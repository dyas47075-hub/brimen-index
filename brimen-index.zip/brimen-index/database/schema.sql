-- =====================================================================
--  BRIMEN Index - struktur database (MySQL 5.7+ / MariaDB 10.3+)
--
--  PILIH SALAH SATU CARA MEMBUAT DATABASE:
--    A) Disarankan : php artisan migrate --seed        (memakai folder database/migrations)
--    B) Manual     : impor file ini lewat phpMyAdmin / mysql CLI
--                    (JANGAN lanjut menjalankan "php artisan migrate", tabelnya sudah ada)
--
--  Isi awal: 1 akun petugas + lemari L, M, N, P. Tabel dokumen & mantri KOSONG.
--  Akun awal : ID Petugas  = admin
--              Kata sandi  = Brimen#2026     <-- WAJIB diganti: php artisan brimen:buat-akun
-- =====================================================================

CREATE DATABASE IF NOT EXISTS brimen_index CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE brimen_index;
SET NAMES utf8mb4;

-- Akun petugas (kata sandi disimpan sebagai hash bcrypt, bukan teks biasa)
CREATE TABLE users (
  id             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_petugas     VARCHAR(30)  NOT NULL,
  nama           VARCHAR(100) NOT NULL,
  password       VARCHAR(255) NOT NULL,
  role           VARCHAR(20)  NOT NULL DEFAULT 'petugas',
  aktif          TINYINT(1)   NOT NULL DEFAULT 1,
  remember_token VARCHAR(100) NULL,
  created_at     TIMESTAMP NULL,
  updated_at     TIMESTAMP NULL,
  PRIMARY KEY (id),
  UNIQUE KEY users_id_petugas_unique (id_petugas)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Referensi mantri
CREATE TABLE mantri (
  id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  kode       VARCHAR(20)  NOT NULL,
  nama       VARCHAR(100) NOT NULL,
  jabatan    VARCHAR(100) NOT NULL DEFAULT 'Junior Associate Mantri',
  foto       MEDIUMTEXT NULL,
  created_at TIMESTAMP NULL,
  updated_at TIMESTAMP NULL,
  PRIMARY KEY (id),
  UNIQUE KEY mantri_kode_unique (kode),
  UNIQUE KEY mantri_nama_unique (nama)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Lemari & laci penyimpanan jaminan (kode lemari = huruf loker pada BRIMEN jaminan)
CREATE TABLE lemari (
  id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  kode       VARCHAR(3) NOT NULL,
  created_at TIMESTAMP NULL,
  updated_at TIMESTAMP NULL,
  PRIMARY KEY (id),
  UNIQUE KEY lemari_kode_unique (kode)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE laci (
  id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  lemari_id  BIGINT UNSIGNED NOT NULL,
  no         SMALLINT UNSIGNED NOT NULL,
  aktif      TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP NULL,
  updated_at TIMESTAMP NULL,
  PRIMARY KEY (id),
  UNIQUE KEY laci_lemari_id_no_unique (lemari_id, no),
  CONSTRAINT laci_lemari_id_foreign FOREIGN KEY (lemari_id) REFERENCES lemari (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dokumen / berkas pinjaman
CREATE TABLE documents (
  id                 VARCHAR(40)  NOT NULL,
  nama_debitur       VARCHAR(150) NOT NULL,
  no_pinjaman        VARCHAR(19)  NOT NULL,                 -- 6152-01-031861-10-1 (unik)
  cif                VARCHAR(30)  NOT NULL,
  jenis_pinjaman     VARCHAR(20)  NOT NULL,                 -- KUR, KUPERA, KUPEDES, KECE, GBT
  plafon             BIGINT UNSIGNED NOT NULL,              -- angka murni, tanpa titik
  mantri_kode        VARCHAR(20)  NOT NULL,
  tgl_realisasi      DATE NOT NULL,
  status_pinjaman    VARCHAR(10)  NOT NULL DEFAULT 'Aktif', -- Aktif, Lunas, Restruk, DH
  berkas_ruang       VARCHAR(10)  NOT NULL,
  berkas_loker       VARCHAR(10)  NOT NULL,
  berkas_laci        VARCHAR(10)  NOT NULL,
  berkas_nomor       VARCHAR(10)  NOT NULL,
  tanpa_agunan       TINYINT(1)   NOT NULL DEFAULT 0,
  jaminan_ruang      VARCHAR(10)  NULL,
  jaminan_loker      VARCHAR(10)  NULL,
  jaminan_laci       VARCHAR(10)  NULL,
  jaminan_nomor      VARCHAR(10)  NULL,
  isi_jaminan        VARCHAR(255) NULL,
  status_jaminan     VARCHAR(30)  NOT NULL DEFAULT 'Aktif', -- Aktif, Lunas, Restruk, DH, Diambil, Lemari Tahan Api, Notaris, Dibawa Mantri
  keterangan_jaminan VARCHAR(255) NULL,
  note               TEXT NULL,
  belum_lengkap      TINYINT(1) NOT NULL DEFAULT 0,
  riwayat            JSON NULL,
  created_at         TIMESTAMP NULL,
  updated_at         TIMESTAMP NULL,
  PRIMARY KEY (id),
  UNIQUE KEY documents_no_pinjaman_unique (no_pinjaman),
  KEY documents_cif_index (cif),
  KEY documents_nama_debitur_index (nama_debitur),
  KEY documents_tgl_realisasi_index (tgl_realisasi),
  KEY documents_jenis_pinjaman_index (jenis_pinjaman),
  KEY documents_mantri_kode_index (mantri_kode),
  KEY documents_jaminan_loker_jaminan_laci_index (jaminan_loker, jaminan_laci),
  KEY documents_berkas_loker_berkas_laci_index (berkas_loker, berkas_laci),
  CONSTRAINT documents_mantri_kode_foreign FOREIGN KEY (mantri_kode) REFERENCES mantri (kode)
    ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Data awal
-- ---------------------------------------------------------------------
INSERT INTO users (id_petugas, nama, password, role, aktif, created_at, updated_at)
VALUES ('admin', 'Administrator', '$2y$12$0sQ7eAhDWv/mlvLxDMzxjOqKDIA6o9dt9mfeLlYlylJHpDbmp6wui', 'admin', 1, NOW(), NOW());

INSERT INTO lemari (kode, created_at, updated_at) VALUES
  ('L', NOW(), NOW()), ('M', NOW(), NOW()), ('N', NOW(), NOW()), ('P', NOW(), NOW());

INSERT INTO laci (lemari_id, no, aktif, created_at, updated_at)
SELECT l.id, n.no, IF(l.kode = 'P' AND n.no = 1, 0, 1), NOW(), NOW()
FROM lemari l
JOIN (SELECT 1 AS no UNION SELECT 2 UNION SELECT 3 UNION SELECT 4) n;
