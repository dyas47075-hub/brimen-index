<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('lemari', function (Blueprint $table) {
            $table->id();
            $table->string('kode', 3)->unique();
            $table->timestamps();
        });

        Schema::create('laci', function (Blueprint $table) {
            $table->id();
            $table->foreignId('lemari_id')->constrained('lemari')->cascadeOnDelete();
            $table->unsignedSmallInteger('no');
            $table->boolean('aktif')->default(true);
            $table->timestamps();
            $table->unique(['lemari_id', 'no']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('laci');
        Schema::dropIfExists('lemari');
    }
};
