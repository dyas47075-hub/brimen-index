<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('documents', function (Blueprint $table) {
            $table->string('id', 40)->primary();

            // Data nasabah
            $table->string('nama_debitur', 150);
            $table->string('no_pinjaman', 19)->unique();      // 6152-01-031861-10-1
            $table->string('cif', 30);
            $table->string('jenis_pinjaman', 20);             // KUR, KUPERA, KUPEDES, KECE, GBT
            $table->unsignedBigInteger('plafon');             // angka murni, tanpa titik
            $table->string('mantri_kode', 20);
            $table->date('tgl_realisasi');
            $table->string('status_pinjaman', 10)->default('Aktif'); // Aktif, Lunas, Restruk, DH

            // BRIMEN berkas (wajib)
            $table->string('berkas_ruang', 10);
            $table->string('berkas_loker', 10);
            $table->string('berkas_laci', 10);
            $table->string('berkas_nomor', 10);

            // Jaminan (kosong bila tanpa agunan)
            $table->boolean('tanpa_agunan')->default(false);
            $table->string('jaminan_ruang', 10)->nullable();
            $table->string('jaminan_loker', 10)->nullable();
            $table->string('jaminan_laci', 10)->nullable();
            $table->string('jaminan_nomor', 10)->nullable();
            $table->string('isi_jaminan', 255)->nullable();
            $table->string('status_jaminan', 30)->default('Aktif');
            $table->string('keterangan_jaminan', 255)->nullable();

            $table->text('note')->nullable();
            $table->boolean('belum_lengkap')->default(false);
            $table->json('riwayat')->nullable();

            $table->timestamps();

            $table->foreign('mantri_kode')->references('kode')->on('mantri')
                ->cascadeOnUpdate()->restrictOnDelete();

            $table->index('cif');
            $table->index('nama_debitur');
            $table->index('tgl_realisasi');
            $table->index('jenis_pinjaman');
            $table->index('mantri_kode');
            $table->index(['jaminan_loker', 'jaminan_laci']);
            $table->index(['berkas_loker', 'berkas_laci']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('documents');
    }
};
