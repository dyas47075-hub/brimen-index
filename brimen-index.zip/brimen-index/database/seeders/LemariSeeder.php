<?php

namespace Database\Seeders;

use App\Models\Laci;
use App\Models\Lemari;
use Illuminate\Database\Seeder;

class LemariSeeder extends Seeder
{
    /** Lemari awal L, M, N, P masing-masing 4 laci (Lemari P laci 1 tidak dipakai). */
    public function run(): void
    {
        foreach (['L', 'M', 'N', 'P'] as $kode) {
            $lemari = Lemari::firstOrCreate(['kode' => $kode]);
            foreach ([1, 2, 3, 4] as $no) {
                Laci::firstOrCreate(
                    ['lemari_id' => $lemari->id, 'no' => $no],
                    ['aktif' => ! ($kode === 'P' && $no === 1)]
                );
            }
        }
    }
}
