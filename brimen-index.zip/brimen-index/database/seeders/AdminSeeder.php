<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;

class AdminSeeder extends Seeder
{
    /** Membuat akun awal dari .env (BRIMEN_ADMIN_*). Ganti kata sandinya dengan: php artisan brimen:buat-akun */
    public function run(): void
    {
        User::updateOrCreate(
            ['id_petugas' => env('BRIMEN_ADMIN_ID', 'admin')],
            [
                'nama' => env('BRIMEN_ADMIN_NAMA', 'Administrator'),
                'password' => env('BRIMEN_ADMIN_PASSWORD', 'Brimen#2026'),
                'role' => 'admin',
                'aktif' => true,
            ]
        );
    }
}
