<?php

namespace Database\Seeders;

use App\Models\Dokumen;
use App\Models\Mantri;
use App\Support\DokumenMapper;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DemoSeeder extends Seeder
{
    /**
     * OPSIONAL - data contoh (6 mantri + 206 dokumen) untuk mencoba aplikasi.
     * Jalankan: php artisan db:seed --class=DemoSeeder
     */
    public function run(): void
    {
        $json = json_decode(file_get_contents(database_path('seeders/data/demo.json')), true);

        DB::transaction(function () use ($json) {
            foreach ($json['mantri'] as $m) {
                Mantri::updateOrCreate(['kode' => $m['kode']], [
                    'nama' => $m['nama'],
                    'jabatan' => $m['jabatan'],
                    'foto' => null,
                ]);
            }

            $kodeByNama = Mantri::pluck('kode', 'nama');

            foreach ($json['docs'] as $d) {
                $model = Dokumen::find($d['id']) ?? new Dokumen();
                $model->id = $d['id'];
                $model->fill(DokumenMapper::fromClient($d, $kodeByNama[$d['mantriFull']]));
                $model->save();
            }
        });
    }
}
