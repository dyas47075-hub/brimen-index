(function(){
  const $=id=>document.getElementById(id);
  const MON=["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"];
  const MCODE={jan:1,feb:2,mar:3,apr:4,mei:5,may:5,jun:6,jul:7,agu:8,aug:8,sep:9,okt:10,oct:10,nov:11,des:12,dec:12};
  const ALLOWED=['KUR','KUPEDES','KUPERA','GBT','KECE'];
  const CODES={'00188207':'Ayunda Febrianti','00223382':'Azizah Ira Alquran','00399892':'Regita Aulia Permadani','00229306':'Antika Prasfilodia','00368716':'Muhammad Adel','00365219':'Taufan Pramana P'};
  const HEAD={
    noPinjaman:['NO REKENING PINJAMAN','NO REKENING','NO REK PINJAMAN','NO PINJAMAN','NOMOR PINJAMAN'],
    nama:['NAMA DEBITUR','NAMA'],
    plafon:['PLAFON','PLAFOND'],
    tgl:['TGL REALISASI','TANGGAL REALISASI'],
    cif:['CIF NO','CIF','NO CIF'],
    jenis:['JENIS PINJ','JENIS PINJAMAN','JENIS'],
    mantri:['MANTRI'],
    brimen:['NO BRIMEN','BRIMEN','BRIMEN BERKAS'],
    noJaminan:['NO JAMINAN','BRIMEN JAMINAN'],
    jaminan:['JAMINAN','ISI JAMINAN']
  };
  const LABEL={noPinjaman:'NO REKENING PINJAMAN',nama:'NAMA DEBITUR',plafon:'PLAFON',tgl:'TGL REALISASI',cif:'CIF NO',jenis:'JENIS PINJ',mantri:'MANTRI',brimen:'NO BRIMEN'};
  const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const str=v=>String(v==null?'':v).replace(/\s+/g,' ').trim();
  const normH=s=>str(s).toUpperCase().replace(/[._]/g,' ').replace(/\s+/g,' ').trim();
  const fmtNum=n=>String(n).replace(/\B(?=(\d{3})+(?!\d))/g,'.');
  const empty=v=>{const s=str(v).toUpperCase();return s===''||/^(-+|N\/?A|NIHIL|NULL)$/.test(s);};
  const toast=(m,t)=>window.App.toast(m,t);

  function parseDate(v){
    let y,m,d;
    if(typeof v==='number'&&v>20000&&v<80000){const t=new Date(Math.round((v-25569)*86400000));y=t.getUTCFullYear();m=t.getUTCMonth()+1;d=t.getUTCDate();}
    else{
      const s=str(v);let a;
      if((a=s.match(/^(\d{4})[\/\-.](\d{1,2})[\/\-.](\d{1,2})/))){y=+a[1];m=+a[2];d=+a[3];}
      else if((a=s.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{2,4})/))){d=+a[1];m=+a[2];y=+a[3];if(y<100)y+=2000;}
      else if((a=s.match(/^(\d{1,2})[\s\-\/.]+([A-Za-z]+)[\s\-\/.,]*(\d{2,4})/))){d=+a[1];m=MCODE[a[2].slice(0,3).toLowerCase()];y=+a[3];if(y<100)y+=2000;}
    }
    if(!y||!m||!d)return null;
    const t=new Date(y,m-1,d);
    if(t.getFullYear()!==y||t.getMonth()!==m-1||t.getDate()!==d||y<2000||y>2100)return null;
    return{iso:y+'-'+String(m).padStart(2,'0')+'-'+String(d).padStart(2,'0'),text:String(d).padStart(2,'0')+' '+MON[m-1]+' '+y};
  }
  function parseCode(v){const p=str(v).toUpperCase().split(/[.\-\/\s,]+/).filter(Boolean);return p.length===4?p:null;}
  function matchMantri(v){
    const raw=str(v);if(!raw)return null;
    const names=window.MantriStore.map(m=>m.nama);
    const c=raw.match(/^(\d{5,})/);if(c){const fm=window.MantriStore.find(m=>m.kode===c[1]);if(fm)return fm.nama;}
    const s=raw.toLowerCase();
    const r=names.find(n=>n.toLowerCase()===s)||(s.length>=3&&names.find(n=>n.toLowerCase().startsWith(s)||s.startsWith(n.toLowerCase())));
    if(r)return r;
    const f=names.filter(n=>n.toLowerCase().split(' ')[0]===s.split(' ')[0]);
    return f.length===1?f[0]:null;
  }
  function findHeader(rows){
    for(let r=0;r<Math.min(rows.length,20);r++){
      const map={};
      (rows[r]||[]).forEach((cell,ci)=>{const h=normH(cell);if(!h)return;for(const f in HEAD){if(map[f]==null&&HEAD[f].indexOf(h)>-1){map[f]=ci;break;}}});
      if(map.noPinjaman!=null&&map.nama!=null&&Object.keys(map).length>=5)return{r:r,map:map};
    }
    return null;
  }
  function convertRow(row,map,existing,seen,seenSlot,upd,seenBerkas,seenCif){
    const g=f=>map[f]==null?'':row[map[f]];
    const dig=str(g('noPinjaman')).replace(/\D/g,'');
    if(dig.length!==15)return{err:'No. rekening pinjaman harus 15 digit'};
    const np=dig.slice(0,4)+'-'+dig.slice(4,6)+'-'+dig.slice(6,12)+'-'+dig.slice(12,14)+'-'+dig.slice(14);
    const nama=str(g('nama'));
    const ex=existing.get(dig);
    if(seen.has(dig)||(ex&&!upd))return{dup:true,np:np,nama:nama};
    if(!nama)return{err:'Nama debitur kosong',np:np};
    const pv=g('plafon');
    const pl=typeof pv==='number'?Math.round(pv):parseInt(str(pv).replace(/rp/i,'').replace(/[.,]\d{1,2}$/,'').replace(/\D/g,''),10);
    if(!pl||pl<=0)return{err:'Plafon tidak valid',np:np,nama:nama};
    const tg=parseDate(g('tgl'));
    if(!tg)return{err:'Tanggal realisasi tidak valid ('+(str(g('tgl'))||'kosong')+')',np:np,nama:nama};
    const cif=str(g('cif'));
    if(!cif)return{err:'CIF kosong',np:np,nama:nama};
    const jr=str(g('jenis')).toUpperCase();
    const jenis=ALLOWED.find(a=>jr===a)||ALLOWED.find(a=>jr.indexOf(a+' ')===0);
    if(!jenis)return{err:'Jenis pinjaman tidak dikenal ('+(jr||'kosong')+')',np:np,nama:nama};
    const mantri=matchMantri(g('mantri'));
    if(!mantri)return{err:'Mantri tidak ada di daftar ('+(str(g('mantri'))||'kosong')+')',np:np,nama:nama};
    let bk=str(g('brimen')),jm=g('noJaminan'),extra=null;
    if(bk.indexOf('//')>-1){const p=bk.split('//');bk=p[0];extra=p[1];}
    const berkas=parseCode(bk);
    if(!berkas)return{err:'NO BRIMEN harus 4 bagian, mis. I.K.2.55 ('+(bk||'kosong')+')',np:np,nama:nama};
    if(empty(jm)&&extra)jm=extra;
    const isi=str(g('jaminan'));
    const tanpa=empty(jm)&&(empty(isi)||/tanpa|tidak ada|nihil/i.test(isi));
    let jaminan=[],isiJ='',inc=false,note='';
    if(!tanpa){
      jaminan=parseCode(jm);
      if(!jaminan)return{err:'NO JAMINAN harus 4 bagian, mis. I.M.3.95 ('+(str(jm)||'kosong')+')',np:np,nama:nama};
      isiJ=isi;if(empty(isi)){isiJ='-';inc=true;note='Isi jaminan belum diisi (hasil impor)';}
    }
    let skey=null;
    if(!tanpa){
      skey=window.Link.slotKey(jaminan);
      const own=window.Link.slotOwner(jaminan,ex?ex.id:null);
      if(own)return{err:'BRIMEN jaminan '+jaminan.join('.')+' sudah dipakai '+own.nama,np:np,nama:nama};
      if(seenSlot.has(skey))return{err:'BRIMEN jaminan '+jaminan.join('.')+' dobel dengan baris lain di file ini',np:np,nama:nama};
    }
    const stBaru=ex?ex.status:'Aktif';
    const bo=window.Link.berkasOwner(berkas,cif,ex?ex.id:null,stBaru);
    if(bo)return{err:'BRIMEN berkas '+berkas.join('.')+' sudah dipakai '+bo.nama+' (CIF berbeda)',np:np,nama:nama};
    const bkey=window.Link.slotKey(berkas),cN=window.Link.cifN(cif);
    if(stBaru!=='Lunas'&&seenBerkas.has(bkey)&&seenBerkas.get(bkey)!==cN)return{err:'BRIMEN berkas '+berkas.join('.')+' dobel dengan baris lain di file ini (CIF berbeda)',np:np,nama:nama};
    if(!ex){
      const cn=window.Link.cifNameOwner(cif,nama,null);
      if(cn)return{err:'CIF '+cif+' sudah terdaftar atas nama '+cn.nama,np:np,nama:nama};
      const nN=window.Link.namaN(nama);
      if(seenCif.has(cN)&&seenCif.get(cN)!==nN)return{err:'CIF '+cif+' sama dengan baris lain di file ini tetapi namanya berbeda',np:np,nama:nama};
    }
    const rec={id:'x'+Date.now().toString(36)+Math.random().toString(36).slice(2,7),nama:nama,noPinjaman:np,cif:cif,plafon:fmtNum(pl),jenis:jenis,mantriFull:mantri,mantri:mantri.split(' ')[0],tglISO:tg.iso,tgl:tg.text,berkas:berkas,jaminan:jaminan,noJaminan:tanpa,isiJaminan:isiJ,status:'Aktif',note:note,incomplete:inc,restruk:false,brimen:berkas.join('.')+(tanpa?'':'//'+jaminan.join('.'))};
    seen.add(dig);if(skey)seenSlot.add(skey);
    if(stBaru!=='Lunas'&&!seenBerkas.has(bkey))seenBerkas.set(bkey,cN);
    if(!ex){seenCif.set(cN,window.Link.namaN(nama));return{rec:rec,info:window.Link.cifOthers(cif,null).length};}
    const ch=[];
    if(ex.nama!==rec.nama)ch.push('nama');
    if(ex.plafon!==rec.plafon)ch.push('plafon');
    if(ex.tglISO!==rec.tglISO)ch.push('tgl realisasi');
    if(ex.cif!==rec.cif)ch.push('CIF');
    if(ex.jenis!==rec.jenis)ch.push('jenis');
    if(ex.mantriFull!==rec.mantriFull)ch.push('mantri');
    if(ex.berkas.join('.')!==rec.berkas.join('.'))ch.push('BRIMEN berkas');
    if(!!ex.noJaminan!==!!rec.noJaminan)ch.push(rec.noJaminan?'jaminan dihapus':'jaminan ditambah');
    else if(!rec.noJaminan){
      if(ex.jaminan.join('.')!==rec.jaminan.join('.'))ch.push('BRIMEN jaminan');
      if(!empty(isi)&&ex.isiJaminan!==rec.isiJaminan)ch.push('isi jaminan');
    }
    if(!ch.length)return{same:true,np:np,nama:nama};
    return{upd:{ex:ex,rec:rec,ch:ch,isiSet:!empty(isi)}};
  }

  function csvRows(text){
    text=text.replace(/^\uFEFF/,'');
    const first=text.split(/\r?\n/).find(l=>l.trim())||'';
    let best=',',bc=-1;[',',';','\t','|'].forEach(c=>{const n=first.split(c).length-1;if(n>bc){bc=n;best=c;}});
    const rows=[];let row=[],cur='',q=false;
    for(let i=0;i<text.length;i++){
      const ch=text[i];
      if(q){if(ch==='"'){if(text[i+1]==='"'){cur+='"';i++;}else q=false;}else cur+=ch;}
      else if(ch==='"')q=true;
      else if(ch===best){row.push(cur);cur='';}
      else if(ch==='\n'||ch==='\r'){if(ch==='\r'&&text[i+1]==='\n')i++;row.push(cur);rows.push(row);row=[];cur='';}
      else cur+=ch;
    }
    if(cur!==''||row.length){row.push(cur);rows.push(row);}
    return rows;
  }
  function htmlSheets(text){
    const doc=new DOMParser().parseFromString(text,'text/html');
    return [...doc.querySelectorAll('table')].map((t,i)=>({name:'Tabel '+(i+1),rows:[...t.querySelectorAll('tr')].map(tr=>[...tr.children].filter(c=>/^t[dh]$/i.test(c.tagName)).map(c=>c.textContent))}));
  }
  function readSheets(file){
    const ext=(file.name.split('.').pop()||'').toLowerCase();
    return new Promise((res,rej)=>{
      const fr=new FileReader();
      fr.onerror=()=>rej(new Error('file tidak bisa dibuka'));
      if(ext==='xlsx'||ext==='xls'){
        fr.onload=()=>{try{
          if(typeof XLSX==='undefined')throw new Error('pembaca Excel belum termuat (periksa koneksi internet, lalu muat ulang halaman)');
          const wb=XLSX.read(fr.result,{type:'array'});
          res(wb.SheetNames.map(n=>({name:n,rows:XLSX.utils.sheet_to_json(wb.Sheets[n],{header:1,raw:true,defval:''})})));
        }catch(e){rej(e);}};
        fr.readAsArrayBuffer(file);
      }else{
        fr.onload=()=>{try{const t=String(fr.result);res(/^(html|htm)$/.test(ext)?htmlSheets(t):[{name:file.name,rows:csvRows(t)}]);}catch(e){rej(e);}};
        fr.readAsText(file);
      }
    });
  }

  let pending=null,ctx=null;
  function showSub(id){
    document.querySelectorAll('.modal-sub').forEach(s=>s.classList.toggle('active',s.id===id));
    $('modalBox').classList.toggle('wide',id==='stepPreview');
  }
  function build(sheets,file){
    ctx={sheets:sheets,file:file};
    let found=null;
    for(const sh of sheets){const h=findHeader(sh.rows);if(h){found={sh:sh,h:h};break;}}
    if(!found){toast('Kolom tidak dikenali. Pastikan ada kolom NO REKENING PINJAMAN dan NAMA DEBITUR beserta kolom lainnya.','err');return;}
    const missing=Object.keys(LABEL).filter(f=>found.h.map[f]==null).map(f=>LABEL[f]);
    if(missing.length){toast('Kolom belum ada di file: '+missing.join(', '),'err');return;}
    const existing=new Map(window.CariApi.DATA.map(d=>[d.noPinjaman.replace(/\D/g,''),d]));
    const upd=$('pvUpdate').checked;
    const seen=new Set(),seenSlot=new Set(),seenBerkas=new Map(),seenCif=new Map(),valid=[],dups=[],errors=[],upds=[],sames=[],infos=[];
    for(let i=found.h.r+1;i<found.sh.rows.length;i++){
      const row=found.sh.rows[i]||[];
      if(row.every(c=>str(c)===''))continue;
      const r=convertRow(row,found.h.map,existing,seen,seenSlot,upd,seenBerkas,seenCif);
      if(r.rec){valid.push(r.rec);if(r.info)infos.push({row:i+1,nama:r.rec.nama,n:r.info});}else if(r.upd){r.upd.row=i+1;upds.push(r.upd);}else if(r.same)sames.push(r);else if(r.dup)dups.push({row:i+1,np:r.np,nama:r.nama});else errors.push({row:i+1,reason:r.err,nama:r.nama||''});
    }
    pending={valid:valid,upds:upds};
    renderPreview(file,found.sh.name,valid,dups,errors,upds,sames,infos);
    showSub('stepPreview');
  }
  function renderPreview(file,sheetName,valid,dups,errors,upds,sames,infos){
    $('pvSub').textContent=file.name+(sheetName&&sheetName!==file.name?'  \u2022  '+sheetName:'');
    $('pvChips').innerHTML='<span class="pv-chip pv-ok">'+valid.length+' data baru</span>'+(upds.length?'<span class="pv-chip pv-upd">'+upds.length+' akan diperbarui</span>':'')+(sames.length?'<span class="pv-chip pv-same">'+sames.length+' tidak berubah</span>':'')+(dups.length?'<span class="pv-chip pv-dup">'+dups.length+' duplikat dilewati</span>':'')+(errors.length?'<span class="pv-chip pv-err">'+errors.length+' baris bermasalah</span>':'');
    const show=valid.slice(0,50);
    $('pvWrap').innerHTML=valid.length?'<table class="pv-table"><thead><tr><th>No. Pinjaman</th><th>Nama Debitur</th><th>Jenis</th><th>Plafon</th><th>Tgl Realisasi</th><th>Mantri</th><th>BRIMEN</th></tr></thead><tbody>'+show.map(d=>'<tr><td>'+esc(d.noPinjaman)+'</td><td>'+esc(d.nama)+'</td><td>'+esc(d.jenis)+'</td><td>Rp '+esc(d.plafon)+'</td><td>'+esc(d.tgl)+'</td><td>'+esc(d.mantri)+'</td><td>'+esc(d.brimen)+'</td></tr>').join('')+'</tbody></table>'+(valid.length>50?'<div style="padding:9px 12px;font-size:12px;color:#6b8198">+ '+(valid.length-50)+' data lainnya</div>':''):'<div style="padding:22px;text-align:center;color:#8599ab;font-size:13px">Tidak ada data baru untuk diimpor.</div>';
    let issues='';
    if(errors.length){issues+='<div class="pv-issues"><b>Baris dilewati (perlu diperbaiki di file):</b><br>'+errors.slice(0,8).map(e=>'Baris '+e.row+(e.nama?' ('+esc(e.nama)+')':'')+': '+esc(e.reason)).join('<br>')+(errors.length>8?'<br>dan '+(errors.length-8)+' baris lainnya':'')+'</div>';}
    if(dups.length){issues+='<div class="pv-issues warn"><b>Sudah ada di sistem / dobel di file:</b><br>'+dups.slice(0,5).map(e=>'Baris '+e.row+': '+esc(e.np)+(e.nama?' ('+esc(e.nama)+')':'')).join('<br>')+(dups.length>5?'<br>dan '+(dups.length-5)+' lainnya':'')+'</div>';}
    if(infos&&infos.length){issues+='<div class="pv-issues info"><b>Nasabah sudah punya pinjaman lain (boleh, hanya pemberitahuan):</b><br>'+infos.slice(0,5).map(u=>'Baris '+u.row+' ('+esc(u.nama)+'): '+u.n+' pinjaman lain').join('<br>')+(infos.length>5?'<br>dan '+(infos.length-5)+' lainnya':'')+'</div>';}
    if(upds.length){issues+='<div class="pv-issues info"><b>Akan diperbarui:</b><br>'+upds.slice(0,6).map(u=>'Baris '+u.row+' ('+esc(u.rec.nama)+'): '+esc(u.ch.join(', '))).join('<br>')+(upds.length>6?'<br>dan '+(upds.length-6)+' lainnya':'')+'</div>';}
    $('pvIssues').innerHTML=issues;
    $('pvImport').textContent=(valid.length&&upds.length)?'Impor '+valid.length+' baru, perbarui '+upds.length:valid.length?'Impor '+valid.length+' data':upds.length?'Perbarui '+upds.length+' data':'Impor';
    $('pvImport').disabled=!(valid.length||upds.length);
  }
  $('pvBack').addEventListener('click',()=>showSub('stepExcel'));
  $('pvCancel').addEventListener('click',()=>$('inputModalOverlay').classList.add('hidden'));
  function applyUpdate(u){
    const ex=u.ex,rec=u.rec,had=!ex.noJaminan;
    ex.nama=rec.nama;ex.plafon=rec.plafon;ex.tgl=rec.tgl;ex.tglISO=rec.tglISO;ex.cif=rec.cif;ex.jenis=rec.jenis;ex.mantriFull=rec.mantriFull;ex.mantri=rec.mantri;ex.berkas=rec.berkas;
    ex.noJaminan=rec.noJaminan;
    if(rec.noJaminan){ex.jaminan=[];ex.isiJaminan='';ex.statusJaminan='Aktif';ex.ketJaminan='';}
    else{
      ex.jaminan=rec.jaminan;
      if(u.isiSet||!had)ex.isiJaminan=rec.isiJaminan;
      if(!had){ex.statusJaminan='Aktif';ex.ketJaminan='';window.Link.syncJaminan(ex);}
    }
    ex.brimen=ex.berkas.join('.')+(ex.noJaminan?'':'//'+ex.jaminan.join('.'));
  }
  $('pvUpdate').addEventListener('change',()=>{if(ctx)build(ctx.sheets,ctx.file);});
  $('pvImport').addEventListener('click',()=>{
    if(!pending||!(pending.valid.length||pending.upds.length))return;
    const n=pending.valid.length,m=pending.upds.length;
    if(n)window.CariApi.DATA.splice.apply(window.CariApi.DATA,[0,0].concat(pending.valid));
    pending.upds.forEach(applyUpdate);
    pending=null;
    window.CariApi.render();
    $('inputModalOverlay').classList.add('hidden');
    toast((n?n+' data baru diimpor':'')+(n&&m?', ':'')+(m?m+' data diperbarui':''));
  });
  window.ImportFile={start:function(file){readSheets(file).then(s=>build(s,file)).catch(e=>toast('File tidak dapat dibaca: '+e.message,'err'));}};
})();
