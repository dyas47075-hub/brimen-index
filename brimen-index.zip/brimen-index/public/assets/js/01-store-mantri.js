/* Daftar mantri dimuat dari database setelah login (lihat 12-sinkronisasi.js) */
window.MantriStore=[];
