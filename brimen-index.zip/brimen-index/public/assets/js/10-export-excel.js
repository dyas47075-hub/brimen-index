(function(){
  const $=id=>document.getElementById(id);
  const A=window.App;
  const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const fmt=n=>String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g,'.');
  const num=s=>parseInt(String(s).replace(/\D/g,''),10)||0;
  const MON=["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"];
  const longDate=iso=>{const p=iso.split('-').map(Number);return String(p[2]).padStart(2,'0')+' '+MON[p[1]-1]+' '+p[0];};
  const slashDate=iso=>{const p=iso.split('-');return p[2]+'/'+p[1]+'/'+p[0];};
  const serial=iso=>{const p=iso.split('-').map(Number);return Math.round((Date.UTC(p[0],p[1]-1,p[2])-Date.UTC(1899,11,30))/86400000);};

  const DOC=[
    {k:'no',l:'NO',def:1,get:(d,i)=>i+1},
    {k:'rek',l:'NO REKENING PINJAMAN',def:1,get:d=>d.noPinjaman},
    {k:'nama',l:'NAMA DEBITUR',def:1,get:d=>d.nama},
    {k:'plafon',l:'PLAFON',def:1,t:'n',z:'#,##0',get:d=>num(d.plafon)},
    {k:'tgl',l:'TGL REALISASI',def:1,t:'d',get:d=>d.tglISO},
    {k:'cif',l:'CIF NO',def:1,get:d=>d.cif},
    {k:'jenis',l:'JENIS PINJ',def:1,get:d=>d.jenis},
    {k:'mantri',l:'MANTRI',def:1,get:d=>d.mantriFull},
    {k:'brimen',l:'NO BRIMEN',def:1,get:d=>d.berkas.join('.')},
    {k:'nojam',l:'NO JAMINAN',def:1,get:d=>d.noJaminan?'':d.jaminan.join('.')},
    {k:'jam',l:'JAMINAN',def:1,get:d=>d.noJaminan?'TANPA AGUNAN':d.isiJaminan},
    {k:'stp',l:'STATUS PINJAMAN',get:d=>d.status},
    {k:'stj',l:'STATUS JAMINAN',get:d=>d.noJaminan?'':(d.statusJaminan||'Aktif')},
    {k:'ket',l:'KETERANGAN JAMINAN',get:d=>d.noJaminan?'':(d.ketJaminan||'')},
    {k:'lkp',l:'KELENGKAPAN',get:d=>d.incomplete?'Belum lengkap':'Lengkap'},
    {k:'note',l:'CATATAN',get:d=>d.note||''}
  ];
  const JAM=[
    {k:'lem',l:'LEMARI',def:1,get:d=>d.jaminan[1]},
    {k:'laci',l:'LACI',def:1,t:'n',get:d=>parseInt(d.jaminan[2],10)||0},
    {k:'urut',l:'NO URUT',def:1,t:'n',get:d=>parseInt(d.jaminan[3],10)||0},
    {k:'nama',l:'NAMA DEBITUR',def:1,get:d=>d.nama},
    {k:'rek',l:'NO REKENING PINJAMAN',def:1,get:d=>d.noPinjaman},
    {k:'isi',l:'ISI JAMINAN',def:1,get:d=>d.isiJaminan},
    {k:'stj',l:'STATUS JAMINAN',def:1,get:d=>d.statusJaminan||'Aktif'},
    {k:'ket',l:'KETERANGAN',def:1,get:d=>d.ketJaminan||''},
    {k:'kode',l:'NO JAMINAN (KODE)',get:d=>d.jaminan.join('.')},
    {k:'mantri',l:'MANTRI',get:d=>d.mantriFull},
    {k:'jenis',l:'JENIS PINJ',get:d=>d.jenis},
    {k:'plafon',l:'PLAFON',t:'n',z:'#,##0',get:d=>num(d.plafon)}
  ];
  const DEFS={doc:DOC,jam:JAM};
  const S={ds:'doc',fmt:'xlsx',sep:';',cols:{doc:new Set(DOC.filter(c=>c.def).map(c=>c.k)),jam:new Set(JAM.filter(c=>c.def).map(c=>c.k))},f:{from:'',to:'',mantri:'',jenis:'',status:'',lengkap:'',stj:''}};
  const JENIS=['KUR','KUPERA','KUPEDES','KECE','GBT'];
  const STJ=['Aktif','Lunas','Restruk','DH','Diambil','Lemari Tahan Api','Notaris','Dibawa Mantri'];

  const cols=()=>DEFS[S.ds].filter(c=>S.cols[S.ds].has(c.k));
  function rows(){
    const f=S.f;
    let r=window.CariApi.DATA.filter(d=>(S.ds!=='jam'||(!d.noJaminan&&d.jaminan&&d.jaminan.length===4))&&
      (!f.from||d.tglISO>=f.from)&&(!f.to||d.tglISO<=f.to)&&(!f.mantri||d.mantriFull===f.mantri)&&(!f.jenis||d.jenis===f.jenis)&&(!f.status||d.status===f.status)&&
      (!f.lengkap||(f.lengkap==='lengkap'?!d.incomplete:!!d.incomplete))&&(S.ds!=='jam'||!f.stj||(d.statusJaminan||'Aktif')===f.stj));
    if(S.ds==='jam')r.sort((a,b)=>a.jaminan[1].localeCompare(b.jaminan[1])||(parseInt(a.jaminan[2],10)-parseInt(b.jaminan[2],10))||(parseInt(a.jaminan[3],10)-parseInt(b.jaminan[3],10)));
    else r.sort((a,b)=>a.tglISO.localeCompare(b.tglISO)||a.noPinjaman.localeCompare(b.noPinjaman));
    return r;
  }
  const disp=(c,d,i)=>{const v=c.get(d,i);return c.t==='d'?longDate(v):(c.k==='plafon'?fmt(v):v);};

  /* ---------- UI ---------- */
  function buildFilters(){
    const keep=S.f;
    $('exMantri').innerHTML='<option value="">Semua mantri</option>'+window.MantriStore.map(m=>'<option value="'+esc(m.nama)+'"'+(keep.mantri===m.nama?' selected':'')+'>'+esc(m.nama)+'</option>').join('');
    $('exJenis').innerHTML='<option value="">Semua jenis</option>'+JENIS.map(j=>'<option value="'+j+'"'+(keep.jenis===j?' selected':'')+'>'+j+'</option>').join('');
    $('exStj').innerHTML='<option value="">Semua status</option>'+STJ.map(j=>'<option value="'+esc(j)+'"'+(keep.stj===j?' selected':'')+'>'+esc(j)+'</option>').join('');
    $('exStjWrap').style.display=S.ds==='jam'?'':'none';
  }
  function renderCols(){
    $('exCols').innerHTML=DEFS[S.ds].map(c=>'<label class="ex-col'+(S.cols[S.ds].has(c.k)?' on':'')+'"><input type="checkbox" data-k="'+c.k+'"'+(S.cols[S.ds].has(c.k)?' checked':'')+'>'+esc(c.l)+'</label>').join('');
  }
  function refresh(){
    const r=rows(),cs=cols();
    $('exCount').textContent=fmt(r.length);
    $('exDsLabel').textContent=S.ds==='doc'?'dokumen akan diekspor':'jaminan akan diekspor';
    $('exColCount').textContent=cs.length+' kolom dipilih';
    $('exCsvOpt').style.display=S.fmt==='csv'?'':'none';
    $('exExt').textContent='.'+S.fmt;
    const ok=r.length>0&&cs.length>0;
    $('exGo').disabled=!ok;
    $('exPrevSub').textContent=r.length?'8 baris pertama dari '+fmt(r.length):'';
    if(!cs.length)$('exPrev').innerHTML='<div class="empty">Pilih minimal satu kolom.</div>';
    else if(!r.length)$('exPrev').innerHTML='<div class="empty">Tidak ada data yang cocok dengan filter.</div>';
    else $('exPrev').innerHTML='<table class="jd-tbl"><thead><tr>'+cs.map(c=>'<th>'+esc(c.l)+'</th>').join('')+'</tr></thead><tbody>'+r.slice(0,8).map((d,i)=>'<tr>'+cs.map(c=>'<td>'+esc(disp(c,d,i))+'</td>').join('')+'</tr>').join('')+'</tbody></table>';
  }

  /* ---------- pembuat file ---------- */
  function csvCell(v,sep){const s=String(v==null?'':v);return(s.indexOf(sep)>-1||/["\r\n]/.test(s))?'"'+s.replace(/"/g,'""')+'"':s;}
  function buildCsv(cs,data,sep){
    const lines=[cs.map(c=>csvCell(c.l,sep)).join(sep)];
    data.forEach((d,i)=>lines.push(cs.map(c=>{const v=c.get(d,i);return csvCell(c.t==='d'?slashDate(v):v,sep);}).join(sep)));
    return new Blob(['\uFEFF'+lines.join('\r\n')],{type:'text/csv;charset=utf-8'});
  }
  function buildXlsx(cs,data,sheet){
    const aoa=[cs.map(c=>c.l)].concat(data.map((d,i)=>cs.map(c=>{const v=c.get(d,i);return c.t==='d'?serial(v):v;})));
    const ws=XLSX.utils.aoa_to_sheet(aoa);
    cs.forEach((c,ci)=>{
      if(c.t==='d'||c.z)for(let r=1;r<=data.length;r++){const a=ws[XLSX.utils.encode_cell({r:r,c:ci})];if(a)a.z=c.t==='d'?'dd/mm/yyyy':c.z;}
    });
    ws['!cols']=cs.map((c,ci)=>({wch:Math.min(45,Math.max(c.l.length,c.t==='d'?12:0,data.slice(0,300).reduce((m,d,i)=>Math.max(m,String(c.t==='d'?'dd/mm/yyyy':c.get(d,i)).length),0))+2)}));
    ws['!autofilter']={ref:XLSX.utils.encode_range({s:{r:0,c:0},e:{r:Math.max(data.length,0),c:cs.length-1}})};
    const wb=XLSX.utils.book_new();XLSX.utils.book_append_sheet(wb,ws,sheet);
    return new Blob([XLSX.write(wb,{bookType:'xlsx',type:'array'})],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
  }
  function make(cs,data,sheet){
    if(S.fmt==='csv')return buildCsv(cs,data,S.sep==='tab'?'\t':S.sep);
    if(typeof XLSX==='undefined')throw new Error('Pembuat file Excel belum termuat (periksa koneksi internet), atau pilih format CSV.');
    return buildXlsx(cs,data,sheet);
  }
  const dlP=(window.claude&&typeof window.claude.use==='function')?Promise.resolve().then(()=>window.claude.use('downloads')).catch(()=>null):Promise.resolve(null);
  async function saveFile(name,blob){
    const dl=await dlP;
    if(dl){
      try{await dl.save({filename:name,data:blob});return 'saved';}
      catch(e){const c=e&&e.code;if(c==='declined')return 'declined';if(c==='rate_limited')return 'busy';if(c==='too_large')return 'big';}
    }
    const url=URL.createObjectURL(blob),a=document.createElement('a');
    a.href=url;a.download=name;a.style.display='none';document.body.appendChild(a);a.click();
    setTimeout(()=>{try{URL.revokeObjectURL(url);}catch(e){}a.remove();},1500);
    return 'saved';
  }
  const cleanName=s=>String(s).replace(/[\\\/:*?"<>|]+/g,'').replace(/\s+/g,' ').trim();
  async function run(name,blob){
    const res=await saveFile(name,blob);
    A.toast(res==='saved'?'File '+name+' siap diunduh':res==='declined'?'Download dibatalkan':res==='busy'?'Tunggu sebentar, lalu coba lagi':'File terlalu besar, persempit filternya',(res==='busy'||res==='big')?'err':undefined);
  }
  $('exGo').addEventListener('click',()=>{
    const cs=cols(),r=rows();if(!cs.length||!r.length)return;
    let base=cleanName($('exName').value)||'Export_BRIMEN';
    try{run(base+'.'+S.fmt,make(cs,r,S.ds==='doc'?'Dokumen':'Jaminan'));}catch(e){A.toast(e.message,'err');}
  });
  $('exTpl').addEventListener('click',()=>{
    const cs=DOC.filter(c=>c.def);
    try{run('Template_Impor_BRIMEN.'+S.fmt,make(cs,[],'Template'));}catch(e){A.toast(e.message,'err');}
  });

  /* ---------- event ---------- */
  document.querySelectorAll('#exDs button').forEach(b=>b.addEventListener('click',()=>{
    S.ds=b.dataset.ds;document.querySelectorAll('#exDs button').forEach(x=>x.classList.toggle('active',x===b));
    buildFilters();renderCols();refresh();
  }));
  document.querySelectorAll('#exFmt button').forEach(b=>b.addEventListener('click',()=>{
    S.fmt=b.dataset.fmt;document.querySelectorAll('#exFmt button').forEach(x=>x.classList.toggle('active',x===b));refresh();
  }));
  $('exSep').addEventListener('change',e=>{S.sep=e.target.value;});
  $('exCols').addEventListener('change',e=>{
    const k=e.target.dataset.k;if(!k)return;
    const set=S.cols[S.ds];e.target.checked?set.add(k):set.delete(k);
    e.target.closest('.ex-col').classList.toggle('on',e.target.checked);refresh();
  });
  $('exAll').addEventListener('click',()=>{S.cols[S.ds]=new Set(DEFS[S.ds].map(c=>c.k));renderCols();refresh();});
  $('exNone').addEventListener('click',()=>{S.cols[S.ds]=new Set();renderCols();refresh();});
  $('exStd').addEventListener('click',()=>{S.cols[S.ds]=new Set(DEFS[S.ds].filter(c=>c.def).map(c=>c.k));renderCols();refresh();});
  [['exFrom','from'],['exTo','to'],['exMantri','mantri'],['exJenis','jenis'],['exStatus','status'],['exLengkap','lengkap'],['exStj','stj']].forEach(p=>$(p[0]).addEventListener('change',e=>{S.f[p[1]]=e.target.value;refresh();}));
  $('exReset').addEventListener('click',()=>{S.f={from:'',to:'',mantri:'',jenis:'',status:'',lengkap:'',stj:''};['exFrom','exTo','exStatus','exLengkap'].forEach(id=>$(id).value='');buildFilters();refresh();});

  const today=()=>{const d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');};
  A.goExport=function(){
    buildFilters();renderCols();
    if(!$('exName').value)$('exName').value='Export_BRIMEN_'+today();
    refresh();A.show('export');A.setNav('export');
  };
})();
