
(function () {
    // =====================================================
    // 1. KONFIGURASI DASAR
    // =====================================================

    const $ = id => document.getElementById(id);

    const MON = [
        "Januari", "Februari", "Maret", "April",
        "Mei", "Juni", "Juli", "Agustus",
        "September", "Oktober", "November", "Desember"
    ];

    const MS = [
        "Jan", "Feb", "Mar", "Apr", "Mei", "Jun",
        "Jul", "Agu", "Sep", "Okt", "Nov", "Des"
    ];

    const JC = {
        KUR: '#155c22',
        KUPERA: '#2e8b3f',
        KUPEDES: '#8fd19e',
        KECE: '#1a6fe0',
        GBT: '#f0b429'
    };

    const nf = n =>
        String(n).replace(/\B(?=(\d{3})+(?!\d))/g, '.');


    // =====================================================
    // 2. FUNGSI GRAFIK AKTIVITAS PER BULAN
    // =====================================================

    function renderActivityChart(D, year) {

        const dok = Array(12).fill(0);
        const jam = Array(12).fill(0);

        // Menghitung dokumen berdasarkan tahun terpilih
        D.forEach(d => {

            const tanggal = d.tglISO || '';

            if (!/^\d{4}-\d{2}-\d{2}$/.test(tanggal)) {
                return;
            }

            const p = tanggal.split('-').map(Number);

            const validDate =
                p[1] >= 1 && p[1] <= 12 &&
                p[2] >= 1 && p[2] <= 31;

            if (!validDate || p[0] !== year) {
                return;
            }

            const bulan = p[1] - 1;

            // Total dokumen
            dok[bulan]++;

            // Mengikuti definisi perhitungan jaminan
            // yang digunakan pada dashboard asli
            if (!d.noJaminan) {
                jam[bulan]++;
            }
        });


        // -------------------------------------------------
        // SKALA SUMBU Y
        // -------------------------------------------------

        const mx = Math.max(1, ...dok, ...jam);

        const iv = mx <= 4 ? mx : 4;

        const step = mx <= 4
            ? 1
            : Math.ceil(mx / 4);

        const top = iv * step;

        let lines = '';

        for (let i = 0; i <= iv; i++) {

            lines +=
                '<div class="bc-line" style="bottom:' +
                (i * step / top * 100) +
                '%">' +
                '<span class="bc-tick">' +
                (i * step) +
                '</span>' +
                '</div>';
        }


        // -------------------------------------------------
        // MEMBUAT BATANG GRAFIK 12 BULAN
        // -------------------------------------------------

        let cols = '';

        for (let m = 0; m < 12; m++) {

            const tinggiDok = dok[m] / top * 100;
            const tinggiJam = jam[m] / top * 100;

            cols +=
                '<div class="bc-col">' +

                '<div class="bc-bar" style="height:' +
                tinggiDok +
                '%;background:#0b559f" title="' +
                MS[m] + ': ' + dok[m] +
                ' dokumen"></div>' +

                '<div class="bc-bar" style="height:' +
                tinggiJam +
                '%;background:#9c1f3b" title="' +
                MS[m] + ': ' + jam[m] +
                ' jaminan"></div>' +

                '</div>';
        }


        // -------------------------------------------------
        // MENAMPILKAN GRAFIK
        // -------------------------------------------------

        const plot = $('bcPlot');
        const months = $('bcMonths');

        if (plot) {
            plot.innerHTML =
                lines +
                '<div class="bc-cols">' +
                cols +
                '</div>';
        }

        if (months) {
            months.innerHTML = MS.map(m =>
                '<span>' + m + '</span>'
            ).join('');
        }
    }


    // =====================================================
    // 3. FUNGSI FILTER TAHUN OTOMATIS
    // =====================================================

    function renderYearFilter(D) {

        const yearSelect = $('bcYear');

        // Mengambil tahun unik dari tanggal realisasi
        const years = [
            ...new Set(
                D
                    .map(d => d.tglISO || '')
                    .filter(t => /^\d{4}-\d{2}-\d{2}$/.test(t))
                    .map(t => Number(t.substring(0, 4)))
            )
        ].sort((a, b) => b - a);

        // Jika belum ada data, gunakan tahun sekarang
        const availableYears = years.length
            ? years
            : [new Date().getFullYear()];

        // Pertahankan pilihan tahun sebelumnya
        const previousYear = yearSelect
            ? Number(yearSelect.value)
            : NaN;

        const selectedYear =
            availableYears.includes(previousYear)
                ? previousYear
                : availableYears[0];

        // Mengisi dropdown tahun
        if (yearSelect) {

            yearSelect.innerHTML = availableYears
                .map(y =>
                    '<option value="' + y + '">' + y + '</option>'
                )
                .join('');

            yearSelect.value = String(selectedYear);

            // Event ketika pengguna mengganti tahun
            yearSelect.onchange = function () {

                const selected = Number(this.value);

                renderActivityChart(
                    CariApi.DATA,
                    selected
                );
            };
        }

        // Render grafik pertama kali
        renderActivityChart(D, selectedYear);
    }


    // =====================================================
    // 4. FUNGSI UTAMA DASHBOARD
    // =====================================================

    function renderDash() {

        const D = Array.isArray(CariApi.DATA)
            ? CariApi.DATA
            : [];

        const now = new Date();
        const hr = now.getHours();

        // Tanggal dashboard
        $('dbDate').textContent =
            now.getDate() + ' ' +
            MON[now.getMonth()] + ' ' +
            now.getFullYear();

        // Sapaan berdasarkan waktu
        $('dbGreet').textContent =
            'Selamat ' +
            (hr < 11 ? 'Pagi' :
                hr < 15 ? 'Siang' :
                    hr < 18 ? 'Sore' : 'Malam') +
            ', bagaimana kabarmu hari ini?';

        // Nama administrator
        $('dbName').textContent =
            (window.AppUser && window.AppUser.name) || 'Lina';


        // -------------------------------------------------
        // KARTU STATISTIK
        // -------------------------------------------------

        $('stDok').textContent = nf(D.length);

        $('stJam').textContent = nf(
            D.filter(d => !d.noJaminan).length
        );

        $('stMan').textContent = nf(
            window.MantriStore
                ? window.MantriStore.length
                : 0
        );


        // -------------------------------------------------
        // GRAFIK AKTIVITAS DINAMIS
        // -------------------------------------------------

        renderYearFilter(D);


        // =================================================
        // 5. DIAGRAM DISTRIBUSI JENIS PINJAMAN
        // =================================================

        const cnt = {};

        D.forEach(d => {

            const jenis = d.jenis;

            if (jenis) {
                cnt[jenis] = (cnt[jenis] || 0) + 1;
            }
        });

        const keys = [
            'KUR',
            'KUPERA',
            'KUPEDES',
            'KECE',
            'GBT'
        ].filter(k => cnt[k]);

        const tot = D.length || 1;

        let a0 = -Math.PI / 2;
        let svg = '';

        keys.forEach(k => {

            const f = cnt[k] / tot;
            const a1 = a0 + f * 2 * Math.PI;

            const tip =
                k + ': ' +
                cnt[k] + ' (' +
                Math.round(f * 100) + '%)';

            if (keys.length === 1) {

                svg +=
                    '<circle r="1" fill="' +
                    JC[k] +
                    '">' +
                    '<title>' + tip + '</title>' +
                    '</circle>';

            } else {

                svg +=
                    '<path d="M0 0 L' +
                    Math.cos(a0) + ' ' +
                    Math.sin(a0) +
                    ' A1 1 0 ' +
                    (f > 0.5 ? 1 : 0) +
                    ' 1 ' +
                    Math.cos(a1) + ' ' +
                    Math.sin(a1) +
                    ' Z" fill="' +
                    JC[k] +
                    '" stroke="#fff" stroke-width=".025">' +
                    '<title>' + tip + '</title>' +
                    '</path>';
            }

            a0 = a1;
        });


        // Menampilkan diagram lingkaran
        $('pieSvg').innerHTML = svg;


        // Menampilkan legenda
        $('pieLegend').innerHTML = keys.map(k =>
            '<span>' +
            '<i style="background:' + JC[k] + '"></i>' +
            k +
            '<b>' + cnt[k] + '</b>' +
            '</span>'
        ).join('');
    }


    // =====================================================
    // 6. NAVIGASI APLIKASI
    // =====================================================

    const A = window.App;

    A.goDashboard = () => {

        renderDash();

        A.show('dashboard');

        A.setNav('dashboard');
    };

    A.logout = function () {

        window.Sync.logout();
    };


    document.querySelectorAll('[data-nav]').forEach(a => {

        a.addEventListener('click', () => {

            const k = a.dataset.nav;

            if (k === 'dashboard') {
                A.goDashboard();

            } else if (k === 'cari') {
                A.goCari();

            } else if (k === 'new') {
                A.openNew();

            } else if (k === 'logout') {
                A.logout();

            } else if (k === 'mantri') {
                A.goMantri();

            } else if (k === 'jaminan') {
                A.goJaminan();

            } else if (k === 'statistik') {
                A.goStatistik();

            } else if (k === 'export') {
                A.goExport();

            } else {
                A.toast('Halaman ini akan dibuat selanjutnya');
            }
        });
    });


    // =====================================================
    // 7. LOGIN
    // =====================================================

    let remember = false;

    $('lgRemember').addEventListener('click', () => {

        remember = !remember;

        $('lgChk').classList.toggle(
            'checked',
            remember
        );
    });


    $('lgForgot').addEventListener('click', () => {

        A.toast('Hubungi admin untuk mereset kata sandi');
    });


    async function doLogin() {

        const id = $('lgId').value.trim();
        const pw = $('lgPw').value;

        if (!id || !pw) {

            $('lgErr').textContent =
                'ID Petugas dan kata sandi wajib diisi';

            return;
        }

        $('lgErr').textContent = '';

        $('lgBtn').disabled = true;

        try {

            await window.Sync.login(
                id,
                pw,
                remember
            );

            document.body.classList.remove('logged-out');

            A.goDashboard();

        } catch (e) {

            $('lgErr').textContent = e.message;

        } finally {

            $('lgBtn').disabled = false;
        }
    }


    $('lgBtn').addEventListener('click', doLogin);


    $('lgId').addEventListener('keydown', e => {

        if (e.key === 'Enter') {

            e.preventDefault();

            $('lgPw').focus();
        }
    });


    $('lgPw').addEventListener('keydown', e => {

        if (e.key === 'Enter') {

            e.preventDefault();

            doLogin();
        }
    });

})();
