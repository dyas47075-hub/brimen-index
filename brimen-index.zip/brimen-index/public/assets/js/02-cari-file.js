(function(){
const JENIS_LIST = ["KUR","KUPERA","KUPEDES","KECE","GBT"];
const MANTRI_LIST = window.MantriStore.map(m=>({code:m.kode,name:m.nama}));

const DATA = []; // diisi dari database
DATA.forEach(d=>{d.statusJaminan=d.statusJaminan||(d.noJaminan?'Aktif':(['Aktif','Lunas','Restruk','DH'].indexOf(d.status)>-1?d.status:'Aktif'));d.ketJaminan=d.ketJaminan||'';d.riwayat=d.riwayat||[];d.mantri=d.mantriFull.split(' ')[0];d.restruk=d.status==='Restruk';d.brimen=d.berkas.join('.')+(d.noJaminan?'':'//'+d.jaminan.join('.'));});

let state = {mantri:null, jenis:null, query:"", tanggal:null};
let activeNote = null;

const cardsContainer = document.getElementById('cardsContainer');
const mantriBtn = document.getElementById('mantriBtn');
const mantriLabel = document.getElementById('mantriLabel');
const mantriDropdown = document.getElementById('mantriDropdown');
const pinjamanBtn = document.getElementById('pinjamanBtn');
const pinjamanLabel = document.getElementById('pinjamanLabel');
const pinjamanDropdown = document.getElementById('pinjamanDropdown');
const tanggalBtn = document.getElementById('tanggalBtn');
const tanggalLabel = document.getElementById('tanggalLabel');
const tanggalDropdown = document.getElementById('tanggalDropdown');
const tglInput = document.getElementById('tglInput');

function formatTglLabel(iso){
  const d = new Date(iso+'T00:00:00');
  return d.toLocaleDateString('id-ID', {day:'2-digit', month:'long', year:'numeric'});
}

function buildDropdowns(){
  mantriDropdown.innerHTML = MANTRI_LIST.map(m =>
    `<button class="dd-item" data-code="${m.code}" data-name="${m.name}">${m.code} - ${m.name}</button>`
  ).join('');
  pinjamanDropdown.innerHTML = JENIS_LIST.map(j =>
    `<button class="dd-item" data-jenis="${j}">${j}</button>`
  ).join('');
}

function render(){
  let filtered = DATA.filter(d=>{
    if(state.jenis && d.jenis !== state.jenis) return false;
    if(state.mantri && d.mantriFull !== state.mantri) return false;
    if(state.tanggal && d.tglISO !== state.tanggal) return false;
    if(state.query){
      const q = state.query.toLowerCase();
      const hay = (d.nama+d.brimen+d.cif+d.noPinjaman).toLowerCase();
      if(!hay.includes(q)) return false;
    }
    return true;
  });

  if(filtered.length === 0){
    cardsContainer.innerHTML = '<div class="empty">Tidak ada data yang cocok.</div>';
    return;
  }

  cardsContainer.innerHTML = filtered.map((d, i)=>`
    <div class="card ${d.incomplete ? 'incomplete':''}" data-id="${d.id}">
      <div class="card-left">
        <p class="nama">${d.nama}</p>
        <p class="brimen">BRIMEN : ${d.brimen}</p>
        <div class="row"><span class="lbl">No. Pinjaman :</span><span class="val">${d.noPinjaman}</span></div>
        <div class="row"><span class="lbl">CIF :</span><span class="val">${d.cif}</span></div>
        <div class="row"><span class="lbl">Tgl Realisasi :</span><span class="val">${d.tgl}</span></div>
        <div class="row"><span class="lbl">Plafon :</span><span class="val">${d.plafon}</span></div>
      </div>
      <div class="card-right">
        <div>
          <div class="tag-row">
            ${d.status==='Restruk' ? '<span class="badge-restruk">Restruk</span>' : d.status==='Lunas' ? '<span class="badge-lunas">Lunas</span>' : d.status==='DH' ? '<span class="badge-dh">DH</span>' : ''}
            <span class="jenis">${d.jenis}</span>
          </div>
          <div class="mantri-tag">Mantri : ${d.mantri}</div>
        </div>
        <div class="icon-row">
          ${activeNote===i ? `<div class="note-pop">Note : ${d.note || 'Berkas belum lengkap'}</div>` : ''}
          ${d.status==='Lunas'?`<button class="icon-btn icon-del" title="Hapus data (lunas)" data-act="del" data-id="${d.id}"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14M10 11v6M14 11v6"/></svg></button>`:''}
          ${`<button class="icon-btn icon-view" title="Lihat detail" data-act="view" data-id="${d.id}">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7Z"/><circle cx="12" cy="12" r="3"/></svg>
          </button>`}
          <button class="icon-btn icon-edit" title="Edit" data-act="edit" data-id="${d.id}">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>
          </button>
          ${d.incomplete ? `<button class="icon-btn icon-note" data-idx="${i}" title="Catatan">?</button>` : ''}
        </div>
      </div>
    </div>
  `).join('');

  cardsContainer.querySelectorAll('.icon-note').forEach(btn=>{
    btn.addEventListener('click', (e)=>{
      e.stopPropagation();
      const idx = parseInt(btn.dataset.idx);
      activeNote = activeNote === idx ? null : idx;
      render();
    });
  });
}

mantriBtn.addEventListener('click', (e)=>{
  e.stopPropagation();
  pinjamanDropdown.classList.add('hidden');
  mantriDropdown.classList.toggle('hidden');
});
pinjamanBtn.addEventListener('click', (e)=>{
  e.stopPropagation();
  mantriDropdown.classList.add('hidden');
  tanggalDropdown.classList.add('hidden');
  pinjamanDropdown.classList.toggle('hidden');
});
tanggalBtn.addEventListener('click', (e)=>{
  e.stopPropagation();
  mantriDropdown.classList.add('hidden');
  pinjamanDropdown.classList.add('hidden');
  tanggalDropdown.classList.toggle('hidden');
});
tanggalDropdown.addEventListener('click', (e)=> e.stopPropagation());

document.getElementById('tglApply').addEventListener('click', ()=>{
  if(!tglInput.value) return;
  state.tanggal = tglInput.value;
  tanggalLabel.textContent = formatTglLabel(tglInput.value);
  tanggalBtn.classList.add('selected');
  tanggalDropdown.classList.add('hidden');
  activeNote = null;
  render();
});
document.getElementById('tglClear').addEventListener('click', ()=>{
  state.tanggal = null;
  tglInput.value = '';
  tanggalLabel.textContent = 'Tanggal';
  tanggalBtn.classList.remove('selected');
  tanggalDropdown.classList.add('hidden');
  activeNote = null;
  render();
});

mantriDropdown.addEventListener('click', (e)=>{
  const item = e.target.closest('.dd-item');
  if(!item) return;
  const fullName = item.dataset.name;
  const shortName = fullName.split(' ')[0];
  state.mantri = fullName;
  mantriLabel.textContent = shortName;
  mantriBtn.classList.add('selected');
  mantriDropdown.classList.add('hidden');
  activeNote = null;
  render();
});

pinjamanDropdown.addEventListener('click', (e)=>{
  const item = e.target.closest('.dd-item');
  if(!item) return;
  state.jenis = item.dataset.jenis;
  pinjamanLabel.textContent = state.jenis;
  pinjamanBtn.classList.add('selected');
  pinjamanDropdown.classList.add('hidden');
  activeNote = null;
  render();
});

document.addEventListener('click', ()=>{
  mantriDropdown.classList.add('hidden');
  pinjamanDropdown.classList.add('hidden');
  tanggalDropdown.classList.add('hidden');
  if(activeNote !== null){ activeNote = null; render(); }
});

document.getElementById('searchInput').addEventListener('input', (e)=>{
  state.query = e.target.value;
  render();
});

buildDropdowns();
render();

/* ===== MODAL INPUT FILE ===== */
const overlay = document.getElementById('inputModalOverlay');
const openBtn = document.getElementById('openInputModalBtn');
const closeBtn = document.getElementById('closeModalBtn');
const stepChoice = document.getElementById('stepChoice');
const stepExcel = document.getElementById('stepExcel');
const stepManual = document.getElementById('stepManual');

function showStep(step){
  document.querySelectorAll('.modal-sub').forEach(s=>s.classList.remove('active'));
  document.getElementById('modalBox').classList.remove('wide');
  step.classList.add('active');
}
function openModal(){
  overlay.classList.remove('hidden');
  showStep(stepChoice);
  resetExcelStep();
}
function closeModal(){ overlay.classList.add('hidden'); }

openBtn.addEventListener('click', openModal);
closeBtn.addEventListener('click', closeModal);
overlay.addEventListener('click', (e)=>{ if(e.target === overlay) closeModal(); });

document.getElementById('choiceExcel').addEventListener('click', ()=> showStep(stepExcel));
document.getElementById('choiceManual').addEventListener('click', ()=>{ closeModal(); window.App.openNew(); });
document.getElementById('backFromExcel').addEventListener('click', ()=> showStep(stepChoice));
document.getElementById('backFromManual').addEventListener('click', ()=> showStep(stepChoice));
document.getElementById('cancelExcel').addEventListener('click', closeModal);
document.getElementById('cancelManual').addEventListener('click', closeModal);

const dropzone = document.getElementById('dropzone');
const excelInput = document.getElementById('excelInput');
const fileChipWrap = document.getElementById('fileChipWrap');
const processBtn = document.getElementById('processExcel');
let selectedFile = null;

function resetExcelStep(){
  selectedFile = null;
  excelInput.value = '';
  fileChipWrap.innerHTML = '';
  processBtn.disabled = true;
}

dropzone.addEventListener('click', ()=> excelInput.click());
dropzone.addEventListener('dragover', (e)=>{ e.preventDefault(); dropzone.style.borderColor='#1a6fe0'; });
dropzone.addEventListener('dragleave', ()=>{ dropzone.style.borderColor=''; });
dropzone.addEventListener('drop', (e)=>{
  e.preventDefault(); dropzone.style.borderColor='';
  if(e.dataTransfer.files.length) handleFile(e.dataTransfer.files[0]);
});
excelInput.addEventListener('change', (e)=>{
  if(e.target.files.length) handleFile(e.target.files[0]);
});

function handleFile(file){
  const okExt = /\.(xlsx|xls|csv|txt|html|htm)$/i.test(file.name);
  if(!okExt){ window.App.toast('Format file tidak didukung. Gunakan .xlsx, .xls, .csv, .txt, atau .html'); return; }
  selectedFile = file;
  fileChipWrap.innerHTML = `
    <div class="file-chip">
      <span>📄 ${file.name.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))} <small style="opacity:.7;font-weight:500">(${file.size<1048576?Math.max(1,Math.round(file.size/1024))+' KB':(file.size/1048576).toFixed(1)+' MB'})</small></span>
      <button type="button" id="removeFileBtn">Hapus</button>
    </div>`;
  processBtn.disabled = false;
  document.getElementById('removeFileBtn').addEventListener('click', resetExcelStep);
}

processBtn.addEventListener('click', ()=>{
  if(!selectedFile) return;
  window.ImportFile.start(selectedFile);
});

cardsContainer.addEventListener('click',(e)=>{
  if(e.target.closest('.note-pop')) return;
  const b=e.target.closest('[data-act]');
  const card=e.target.closest('.card');
  const id=b?b.dataset.id:(card&&card.dataset.id);
  if(!id) return;
  const item=DATA.find(x=>x.id===id);
  if(!item) return;
  e.stopPropagation();
  if(b&&b.dataset.act==='del') window.Link.askDeleteDoc(item,function(){render();}); else if(b&&b.dataset.act==='edit') window.App.openEdit(item); else window.App.openDetail(item);
});
window.CariApi={DATA,render,refreshMantri:function(){MANTRI_LIST.length=0;window.MantriStore.forEach(function(m){MANTRI_LIST.push({code:m.kode,name:m.nama});});buildDropdowns();}};
})();
