/* Sinkronisasi dengan server Laravel/MySQL.
 * Seluruh halaman bekerja pada array data di memori (CariApi.DATA, MantriStore, LemariStore).
 * Modul ini: (1) memuat data dari database saat login, (2) mendeteksi perubahan dan menyimpannya via /api/sync. */
(function(){
  const metaCsrf=document.querySelector('meta[name="csrf-token"]');
  const metaBase=document.querySelector('meta[name="app-base"]');
  const BASE=(metaBase?metaBase.getAttribute('content'):'').replace(/\/$/,'');
  let csrf=metaCsrf?metaCsrf.getAttribute('content'):'';
  const A=window.App,DATA=window.CariApi.DATA,MS=window.MantriStore,LS=window.LemariStore;

  const DOC_KEYS=['id','nama','noPinjaman','cif','plafon','jenis','mantriFull','tglISO','berkas','jaminan','noJaminan','isiJaminan','status','statusJaminan','ketJaminan','incomplete','note','riwayat'];
  const pick=(o,ks)=>{const r={};ks.forEach(k=>{r[k]=o[k];});return r;};
  const docJson=d=>JSON.stringify(pick(d,DOC_KEYS));
  const mJson=m=>JSON.stringify({kode:m.kode,nama:m.nama,jabatan:m.jabatan||'',foto:m.foto||''});
  const lJson=l=>JSON.stringify({kode:l.kode,laci:l.laci.map(c=>({no:c.no,on:!!c.on}))});
  let snap={docs:new Map(),mantri:new Map(),lemari:new Map()};
  let ready=false,running=false,again=false,timer=null;

  function hydrate(d){
    d.mantri=(d.mantriFull||'').split(' ')[0];
    d.restruk=d.status==='Restruk';
    d.brimen=d.berkas.join('.')+(d.noJaminan?'':'//'+d.jaminan.join('.'));
    d.riwayat=d.riwayat||[];
    return d;
  }
  function takeSnapshot(){
    snap={docs:new Map(),mantri:new Map(),lemari:new Map()};
    DATA.forEach(d=>snap.docs.set(d.id,docJson(d)));
    MS.forEach(m=>snap.mantri.set(m.kode,mJson(m)));
    LS.forEach(l=>snap.lemari.set(l.kode,lJson(l)));
  }

  async function api(path,opt){
    opt=opt||{};
    const headers={'Accept':'application/json','X-Requested-With':'XMLHttpRequest','X-CSRF-TOKEN':csrf};
    if(opt.body)headers['Content-Type']='application/json';
    let res;
    try{res=await fetch(BASE+path,{method:opt.method||'GET',headers:headers,credentials:'same-origin',body:opt.body?JSON.stringify(opt.body):undefined});}
    catch(e){const err=new Error('Tidak dapat terhubung ke server');err.status=0;throw err;}
    let json=null;try{json=await res.json();}catch(e){}
    if(!res.ok){
      let msg=json&&json.message;
      if(json&&json.errors){const f=Object.values(json.errors)[0];if(f&&f[0])msg=f[0];}
      if(res.status===419)msg='Sesi berakhir. Muat ulang halaman lalu login kembali.';
      if(res.status===401)msg='Sesi login berakhir. Silakan login kembali.';
      if(res.status===429)msg='Terlalu banyak percobaan. Coba lagi sebentar lagi.';
      const err=new Error(msg||('Kesalahan server ('+res.status+')'));err.status=res.status;throw err;
    }
    return json;
  }

  async function load(){
    const j=await api('/api/bootstrap');
    MS.length=0;j.mantri.forEach(m=>MS.push({kode:m.kode,nama:m.nama,jabatan:m.jabatan,foto:m.foto||''}));
    LS.length=0;j.lemari.forEach(l=>LS.push(l));
    DATA.length=0;j.docs.forEach(d=>DATA.push(hydrate(d)));
    takeSnapshot();
    window.FormView.rebuildMantri();window.CariApi.refreshMantri();window.CariApi.render();
    return j;
  }

  async function flush(){
    if(!ready)return;
    if(running){again=true;return;}
    running=true;
    try{
      const up=[],del=[],mu=[],lu=[],cur=new Set();
      DATA.forEach(d=>{const j=docJson(d);cur.add(d.id);if(snap.docs.get(d.id)!==j)up.push(JSON.parse(j));});
      snap.docs.forEach((j,id)=>{if(!cur.has(id))del.push(id);});
      MS.forEach(m=>{const j=mJson(m);if(snap.mantri.get(m.kode)!==j)mu.push(JSON.parse(j));});
      LS.forEach(l=>{const j=lJson(l);if(snap.lemari.get(l.kode)!==j)lu.push(JSON.parse(j));});
      if(!up.length&&!del.length&&!mu.length&&!lu.length)return;
      await api('/api/sync',{method:'POST',body:{mantri:mu,lemari:lu,docs:{upserts:up,deletes:del}}});
      up.forEach(d=>snap.docs.set(d.id,JSON.stringify(d)));
      del.forEach(id=>snap.docs.delete(id));
      mu.forEach(m=>snap.mantri.set(m.kode,JSON.stringify(m)));
      lu.forEach(l=>snap.lemari.set(l.kode,JSON.stringify(l)));
    }catch(e){
      if(e.status===401||e.status===419){A.toast(e.message,'err');setTimeout(()=>Sync.reload(),1800);}
      else if(e.status===422){A.toast('Data ditolak server: '+e.message,'err');ready=false;setTimeout(()=>Sync.reload(),2600);}
      else A.toast('Gagal menyimpan ke server: '+e.message,'err');
    }finally{
      running=false;
      if(again){again=false;schedule(0);}
    }
  }
  function schedule(ms){
    if(!ready)return;
    clearTimeout(timer);
    timer=setTimeout(flush,ms==null?400:ms);
  }
  ['click','change'].forEach(ev=>document.addEventListener(ev,()=>schedule(),true));
  setInterval(()=>schedule(0),5000);
  const toast0=A.toast;
  A.toast=function(m,t){toast0.apply(this,arguments);if(t!=='err')schedule(300);};

  async function login(id,pw,remember){
    const j=await api('/login',{method:'POST',body:{id_petugas:id,password:pw,remember:!!remember}});
    if(j.csrf){csrf=j.csrf;if(metaCsrf)metaCsrf.setAttribute('content',csrf);}
    window.AppUser={id:j.user.id,name:j.user.name};
    await load();
    ready=true;
  }
  async function logout(){
    try{await api('/logout',{method:'POST'});}catch(e){}
    Sync.reload();
  }

  const Sync=window.Sync={login:login,logout:logout,load:load,flush:flush,reload:function(){location.reload();}};

  // Halaman dibuka saat sesi login masih aktif -> langsung muat data
  const boot=window.__BOOT__;
  if(boot&&boot.user){
    window.AppUser=boot.user;
    load().then(()=>{
      ready=true;
      document.body.classList.remove('logged-out');
      A.goDashboard();
    }).catch(e=>{
      document.body.classList.add('logged-out');
      A.show('login');
      A.toast(e.message,'err');
    });
  }
})();
