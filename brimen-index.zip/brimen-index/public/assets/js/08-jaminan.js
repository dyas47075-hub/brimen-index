(function(){
  const $=id=>document.getElementById(id);
  const A=window.App;
  const CAP=200,PAGE=20;
  const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const fmt=n=>String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g,'.');
  const BLN=['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Agu','Sep','Okt','Nov','Des'];
  const fdt=t=>{const x=new Date(t);return String(x.getDate()).padStart(2,'0')+' '+BLN[x.getMonth()]+' '+x.getFullYear()+' '+String(x.getHours()).padStart(2,'0')+'.'+String(x.getMinutes()).padStart(2,'0');};
  const ST=[
    {k:'Aktif',c:'#1f6d2b',bg:'#d7f3d7',sq:'#2e8b3f'},
    {k:'Lunas',c:'#1a4fa0',bg:'#dceaff',sq:'#1a6fe0'},
    {k:'Restruk',c:'#7a1230',bg:'#f6d9dc',sq:'#9c1f3b'},
    {k:'DH',c:'#b3162f',bg:'#fdecef',sq:'#e03131'},
    {k:'Diambil',c:'#4b5563',bg:'#e5e7eb',sq:'#9aa5b1'},
    {k:'Lemari Tahan Api',c:'#a14b00',bg:'#ffe8d1',sq:'#f08a00'},
    {k:'Notaris',c:'#6b3fa0',bg:'#ece3f8',sq:'#7b4bc0'},
    {k:'Dibawa Mantri',c:'#8a5a00',bg:'#fff1c9',sq:'#e0b100'}
  ];
  const SM={};ST.forEach(s=>SM[s.k]=s);
  const mkLaci=(n,off)=>{const a=[];for(let i=1;i<=n;i++)a.push({no:i,on:!(off&&off.indexOf(i)>-1)});return a;};
  const LEMARI=window.LemariStore=[]; // diisi dari database

  const stOf=d=>d.statusJaminan||'Aktif';
  const isFree=d=>stOf(d)==='Diambil';
  const nomor=d=>parseInt(d.jaminan[3],10)||0;
  const all=()=>window.CariApi.DATA.filter(d=>!d.noJaminan&&d.jaminan&&d.jaminan.length===4);
  const inLaci=(k,n)=>all().filter(d=>d.jaminan[1]===k&&parseInt(d.jaminan[2],10)===n);
  const known=(k,n)=>LEMARI.some(l=>l.kode===k&&l.laci.some(c=>c.no===n));

  /* ---------- halaman utama: lemari & laci ---------- */
  function renderGrid(){
    const js=all();
    const lun=js.filter(d=>stOf(d)==='Lunas').length,dia=js.filter(d=>stOf(d)==='Diambil').length;
    $('jmTotal').textContent=fmt(js.length);$('jmAktif').textContent=fmt(js.length-lun-dia);
    $('jmLunas').textContent=fmt(lun);$('jmDiambil').textContent=fmt(dia);
    const orphan=js.filter(d=>!known(d.jaminan[1],parseInt(d.jaminan[2],10)));
    const w=$('jmWarn');
    if(orphan.length){const ex=[];orphan.forEach(d=>{const c=d.jaminan[1]+'.'+d.jaminan[2];if(ex.indexOf(c)<0)ex.push(c);});
      w.textContent=orphan.length+' jaminan memakai kode lemari/laci yang belum terdaftar ('+ex.slice(0,5).join(', ')+'). Klik "Tambah Lemari" agar bisa dilihat di sini.';w.classList.remove('hidden');}
    else w.classList.add('hidden');
    $('jmGrid').innerHTML=LEMARI.map(l=>'<div class="jm-cab"><div class="jm-cab-h">Lemari '+esc(l.kode)+'</div>'+l.laci.map(c=>{
      const alls=inLaci(l.kode,c.no),n=alls.filter(x=>!isFree(x)).length,off=!c.on&&alls.length===0;
      return '<button type="button" class="jm-laci'+(off?' off':'')+'" data-k="'+esc(l.kode)+'" data-n="'+c.no+'" title="'+(off?'Laci tidak dipakai':n+' jaminan')+'"'+(off?' disabled':'')+'>Laci '+c.no+'</button>';
    }).join('')+'</div>').join('');
  }
  $('jmGrid').addEventListener('click',e=>{
    const b=e.target.closest('.jm-laci');if(!b||b.disabled)return;
    A.goLaci(b.dataset.k,parseInt(b.dataset.n,10));
  });

  /* ---------- detail laci ---------- */
  let cur=null,F={q:'',st:'all',sort:'asc',page:1};
  const resetF=()=>{F={q:'',st:'all',sort:'asc',page:1};$('jdSearch').value='';$('jdSort').value='asc';};
  function renderLaci(){
    if(!cur)return;
    const items=inLaci(cur.k,cur.n);
    const occ=items.filter(d=>!isFree(d)).length,freeN=items.length-occ;
    $('jdTitle').textContent='Lemari '+cur.k+' \u00B7 Laci '+cur.n;
    $('jdSub').textContent=occ+' jaminan terisi'+(freeN?' \u2022 '+freeN+' diambil (slot kosong)':'');
    const pct=Math.min(100,occ/CAP*100),col=pct>=95?'#c81e3a':pct>=80?'#f08a00':'#2e8b3f';
    $('jdCap').innerHTML='<div class="jd-lbl">Kapasitas laci</div><div><b>'+occ+'</b> <span>/ '+CAP+' jaminan</span></div><div class="jd-bar"><i style="width:'+pct+'%;background:'+col+'"></i></div><div class="jd-note">Terisi '+Math.round(pct)+'% \u2022 sisa '+Math.max(0,CAP-occ)+' slot</div>';
    const cnt={};items.forEach(d=>{cnt[stOf(d)]=(cnt[stOf(d)]||0)+1;});
    $('jdChips').innerHTML='<button type="button" class="jd-chip'+(F.st==='all'?' active':'')+'" data-st="all">Semua <b>'+items.length+'</b></button>'+ST.map(s=>'<button type="button" class="jd-chip'+(F.st===s.k?' active':'')+((cnt[s.k]||0)?'':' zero')+'" data-st="'+esc(s.k)+'"><i style="background:'+s.sq+'"></i>'+esc(s.k)+' <b>'+(cnt[s.k]||0)+'</b></button>').join('');
    const byNo={};items.forEach(d=>{byNo[nomor(d)]=d;});
    const max=Math.max(CAP,items.reduce((m,d)=>Math.max(m,nomor(d)),0));
    let map='';for(let i=1;i<=max;i++){const d=byNo[i];map+='<span class="jd-sq'+(d&&isFree(d)?' free':'')+'" data-no="'+i+'"'+(!d?' style="background:#e3ebf2"':(isFree(d)?'':' style="background:'+SM[stOf(d)].sq+'"'))+' title="No. '+i+(d?(isFree(d)?' \u2014 kosong (diambil: '+esc(d.nama)+')':' \u2014 '+esc(d.nama)+' ('+esc(stOf(d))+(stOf(d)==='Lunas'?', menunggu diambil':'')+')'):' \u2014 kosong')+'"></span>';}
    $('jdMap').innerHTML=map;
    const q=F.q.toLowerCase();
    let rows=items.filter(d=>(F.st==='all'||stOf(d)===F.st)&&(!q||(nomor(d)+' '+d.nama+' '+d.noPinjaman+' '+d.isiJaminan+' '+(d.ketJaminan||'')+' '+stOf(d)).toLowerCase().indexOf(q)>-1));
    rows.sort((a,b)=>F.sort==='desc'?nomor(b)-nomor(a):F.sort==='nama'?a.nama.localeCompare(b.nama):F.sort==='status'?(ST.findIndex(s=>s.k===stOf(a))-ST.findIndex(s=>s.k===stOf(b)))||nomor(a)-nomor(b):nomor(a)-nomor(b));
    const pages=Math.max(1,Math.ceil(rows.length/PAGE));if(F.page>pages)F.page=pages;
    const from=(F.page-1)*PAGE,slice=rows.slice(from,from+PAGE);
    $('jdBody').innerHTML=slice.length?slice.map(d=>{
      const s=SM[stOf(d)];
      return '<tr><td class="jd-no">'+nomor(d)+'</td><td><b>'+esc(d.nama)+'</b><div class="jd-sub">'+esc(d.noPinjaman)+'</div></td><td>'+esc(d.isiJaminan)+(d.ketJaminan?'<div class="jd-ket">'+esc(d.ketJaminan)+'</div>':'')+'</td>'+
        '<td><select class="jd-stsel" data-id="'+esc(d.id)+'" style="background-color:'+s.bg+';color:'+s.c+'">'+ST.map(x=>'<option value="'+esc(x.k)+'"'+(x.k===s.k?' selected':'')+'>'+esc(x.k)+'</option>').join('')+'</select></td>'+
        '<td class="jd-act"><button type="button" class="icon-btn icon-view" data-act="view" data-id="'+esc(d.id)+'" title="Lihat dokumen"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7Z"/><circle cx="12" cy="12" r="3"/></svg></button> '+
        (isFree(d)?'<button type="button" class="icon-btn icon-del" data-act="del" data-id="'+esc(d.id)+'" title="Hapus jaminan (diambil)"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14M10 11v6M14 11v6"/></svg></button> ':'')+'<button type="button" class="icon-btn icon-edit" data-act="edit" data-id="'+esc(d.id)+'" title="Edit jaminan"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg></button></td></tr>';
    }).join(''):'<tr><td colspan="5" class="empty">Tidak ada jaminan yang cocok.</td></tr>';
    $('jdPager').innerHTML=rows.length?'<span>Menampilkan '+(from+1)+'\u2013'+(from+slice.length)+' dari '+rows.length+'</span><div><button type="button" class="jd-pg" data-p="prev"'+(F.page<=1?' disabled':'')+'>&lsaquo; Sebelumnya</button><span class="jd-pgn">Hal '+F.page+' / '+pages+'</span><button type="button" class="jd-pg" data-p="next"'+(F.page>=pages?' disabled':'')+'>Berikutnya &rsaquo;</button></div>':'';
  }
  const byId=id=>window.CariApi.DATA.find(x=>x.id===id);
  const ret=()=>A.goLaci(cur.k,cur.n);
  $('jdChips').addEventListener('click',e=>{const b=e.target.closest('.jd-chip');if(!b)return;F.st=b.dataset.st;F.page=1;renderLaci();});
  $('jdSearch').addEventListener('input',e=>{F.q=e.target.value.trim();F.page=1;renderLaci();});
  $('jdSort').addEventListener('change',e=>{F.sort=e.target.value;F.page=1;renderLaci();});
  $('jdPager').addEventListener('click',e=>{const b=e.target.closest('.jd-pg');if(!b||b.disabled)return;F.page+=b.dataset.p==='next'?1:-1;renderLaci();});
  $('jdBack').addEventListener('click',()=>A.goJaminan());
  $('jdBody').addEventListener('click',e=>{
    const b=e.target.closest('[data-act]');if(!b)return;
    const d=byId(b.dataset.id);if(!d)return;
    if(b.dataset.act==='del'){askDelJam(d);return;}
    if(b.dataset.act==='edit')openEdit(d);else A.openDetail(d,ret,'jaminan');
  });
  $('jdBody').addEventListener('change',e=>{
    const s=e.target.closest('.jd-stsel');if(!s)return;
    const d=byId(s.dataset.id);if(!d)return;
    apply(d,{isi:d.isiJaminan,st:s.value,ket:d.ketJaminan||''});
  });
  $('jdMap').addEventListener('click',e=>{
    const q=e.target.closest('.jd-sq');if(!q)return;
    const no=parseInt(q.dataset.no,10),d=inLaci(cur.k,cur.n).find(x=>nomor(x)===no);
    if(d)openEdit(d);else A.toast('No. '+no+' masih kosong. Tambahkan lewat Input File dengan BRIMEN jaminan I.'+cur.k+'.'+cur.n+'.'+no);
  });

  /* ---------- edit jaminan ---------- */
  let editing=null;
  function openEdit(d){
    editing=d;
    $('jmInfo').innerHTML='<b>'+esc(d.nama)+'</b><br>'+esc(d.noPinjaman)+' \u2022 BRIMEN jaminan '+esc(d.jaminan.join('.'))+'<br>Status berkas: <b>'+esc(d.status)+'</b>';
    $('jmDel').style.display=isFree(d)?'':'none';
    $('jmIsi').value=d.isiJaminan||'';$('jmIsi').classList.remove('err');
    $('jmSt').innerHTML=ST.map(x=>'<option value="'+esc(x.k)+'"'+(x.k===stOf(d)?' selected':'')+'>'+esc(x.k)+'</option>').join('');
    $('jmKet').value=d.ketJaminan||'';
    const h=(d.riwayat||[]).slice(0,5);
    $('jmHist').innerHTML=h.length?h.map(r=>'<div><span>'+fdt(r.t)+'</span> '+esc(r.x)+'</div>').join(''):'<div class="jm-nohist">Belum ada perubahan.</div>';
    $('jmModal').classList.remove('hidden');setTimeout(()=>$('jmIsi').focus(),30);
  }
  const closeEdit=()=>{$('jmModal').classList.add('hidden');editing=null;};
  $('jmClose').addEventListener('click',closeEdit);
  $('jmCancel').addEventListener('click',closeEdit);
  $('jmModal').addEventListener('click',e=>{if(e.target===$('jmModal'))closeEdit();});
  function apply(d,v){
    const ch=[],cut=s=>String(s).length>40?String(s).slice(0,40)+'\u2026':String(s);
    if(window.Link.LOAN.indexOf(v.st)>-1&&d.status==='Lunas'&&v.st!=='Lunas'){const bo=window.Link.berkasOwner(d.berkas,d.cif,d.id,v.st);if(bo){A.toast('BRIMEN berkas '+d.berkas.join('.')+' sudah dipakai '+bo.nama+', status tidak bisa diubah dari Lunas','err');renderLaci();return false;}}
    if(stOf(d)==='Diambil'&&v.st!=='Diambil'){const so=window.Link.slotOwner(d.jaminan,d.id);if(so){A.toast('Slot '+d.jaminan.join('.')+' sudah dipakai '+so.nama+', jaminan ini tidak bisa diaktifkan kembali','err');renderLaci();return false;}}
    if(v.isi!==(d.isiJaminan||''))ch.push('Isi jaminan: "'+cut(d.isiJaminan||'')+'" \u2192 "'+cut(v.isi)+'"');
    if(v.st!==stOf(d))ch.push('Status: '+stOf(d)+' \u2192 '+v.st);
    if(v.ket!==(d.ketJaminan||''))ch.push('Keterangan diubah');
    if(!ch.length){A.toast('Tidak ada perubahan');renderLaci();return false;}
    d.isiJaminan=v.isi;d.statusJaminan=v.st;d.ketJaminan=v.ket;
    if(window.Link.LOAN.indexOf(v.st)>-1&&d.status!==v.st){ch.push('Status berkas: '+d.status+' \u2192 '+v.st);window.Link.setBerkas(d,v.st);}
    d.riwayat=d.riwayat||[];d.riwayat.unshift({t:Date.now(),x:ch.join('; ')});if(d.riwayat.length>20)d.riwayat.length=20;
    renderLaci();renderGrid();A.toast('Jaminan '+d.nama+' diperbarui');return true;
  }
  $('jmSave').addEventListener('click',()=>{
    if(!editing)return;
    const isi=$('jmIsi').value.replace(/\s+/g,' ').trim();
    if(!isi){$('jmIsi').classList.add('err');A.toast('Isi jaminan wajib diisi','err');return;}
    const d=editing;
    if(apply(d,{isi:isi,st:$('jmSt').value,ket:$('jmKet').value.replace(/\s+/g,' ').trim()}))closeEdit();
  });

  function askDelJam(d){
    if(!isFree(d)){A.toast('Hanya jaminan berstatus Diambil yang bisa dihapus','err');return;}
    window.Link.confirm({title:'Hapus data jaminan?',msg:d.nama+' \u2022 No. '+nomor(d)+' di Lemari '+d.jaminan[1]+' Laci '+d.jaminan[2],warn:'Slot ini dikosongkan permanen. Data berkas debitur tetap ada (ditandai tanpa jaminan fisik).',yes:'Hapus jaminan'},function(){
      window.Link.deleteJaminan(d);closeEdit();renderLaci();renderGrid();A.toast('Jaminan '+d.nama+' dihapus, slot dikosongkan');
    });
  }
  $('jmDel').addEventListener('click',()=>{if(editing)askDelJam(editing);});

  /* ---------- tambah lemari ---------- */
  const openAdd=()=>{$('lmKode').value='';$('lmJumlah').value='4';$('lmKode').classList.remove('err');$('lmModal').classList.remove('hidden');setTimeout(()=>$('lmKode').focus(),30);};
  const closeAdd=()=>$('lmModal').classList.add('hidden');
  $('jmAdd').addEventListener('click',openAdd);
  $('lmClose').addEventListener('click',closeAdd);
  $('lmCancel').addEventListener('click',closeAdd);
  $('lmModal').addEventListener('click',e=>{if(e.target===$('lmModal'))closeAdd();});
  $('lmSave').addEventListener('click',()=>{
    const kode=$('lmKode').value.trim().toUpperCase(),n=parseInt($('lmJumlah').value,10);
    $('lmKode').classList.remove('err');
    if(!/^[A-Z0-9]{1,3}$/.test(kode)){$('lmKode').classList.add('err');A.toast('Kode lemari 1\u20133 huruf/angka, mis. Q','err');return;}
    if(LEMARI.some(l=>l.kode===kode)){$('lmKode').classList.add('err');A.toast('Lemari '+kode+' sudah ada','err');return;}
    if(!(n>=1&&n<=12)){A.toast('Jumlah laci 1\u201312','err');return;}
    LEMARI.push({kode:kode,laci:mkLaci(n)});renderGrid();closeAdd();A.toast('Lemari '+kode+' ditambahkan dengan '+n+' laci');
  });

  /* ---------- navigasi ---------- */
  A.goJaminan=function(){renderGrid();A.show('jaminan');A.setNav('jaminan');};
  A.goLaci=function(k,n){
    if(!cur||cur.k!==k||cur.n!==n)resetF();
    cur={k:k,n:n};renderLaci();A.show('jaminanDetail');A.setNav('jaminan');
  };
})();
