(function(){
  const $=id=>document.getElementById(id);
  const A=window.App;
  const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const fmt=n=>String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g,'.');
  const num=s=>parseInt(String(s).replace(/\D/g,''),10)||0;
  const tr=s=>s.replace('.',',').replace(/,?0+$/,'');
  const rp=(n,d)=>n>=1e9?'Rp '+tr((n/1e9).toFixed(2))+' M':'Rp '+(d?tr((n/1e6).toFixed(1)):fmt(n/1e6))+' Jt';
  const pct1=x=>(Math.round(x*10)/10).toFixed(1).replace('.',',').replace(/,0$/,'')+'%';
  const MS=['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Agu','Sep','Okt','Nov','Des'];
  const JENIS=['KUR','KUPERA','KUPEDES','KECE','GBT'];
  const JC={KUR:'#155c22',KUPERA:'#2e8b3f',KUPEDES:'#8fd19e',KECE:'#1a6fe0',GBT:'#f0b429'};
  const SC={Aktif:'#2e8b3f',Lunas:'#1a6fe0',Restruk:'#9c1f3b',DH:'#e03131'};
  const JST=[['Aktif','#2e8b3f'],['Lunas','#1a6fe0'],['Restruk','#9c1f3b'],['DH','#e03131'],['Diambil','#9aa5b1'],['Lemari Tahan Api','#f08a00'],['Notaris','#7b4bc0'],['Dibawa Mantri','#e0b100']];
  const F={year:null,mantri:'',jenis:''};

  function nice(max,ticks,int){
    if(!(max>0))return{top:ticks,step:1};
    const raw=max/ticks,mag=Math.pow(10,Math.floor(Math.log10(raw))),nm=raw/mag;
    let step=(nm<=1?1:nm<=2?2:nm<=5?5:10)*mag;if(int)step=Math.max(1,Math.ceil(step));
    return{top:step*ticks,step:step};
  }
  function trend(cnt,plaf){
    const W=760,H=270,ml=40,mr=58,mt=16,mb=32,pw=W-ml-mr,ph=H-mt-mb,cw=pw/12;
    const nc=nice(Math.max.apply(null,cnt),4,true),np=nice(Math.max.apply(null,plaf)/1e6,4,false);
    let s='<svg viewBox="0 0 '+W+' '+H+'" class="st-svg" role="img" aria-label="Tren bulanan">';
    for(let i=0;i<=4;i++){
      const y=mt+ph-(i/4)*ph;
      s+='<line x1="'+ml+'" x2="'+(W-mr)+'" y1="'+y+'" y2="'+y+'" stroke="#e3ebf2" stroke-dasharray="3 3"/>'
        +'<text x="'+(ml-8)+'" y="'+(y+4)+'" text-anchor="end">'+(i*nc.step)+'</text>'
        +'<text x="'+(W-mr+8)+'" y="'+(y+4)+'">'+fmt(i*np.step)+'</text>';
    }
    let pts=[],dots='';
    for(let i=0;i<12;i++){
      const cx=ml+i*cw+cw/2,bh=cnt[i]/nc.top*ph;
      s+='<rect x="'+(cx-cw*0.25)+'" y="'+(mt+ph-bh)+'" width="'+(cw*0.5)+'" height="'+bh+'" rx="4" fill="#0b559f"><title>'+MS[i]+': '+cnt[i]+' dokumen</title></rect>'
        +'<text x="'+cx+'" y="'+(H-10)+'" text-anchor="middle">'+MS[i]+'</text>';
      const py=mt+ph-(plaf[i]/1e6/np.top)*ph;pts.push(cx+','+py);
      dots+='<circle cx="'+cx+'" cy="'+py+'" r="4" fill="#fff" stroke="#ff9800" stroke-width="2.5"><title>'+MS[i]+': '+rp(plaf[i],true)+'</title></circle>';
    }
    return s+'<polyline points="'+pts.join(' ')+'" fill="none" stroke="#ff9800" stroke-width="2.5" stroke-linejoin="round"/>'+dots+'</svg>';
  }
  function donut(parts,top,sub){
    const tot=parts.reduce((s,p)=>s+p.v,0),R=44,C=2*Math.PI*R;let off=0;
    let s='<svg viewBox="0 0 120 120" class="st-donut"><circle cx="60" cy="60" r="'+R+'" fill="none" stroke="#e8eff5" stroke-width="16"/>';
    if(tot>0)parts.forEach(p=>{if(!p.v)return;const len=p.v/tot*C;
      s+='<circle cx="60" cy="60" r="'+R+'" fill="none" stroke="'+p.c+'" stroke-width="16" stroke-dasharray="'+len+' '+(C-len)+'" stroke-dashoffset="'+(-off)+'" transform="rotate(-90 60 60)"><title>'+esc(p.l)+': '+p.v+'</title></circle>';off+=len;});
    return s+'<text x="60" y="59" text-anchor="middle" class="dc-t">'+top+'</text><text x="60" y="74" text-anchor="middle" class="dc-s">'+sub+'</text></svg>';
  }
  function legend(parts){
    const tot=parts.reduce((s,p)=>s+p.v,0);
    return '<div class="st-leg">'+parts.map(p=>'<div><i style="background:'+p.c+'"></i><span>'+esc(p.l)+'</span><b>'+fmt(p.v)+'</b><em>'+pct1(tot?p.v/tot*100:0)+'</em></div>').join('')+'</div>';
  }
  function hbars(rows,empty){
    const max=Math.max.apply(null,rows.map(r=>r.v).concat([0]));
    if(!rows.length||max===0)return '<div class="empty">'+(empty||'Belum ada data.')+'</div>';
    return rows.map(r=>'<div class="st-hb" title="'+esc(r.tip||'')+'"><span class="st-hl">'+esc(r.l)+'</span><div class="st-trk"><i style="width:'+(r.v/max*100)+'%;background:'+r.c+'"></i></div><b>'+r.txt+'</b></div>').join('');
  }

  function years(){
    const set={};window.CariApi.DATA.forEach(d=>{set[d.tglISO.slice(0,4)]=1;});
    return Object.keys(set).sort().reverse();
  }
  function buildFilters(){
    const ys=years();if(!F.year||ys.indexOf(String(F.year))<0)F.year=ys[0]||String(new Date().getFullYear());
    $('stYear').innerHTML=(ys.length?ys:[F.year]).map(y=>'<option value="'+y+'"'+(String(F.year)===y?' selected':'')+'>Tahun '+y+'</option>').join('');
    $('stMantri').innerHTML='<option value="">Semua mantri</option>'+window.MantriStore.map(m=>'<option value="'+esc(m.nama)+'"'+(F.mantri===m.nama?' selected':'')+'>'+esc(m.nama)+'</option>').join('');
    $('stJenis').innerHTML='<option value="">Semua jenis pinjaman</option>'+JENIS.map(j=>'<option value="'+j+'"'+(F.jenis===j?' selected':'')+'>'+j+'</option>').join('');
  }

  function render(){
    const D=window.CariApi.DATA.filter(d=>d.tglISO.slice(0,4)===String(F.year)&&(!F.mantri||d.mantriFull===F.mantri)&&(!F.jenis||d.jenis===F.jenis));
    const n=D.length,plafon=D.reduce((s,d)=>s+num(d.plafon),0),comp=D.filter(d=>!d.incomplete).length,rs=D.filter(d=>d.status==='Restruk').length;
    const kp=[
      {l:'Total Dokumen',v:fmt(n),s:'Tahun '+F.year,c:'#0b559f'},
      {l:'Total Plafon',v:rp(plafon),s:'dari '+fmt(n)+' dokumen',c:'#ff9800',t:'Rp '+fmt(plafon)},
      {l:'Rata-rata Plafon',v:n?rp(plafon/n,true):'Rp 0 Jt',s:'per dokumen',c:'#7b4bc0',t:n?'Rp '+fmt(plafon/n):''},
      {l:'Berkas Lengkap',v:pct1(n?comp/n*100:0),s:fmt(n-comp)+' belum lengkap',c:'#2e8b3f'},
      {l:'Restruk',v:fmt(rs),s:pct1(n?rs/n*100:0)+' dari dokumen',c:'#9c1f3b'}
    ];
    $('stKpis').innerHTML=kp.map(k=>'<div class="st-kpi" style="border-left-color:'+k.c+'" title="'+esc(k.t||'')+'"><span>'+k.l+'</span><b>'+k.v+'</b><em>'+k.s+'</em></div>').join('');

    const cnt=Array(12).fill(0),plaf=Array(12).fill(0);
    D.forEach(d=>{const m=parseInt(d.tglISO.slice(5,7),10)-1;cnt[m]++;plaf[m]+=num(d.plafon);});
    $('stTrendSub').textContent='Tahun '+F.year;
    $('stTrend').innerHTML=n?trend(cnt,plaf):'<div class="empty">Tidak ada data pada filter ini.</div>';

    const sp=['Aktif','Lunas','Restruk','DH'].map(k=>({l:k,v:D.filter(d=>d.status===k).length,c:SC[k]}));
    $('stStatus').innerHTML='<div class="st-dwrap">'+donut(sp,fmt(n),'dokumen')+legend(sp)+'</div>';

    $('stJenisChart').innerHTML=hbars(JENIS.map(j=>{const r=D.filter(d=>d.jenis===j),p=r.reduce((s,d)=>s+num(d.plafon),0);return{l:j,v:p,c:JC[j],txt:rp(p)+' <small>\u00B7 '+r.length+' dok</small>',tip:'Rp '+fmt(p)};}),'Tidak ada data pada filter ini.');

    const inc=D.filter(d=>d.incomplete),lp=[{l:'Lengkap',v:comp,c:'#2e8b3f'},{l:'Belum lengkap',v:inc.length,c:'#c81e3a'}];
    const cause={};inc.forEach(d=>{const k=(d.note||'').trim()||'Tanpa catatan';cause[k]=(cause[k]||0)+1;});
    const cl=Object.keys(cause).sort((a,b)=>cause[b]-cause[a]).slice(0,4);
    $('stLengkap').innerHTML='<div class="st-dwrap">'+donut(lp,pct1(n?comp/n*100:0),'lengkap')+legend(lp)+'</div>'+
      '<div class="st-sub2">Catatan belum lengkap terbanyak</div>'+(cl.length?cl.map(k=>'<div class="st-cause"><span>'+esc(k)+'</span><b>'+cause[k]+'</b></div>').join(''):'<div class="empty" style="padding:8px 0">Semua berkas lengkap.</div>');

    const mr=window.MantriStore.map(m=>{const r=D.filter(d=>d.mantriFull===m.nama);return{m:m,n:r.length,p:r.reduce((s,d)=>s+num(d.plafon),0),i:r.filter(d=>d.incomplete).length};}).filter(x=>x.n>0).sort((a,b)=>b.p-a.p);
    const maxP=mr.length?mr[0].p:1;
    $('stMantriTbl').innerHTML=mr.length?'<table class="st-tbl"><thead><tr><th>#</th><th>Mantri</th><th>Nasabah</th><th>Total Plafon</th><th>Belum Lengkap</th><th>Porsi Plafon</th></tr></thead><tbody>'+mr.map((x,i)=>{
      const av=x.m.foto?'<span class="st-av" style="background-image:url(\''+x.m.foto+'\')"></span>':'<span class="st-av">'+esc(x.m.nama.split(' ').slice(0,2).map(w=>w[0]).join(''))+'</span>';
      return '<tr data-kode="'+esc(x.m.kode)+'"><td>'+(i+1)+'</td><td><div class="st-mn">'+av+esc(x.m.nama)+'</div></td><td>'+fmt(x.n)+'</td><td>'+rp(x.p)+'</td><td>'+x.i+' <small>('+pct1(x.n?x.i/x.n*100:0)+')</small></td><td><div class="st-trk sm"><i style="width:'+(x.p/maxP*100)+'%"></i></div></td></tr>';
    }).join('')+'</tbody></table>':'<div class="empty">Tidak ada data pada filter ini.</div>';

    const jm=D.filter(d=>!d.noJaminan);
    $('stJamSub').textContent=fmt(jm.length)+' jaminan';
    $('stJamStatus').innerHTML=hbars(JST.map(s=>{const c=jm.filter(d=>(d.statusJaminan||'Aktif')===s[0]).length;return{l:s[0],v:c,c:s[1],txt:fmt(c)+' <small>('+pct1(jm.length?c/jm.length*100:0)+')</small>'};}),'Tidak ada jaminan pada filter ini.');

    const allJ=window.CariApi.DATA.filter(d=>!d.noJaminan&&d.jaminan&&d.jaminan.length===4);
    $('stOkupansi').innerHTML=(window.LemariStore||[]).map(l=>{
      const items=allJ.filter(d=>d.jaminan[1]===l.kode&&(d.statusJaminan||'Aktif')!=='Diambil').length;
      const lacis=l.laci.filter(c=>c.on||allJ.some(d=>d.jaminan[1]===l.kode&&parseInt(d.jaminan[2],10)===c.no)).length,cap=lacis*200,pc=cap?items/cap*100:0;
      const col=pc>=95?'#c81e3a':pc>=80?'#f08a00':'#2e8b3f';
      return '<div class="st-hb st-ok" title="'+lacis+' laci aktif \u00D7 200"><span class="st-hl">Lemari '+esc(l.kode)+'</span><div class="st-trk"><i style="width:'+Math.min(100,pc)+'%;background:'+col+'"></i></div><b>'+fmt(items)+' / '+fmt(cap)+' <small>('+pct1(pc)+')</small></b></div>';
    }).join('')||'<div class="empty">Belum ada lemari.</div>';
  }

  $('stYear').addEventListener('change',e=>{F.year=e.target.value;render();});
  $('stMantri').addEventListener('change',e=>{F.mantri=e.target.value;render();});
  $('stJenis').addEventListener('change',e=>{F.jenis=e.target.value;render();});
  $('stReset').addEventListener('click',()=>{F.year=null;F.mantri='';F.jenis='';buildFilters();render();});
  $('stMantriTbl').addEventListener('click',e=>{const r=e.target.closest('tr[data-kode]');if(r)A.goMantriDetail(r.dataset.kode);});
  $('stOkupansi').addEventListener('click',()=>A.goJaminan());
  A.goStatistik=function(){buildFilters();render();A.show('statistik');A.setNav('statistik');};
})();
