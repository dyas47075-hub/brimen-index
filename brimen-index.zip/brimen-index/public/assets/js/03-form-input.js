(function(){
/* ---- generic listbox dropdowns ---- */
function wireListbox(btnId, listId, valId){
  const btn = document.getElementById(btnId);
  const list = document.getElementById(listId);
  const val = document.getElementById(valId);
  btn.addEventListener('click', (e)=>{
    e.stopPropagation();
    closeAllPopups(list);
    list.classList.toggle('hidden');
  });
  list.querySelectorAll('.lb-item').forEach(item=>{
    item.addEventListener('click', (e)=>{
      e.stopPropagation();
      list.querySelectorAll('.lb-item').forEach(i=>i.classList.remove('sel'));
      item.classList.add('sel');
      val.textContent = item.dataset.val;
      val.classList.remove('ph');
      list.classList.add('hidden');
    });
  });
}
function closeAllPopups(except){
  document.querySelectorAll('.listbox, .calendar-pop').forEach(p=>{
    if(p !== except) p.classList.add('hidden');
  });
}
document.addEventListener('click', ()=> closeAllPopups(null));

wireListbox('jenisBtn','jenisList','jenisVal');
wireListbox('fMantriBtn','mantriList','mantriVal');
wireListbox('statusBtn','statusList','statusVal');

/* ---- calendar ---- */
const calPop = document.getElementById('calendarPop');
const calTitle = document.getElementById('calTitle');
const calGrid = document.getElementById('calGrid');
const tglBtn = document.getElementById('tglBtn');
const tglVal = document.getElementById('tglVal');
const MONTHS_ID = ["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"];
const DOW = ["Min","Sen","Sel","Rab","Kam","Jum","Sab"];
let viewDate = new Date();
let selectedDate = null;
const today = new Date(); today.setHours(0,0,0,0);

function renderCalendar(){
  calTitle.textContent = MONTHS_ID[viewDate.getMonth()] + " " + viewDate.getFullYear();
  calGrid.innerHTML = '';
  DOW.forEach(d=>{
    const el = document.createElement('div');
    el.className = 'cal-dow'; el.textContent = d;
    calGrid.appendChild(el);
  });
  const firstDay = new Date(viewDate.getFullYear(), viewDate.getMonth(), 1);
  const startOffset = firstDay.getDay();
  const daysInMonth = new Date(viewDate.getFullYear(), viewDate.getMonth()+1, 0).getDate();
  for(let i=0;i<startOffset;i++){
    const el = document.createElement('div'); el.className='cal-day muted'; calGrid.appendChild(el);
  }
  for(let d=1; d<=daysInMonth; d++){
    const el = document.createElement('div');
    el.className = 'cal-day';
    el.textContent = d;
    const thisDate = new Date(viewDate.getFullYear(), viewDate.getMonth(), d);
    if(thisDate.getTime() === today.getTime()) el.classList.add('today');
    if(selectedDate && thisDate.getTime() === selectedDate.getTime()) el.classList.add('selected');
    el.addEventListener('click', (e)=>{
      e.stopPropagation();
      selectedDate = thisDate;
      tglVal.textContent = String(d).padStart(2,'0') + ' ' + MONTHS_ID[viewDate.getMonth()] + ' ' + viewDate.getFullYear();
      tglVal.classList.remove('ph');
      calPop.classList.add('hidden');
      renderCalendar();
    });
    calGrid.appendChild(el);
  }
}
tglBtn.addEventListener('click',(e)=>{
  e.stopPropagation();
  closeAllPopups(calPop);
  calPop.classList.toggle('hidden');
  renderCalendar();
});
document.getElementById('calPrev').addEventListener('click',(e)=>{e.stopPropagation(); viewDate.setMonth(viewDate.getMonth()-1); renderCalendar();});
document.getElementById('calNext').addEventListener('click',(e)=>{e.stopPropagation(); viewDate.setMonth(viewDate.getMonth()+1); renderCalendar();});
calPop.addEventListener('click',(e)=>e.stopPropagation());
renderCalendar();

/* ---- checkboxes ---- */
function wireCheckbox(rowId, chkId, onChange){
  const row = document.getElementById(rowId);
  const chk = document.getElementById(chkId);
  let checked = false;
  row.addEventListener('click', ()=>{
    checked = !checked;
    chk.classList.toggle('checked', checked);
    if(onChange) onChange(checked);
  });
  return {set(v){checked=v;chk.classList.toggle('checked',v);if(onChange)onChange(v);},get(){return checked;}};
}
const belumChk = wireCheckbox('belumLengkapRow','belumLengkapChk');

const jaminanGroup = document.getElementById('jaminanGroup');
const statusField = document.getElementById('statusField');
const isiJaminanField = document.getElementById('isiJaminanField');
const brimenSection = document.getElementById('brimenSection');

const noJamChk = wireCheckbox('noJaminanRow','noJaminanChk', (checked)=>{
  if(checked){
    jaminanGroup.style.display = 'none';
    isiJaminanField.style.display = 'none';
    brimenSection.style.gridTemplateColumns = '1fr 1fr';
  } else {
    jaminanGroup.style.display = '';
    isiJaminanField.style.display = '';
    brimenSection.style.gridTemplateColumns = '1fr 1fr 1.1fr';
  }
});

/* ---- No. pinjaman: ketik biasa, otomatis diberi tanda hubung saat 15 digit ---- */
const noPinjaman = document.getElementById('noPinjaman');
noPinjaman.addEventListener('input', ()=>{
  const d = noPinjaman.value.replace(/\D/g,'').slice(0,15);
  noPinjaman.value = d.length === 15
    ? `${d.slice(0,4)}-${d.slice(4,6)}-${d.slice(6,12)}-${d.slice(12,14)}-${d.slice(14)}`
    : d;
});

/* ---- Plafon: pemisah ribuan otomatis ---- */
const plafon = document.getElementById('plafon');
plafon.addEventListener('input', ()=>{
  const d = plafon.value.replace(/\D/g,'').replace(/^0+(?=\d)/,'');
  plafon.value = d ? d.replace(/\B(?=(\d{3})+(?!\d))/g,'.') : '';
});

/* ---- BRIMEN: pindah otomatis ke kotak berikutnya ---- */
const boxes = [...document.querySelectorAll('.bb input')];
const isVisible = el => el.offsetParent !== null;
function focusNext(i){
  for(let j=i+1;j<boxes.length;j++){ if(isVisible(boxes[j])){ boxes[j].focus(); return; } }
}
function focusPrev(i){
  for(let j=i-1;j>=0;j--){ if(isVisible(boxes[j])){ boxes[j].focus(); boxes[j].select(); return; } }
}
boxes.forEach((inp,i)=>{
  const isBerkas = (i % 4) === 3;          // kotak ke-4 tiap grup (bisa lebih dari 1 karakter)
  inp.maxLength = isBerkas ? 3 : 1;
  inp.autocomplete = 'off';
  inp.addEventListener('input', ()=>{
    inp.value = inp.value.toUpperCase();
    if(!isBerkas && inp.value.length === 1) focusNext(i);
  });
  inp.addEventListener('keydown', (e)=>{
    if(e.key === 'Enter'){ e.preventDefault(); focusNext(i); }
    if(e.key === 'Backspace' && inp.value === ''){ e.preventDefault(); focusPrev(i); }
  });
  inp.addEventListener('focus', ()=> inp.select());
});


/* ===== FormView API ===== */
const $ = id => document.getElementById(id);
function setSelect(valId,listId,v){
  const val=$(valId),list=$(listId);
  list.querySelectorAll('.lb-item').forEach(i=>i.classList.toggle('sel',i.dataset.val===v));
  if(v){val.textContent=v;val.classList.remove('ph');}
  else{val.textContent=list.querySelector('.lb-header').textContent;val.classList.add('ph');}
}
const getSelect = valId => $(valId).classList.contains('ph') ? '' : $(valId).textContent.trim();
const fmtDate = d => String(d.getDate()).padStart(2,'0')+' '+MONTHS_ID[d.getMonth()]+' '+d.getFullYear();
function setDate(d){
  selectedDate=d;
  if(d){viewDate=new Date(d);tglVal.textContent=fmtDate(d);tglVal.classList.remove('ph');}
  else{tglVal.textContent='Pilih tanggal';tglVal.classList.add('ph');viewDate=new Date();}
  renderCalendar();
}
let editingId=null;
function clearErrors(){document.querySelectorAll('#view-form .err').forEach(e=>e.classList.remove('err'));}
document.getElementById('view-form').addEventListener('input',e=>e.target.classList.remove('err'));
function setMode(mode){
  editingId=null;
  if(mode==='edit'){$('formTitle').textContent='Edit data';$('formSub').textContent='Perbarui informasi dokumen, lalu simpan perubahan';$('btnSimpan').textContent='Simpan perubahan';}
  else{$('formTitle').textContent='Input dokumen baru';$('formSub').textContent='Lengkapi semua field yang wajib diisi';$('btnSimpan').textContent='Simpan dokumen';}
}
function reset(){
  ['fNama','noPinjaman','fCif','plafon','fIsi','fNote'].forEach(id=>$(id).value='');
  boxes.forEach(b=>b.value='');
  setSelect('jenisVal','jenisList','');setSelect('mantriVal','mantriList','');setSelect('statusVal','statusList','');
  setDate(null);noJamChk.set(false);belumChk.set(false);clearErrors();
}
function fill(d){
  reset();editingId=d.id;
  $('fNama').value=d.nama;$('noPinjaman').value=d.noPinjaman;$('fCif').value=d.cif;$('plafon').value=d.plafon;
  setSelect('jenisVal','jenisList',d.jenis);setSelect('mantriVal','mantriList',d.mantriFull);setSelect('statusVal','statusList',d.status||'');
  setDate(new Date(d.tglISO+'T00:00:00'));
  (d.berkas||[]).forEach((v,i)=>boxes[i].value=v||'');
  noJamChk.set(!!d.noJaminan);
  if(!d.noJaminan){(d.jaminan||[]).forEach((v,i)=>boxes[4+i].value=v||'');$('fIsi').value=d.isiJaminan||'';}
  $('fNote').value=d.note||'';belumChk.set(!!d.incomplete);
}
function collect(){
  clearErrors();
  const errors=[];
  const need=(ok,label,el)=>{if(!ok){errors.push(label);if(el)el.classList.add('err');}};
  const nama=$('fNama').value.trim(),np=$('noPinjaman').value,cif=$('fCif').value.trim(),pl=$('plafon').value;
  const jenis=getSelect('jenisVal'),mantri=getSelect('mantriVal'),status=getSelect('statusVal'),noJam=noJamChk.get();
  need(nama,'Nama debitur',$('fNama'));
  need(np.replace(/\D/g,'').length===15,'No. pinjaman (15 digit)',$('noPinjaman'));
  if(np.replace(/\D/g,'').length===15){const nd=window.Link.nopOwner(np,editingId);if(nd){errors.push('No. pinjaman sudah dipakai '+nd.nama);$('noPinjaman').classList.add('err');}}
  need(jenis,'Jenis pinjaman',$('jenisBtn'));
  need(pl,'Plafon',$('plafon'));
  need(cif,'CIF',$('fCif'));
  need(mantri,'Mantri',$('fMantriBtn'));
  need(selectedDate,'Tanggal realisasi',$('tglBtn'));
  const grp=(arr,label)=>{const v=arr.map(b=>b.value.trim());if(!v.every(Boolean)){errors.push(label);arr.forEach(b=>!b.value.trim()&&b.classList.add('err'));}return v;};
  const berkas=grp(boxes.slice(0,4),'BRIMEN berkas');
  let jaminan=[],isi='';
  if(!noJam){jaminan=grp(boxes.slice(4),'BRIMEN jaminan');isi=$('fIsi').value.trim();need(isi,'Isi jaminan',$('fIsi'));
    if(jaminan.every(Boolean)){const so=window.Link.slotOwner(jaminan,editingId);if(so){errors.push('BRIMEN jaminan '+jaminan.join('.')+' sudah dipakai '+so.nama);boxes.slice(4).forEach(b=>b.classList.add('err'));}}}
  if(berkas.every(Boolean)&&cif){
    const bo=window.Link.berkasOwner(berkas,cif,editingId,status||'Aktif');
    if(bo){errors.push('BRIMEN berkas '+berkas.join('.')+' sudah dipakai '+bo.nama+' (CIF berbeda)');boxes.slice(0,4).forEach(b=>b.classList.add('err'));}
  }
  if(!editingId&&cif&&nama){
    const cn=window.Link.cifNameOwner(cif,nama,editingId);
    if(cn){errors.push('CIF '+cif+' sudah terdaftar atas nama '+cn.nama);$('fCif').classList.add('err');}
  }
  if(errors.length)return{errors};
  const iso=selectedDate.getFullYear()+'-'+String(selectedDate.getMonth()+1).padStart(2,'0')+'-'+String(selectedDate.getDate()).padStart(2,'0');
  return{errors:[],rec:{nama,noPinjaman:np,cif,plafon:pl,jenis,mantriFull:mantri,mantri:mantri.split(' ')[0],tglISO:iso,tgl:fmtDate(selectedDate),berkas,jaminan,noJaminan:noJam,isiJaminan:isi,status:status||'Aktif',note:$('fNote').value.trim(),incomplete:belumChk.get(),restruk:status==='Restruk',brimen:berkas.join('.')+(noJam?'':'//'+jaminan.join('.'))}};
}
function rebuildMantriList(){
  const list=$('mantriList'),val=$('mantriVal'),cur=getSelect('mantriVal');
  const e=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  list.innerHTML='<div class="lb-header">Pilih mantri</div>'+window.MantriStore.map(m=>'<div class="lb-item" data-val="'+e(m.nama)+'">'+e(m.nama)+'</div>').join('');
  list.querySelectorAll('.lb-item').forEach(item=>{
    if(item.dataset.val===cur)item.classList.add('sel');
    item.addEventListener('click',ev=>{ev.stopPropagation();list.querySelectorAll('.lb-item').forEach(i=>i.classList.remove('sel'));item.classList.add('sel');val.textContent=item.dataset.val;val.classList.remove('ph');list.classList.add('hidden');});
  });
}
window.FormView={rebuildMantri:rebuildMantriList,setMode,reset,fill,collect,editingId:()=>editingId};
})();
