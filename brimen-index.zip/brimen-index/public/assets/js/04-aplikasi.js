(function(){
  const $=id=>document.getElementById(id);
  const views={login:'view-login',dashboard:'view-dashboard',cari:'view-cari',mantri:'view-mantri',mantriDetail:'view-mantri-detail',jaminan:'view-jaminan',jaminanDetail:'view-jaminan-detail',statistik:'view-statistik',export:'view-export',form:'view-form',detail:'view-detail'};
  function show(name){
    Object.keys(views).forEach(k=>$(views[k]).classList.toggle('active',k===name));
    const m=document.querySelector('.view.active > main'); if(m) m.scrollTop=0;
  }
  function setNav(key){document.querySelectorAll('[data-nav]').forEach(a=>a.classList.toggle('active',a.dataset.nav===key));}
  let tt;
  function toast(msg,type){const t=$('toast');t.textContent=msg;t.className='toast show'+(type==='err'?' err':'');clearTimeout(tt);tt=setTimeout(()=>t.className='toast',3200);}
  const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  let current=null;
  const chips=arr=>'<div class="d-chips">'+['Ruang','Loker','Laci','Berkas'].map((l,i)=>'<div class="d-chip"><small>'+l+'</small><b>'+esc(arr[i]||'-')+'</b></div>').join('')+'</div>';
  const item=(l,v,big)=>'<div class="d-item"><span class="d-lbl">'+l+'</span><span class="d-val'+(big?' big':'')+'">'+v+'</span></div>';
  function renderDetail(d){
    current=d;
    $('dDel').style.display=d.status==='Lunas'?'':'none';
    $('dSub').textContent=d.nama+' \u2022 '+d.jenis;
    const sc={Aktif:'normal',Lunas:'lunas',Restruk:'restruk',DH:'dh'}[d.status]||'';
    $('dBadges').innerHTML='<span class="d-pill '+sc+'">'+esc(d.status)+'</span>'+(d.incomplete?'<span class="d-pill warn">Belum lengkap</span>':'');
    $('dAlert').innerHTML=d.incomplete?'<div class="d-alert"><b>Berkas belum lengkap</b><span>'+esc(d.note||'Terdapat berkas yang perlu dilengkapi.')+'</span></div>':'';
    $('dNasabah').innerHTML=item('Nama debitur',esc(d.nama))+item('No. pinjaman',esc(d.noPinjaman))+item('CIF',esc(d.cif))+item('Jenis pinjaman',esc(d.jenis))+item('Plafon','Rp '+esc(d.plafon),true)+item('Mantri',esc(d.mantriFull))+item('Tanggal realisasi',esc(d.tgl))+item('BRIMEN',esc(d.brimen))+item('Status pinjaman',esc(d.status))+(d.noJaminan?'':item('Status jaminan',esc(d.statusJaminan||'Aktif')));
    $('dLokasi').innerHTML=d.noJaminan
      ?'<div class="d-locs"><div><div class="d-loc-title">BRIMEN berkas</div>'+chips(d.berkas)+'</div></div><div class="d-banner">Tidak ada jaminan fisik (tanpa agunan)</div>'
      :'<div class="d-locs"><div><div class="d-loc-title">BRIMEN berkas</div>'+chips(d.berkas)+'</div><div><div class="d-loc-title">BRIMEN jaminan</div>'+chips(d.jaminan)+'</div></div><div class="d-grid" style="grid-template-columns:1fr;margin-bottom:18px">'+item('Isi jaminan',esc(d.isiJaminan||'-'))+'</div>';
    $('dNote').innerHTML=d.note?esc(d.note):'<span class="muted">Tidak ada catatan</span>';
  }
  function goCari(){window.CariApi.render();show('cari');setNav('cari');}
  let back=null,dback=null,dnav=null;
  const afterForm=()=>{const f=back;back=null;f?f():goCari();};
  window.App={
    toast,goCari,show,setNav,
    openNew(){back=null;FormView.setMode('new');FormView.reset();show('form');setNav('new');},
    openEdit(d,ret,nav){back=ret||null;FormView.setMode('edit');FormView.fill(d);show('form');setNav(nav||(ret?'mantri':'cari'));},
    openDetail(d,ret,nav){dback=ret||null;dnav=nav||null;renderDetail(d);show('detail');setNav(nav||(ret?'mantri':'cari'));}
  };
  $('btnBatal').addEventListener('click',afterForm);
  $('dBack').addEventListener('click',()=>{const f=dback;dback=null;f?f():goCari();});
  $('dEdit').addEventListener('click',()=>current&&App.openEdit(current,dback,dnav));
  $('dDel').addEventListener('click',()=>current&&Link.askDeleteDoc(current,()=>{const f=dback;dback=null;f?f():goCari();}));
  $('btnSimpan').addEventListener('click',()=>{
    const r=FormView.collect();
    if(r.errors.length){toast('Periksa dulu: '+r.errors.join(', '),'err');return;}
    const D=window.CariApi.DATA,id=FormView.editingId();
    if(id){const i=D.findIndex(x=>x.id===id);D[i]=Object.assign({},D[i],r.rec,{id});Link.syncJaminan(D[i]);toast('Perubahan berhasil disimpan.'+Link.saveNote(D[i],false));}
    else{r.rec.id='d'+Date.now();Link.syncJaminan(r.rec);const nt=Link.saveNote(r.rec,true);D.unshift(r.rec);toast('Dokumen berhasil disimpan.'+nt);}
    afterForm();
  });
})();
