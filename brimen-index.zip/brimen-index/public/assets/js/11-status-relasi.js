(function(){
  const $=id=>document.getElementById(id);
  const LOAN=['Aktif','Lunas','Restruk','DH'];
  function setBerkas(d,s){d.status=s;d.restruk=(s==='Restruk');}
  /* status jaminan mengikuti status berkas (Aktif/Lunas/Restruk/DH); status lokasi fisik tidak diubah, kecuali berkas Lunas */
  function syncJaminan(d){
    if(d.noJaminan)return;
    const js=d.statusJaminan||'Aktif';
    if(LOAN.indexOf(js)>-1)d.statusJaminan=d.status;
    else d.statusJaminan=js;
  }
  let yes=null;
  const close=()=>{$('cfModal').classList.add('hidden');yes=null;};
  function confirm(o,fn){
    $('cfTitle').textContent=o.title;$('cfMsg').textContent=o.msg;$('cfWarn').textContent=o.warn||'';
    $('cfYes').textContent=o.yes||'Hapus';yes=fn;$('cfModal').classList.remove('hidden');
  }
  $('cfNo').addEventListener('click',close);
  $('cfModal').addEventListener('click',e=>{if(e.target===$('cfModal'))close();});
  $('cfYes').addEventListener('click',()=>{const f=yes;close();if(f)f();});
  function askDeleteDoc(d,after){
    if(d.status!=='Lunas'){window.App.toast('Hanya berkas berstatus Lunas yang bisa dihapus','err');return;}
    if(!d.noJaminan&&(d.statusJaminan||'Aktif')!=='Diambil'){window.App.toast('Jaminan berkas ini belum berstatus Diambil, jadi data belum bisa dihapus','err');return;}
    confirm({title:'Hapus data berkas?',msg:d.nama+' \u2022 '+d.noPinjaman,
      warn:'Data berkas'+(d.noJaminan?'':' beserta jaminannya (Lemari '+d.jaminan[1]+', Laci '+d.jaminan[2]+', No. '+d.jaminan[3]+')')+' akan dihapus permanen dan tidak bisa dikembalikan.',yes:'Hapus data'},
      function(){
        const D=window.CariApi.DATA,i=D.findIndex(x=>x.id===d.id);if(i>-1)D.splice(i,1);
        window.App.toast('Data '+d.nama+' dihapus');if(after)after();
      });
  }
  function deleteJaminan(d){d.noJaminan=true;d.jaminan=[];d.isiJaminan='';d.statusJaminan='Aktif';d.ketJaminan='';}
  function slotKey(a){const n=v=>{const x=parseInt(v,10);return isNaN(x)?String(v).toUpperCase():String(x);};return [String(a[0]).toUpperCase(),String(a[1]).toUpperCase(),n(a[2]),n(a[3])].join('|');}
  function slotOwner(a,excludeId){const k=slotKey(a);return window.CariApi.DATA.find(x=>x.id!==excludeId&&!x.noJaminan&&x.jaminan&&x.jaminan.length===4&&(x.statusJaminan||'Aktif')!=='Diambil'&&slotKey(x.jaminan)===k)||null;}
  function nopOwner(np,excludeId){const dg=String(np).replace(/\D/g,'');return window.CariApi.DATA.find(x=>x.id!==excludeId&&x.noPinjaman.replace(/\D/g,'')===dg)||null;}
  const cifN=s=>String(s||'').toUpperCase().replace(/\s+/g,'');
  const namaN=s=>String(s||'').toUpperCase().replace(/[.,]/g,' ').replace(/\s+/g,' ').trim();
  /* BRIMEN berkas sudah dipakai nasabah lain (CIF berbeda)? Berkas berstatus Lunas dianggap bebas (map & nomornya boleh dipakai ulang). */
  function berkasOwner(berkas,cif,excludeId,statusBaru){
    if(statusBaru==='Lunas')return null;
    const k=slotKey(berkas),c=cifN(cif);
    return window.CariApi.DATA.find(x=>x.id!==excludeId&&x.status!=='Lunas'&&cifN(x.cif)!==c&&slotKey(x.berkas)===k)||null;
  }
  /* CIF yang sama harus atas nama yang sama */
  function cifNameOwner(cif,nama,excludeId){
    const c=cifN(cif),n=namaN(nama);
    return window.CariApi.DATA.find(x=>x.id!==excludeId&&cifN(x.cif)===c&&namaN(x.nama)!==n)||null;
  }
  function cifOthers(cif,excludeId){const c=cifN(cif);return window.CariApi.DATA.filter(x=>x.id!==excludeId&&cifN(x.cif)===c);}
  function saveNote(rec,isNew){
    const o=cifOthers(rec.cif,rec.id);
    if(isNew&&o.length)return ' Nasabah ini sudah punya '+o.length+' pinjaman lain.';
    if(!isNew&&o.some(x=>namaN(x.nama)!==namaN(rec.nama)))return ' Perhatian: nama berbeda dengan pinjaman lain pada CIF yang sama.';
    return '';
  }
  window.Link={berkasOwner:berkasOwner,cifNameOwner:cifNameOwner,cifOthers:cifOthers,saveNote:saveNote,cifN:cifN,namaN:namaN,slotKey:slotKey,slotOwner:slotOwner,nopOwner:nopOwner,LOAN:LOAN,setBerkas:setBerkas,syncJaminan:syncJaminan,confirm:confirm,askDeleteDoc:askDeleteDoc,deleteJaminan:deleteJaminan};
})();
