(function(){
  const $=id=>document.getElementById(id);
  const A=window.App,S=window.MantriStore;
  const MON=["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"];
  const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const fmt=n=>String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g,'.');
  const num=s=>parseInt(String(s).replace(/\D/g,''),10)||0;
  const short=n=>n>=1e9?(n/1e9).toFixed(2).replace('.',',').replace(/,?0+$/,'')+' M':fmt(n/1e6)+' Jt';
  const ICON='<svg viewBox="0 0 24 24" fill="none" stroke-width="1.8" stroke-linecap="round"><circle cx="12" cy="8" r="4"/><path d="M4.5 21c0-4 3.4-6.5 7.5-6.5s7.5 2.5 7.5 6.5"/></svg>';
  const EDIT='<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>';

  function stats(m){
    const rs=window.CariApi.DATA.filter(d=>d.mantriFull===m.nama);
    return{rs:rs,n:rs.length,plafon:rs.reduce((s,d)=>s+num(d.plafon),0),inc:rs.filter(d=>d.incomplete).length};
  }
  function avatar(m,cls){
    const st=m.foto?' style="background-image:url(\''+m.foto+'\')"':'';
    return '<div class="mt-avatar '+(cls||'')+'" data-kode="'+esc(m.kode)+'"'+st+'>'+(m.foto?'':ICON)+'<span class="cam">'+(m.foto?'Ubah foto':'Tambah foto')+'</span></div>';
  }

  /* ---------- foto ---------- */
  const inp=document.createElement('input');inp.type='file';inp.accept='image/*';inp.style.display='none';document.body.appendChild(inp);
  let cb=null;
  function pick(fn){cb=fn;inp.value='';inp.click();}
  function toDataUrl(file){
    return new Promise((res,rej)=>{
      const fr=new FileReader();
      fr.onerror=()=>rej();
      fr.onload=()=>{
        const img=new Image();
        img.onerror=()=>rej();
        img.onload=()=>{
          try{const s=Math.min(img.width,img.height),c=document.createElement('canvas');c.width=c.height=320;
            c.getContext('2d').drawImage(img,(img.width-s)/2,(img.height-s)/2,s,s,0,0,320,320);res(c.toDataURL('image/jpeg',0.88));}
          catch(e){res(fr.result);}
        };
        img.src=fr.result;
      };
      fr.readAsDataURL(file);
    });
  }
  inp.addEventListener('change',()=>{
    const f=inp.files&&inp.files[0];if(!f)return;
    if(!/^image\//.test(f.type)){A.toast('File harus berupa gambar','err');return;}
    toDataUrl(f).then(u=>cb&&cb(u)).catch(()=>A.toast('Foto tidak dapat dibaca','err'));
  });
  function pickFor(kode){
    const m=S.find(x=>x.kode===kode);if(!m)return;
    pick(u=>{m.foto=u;renderGrid();if(cur&&cur.kode===kode)renderDetail();A.toast('Foto berhasil diperbarui');});
  }

  /* ---------- daftar mantri ---------- */
  function renderGrid(){
    $('mtGrid').innerHTML=S.map(m=>{
      const s=stats(m);
      return '<div class="mt-card"><div class="mt-head">'+avatar(m)+'<div class="mt-name">'+esc(m.nama)+'</div></div>'+
        '<div class="mt-body"><div class="mt-row"><span>Total Nasabah</span><b>'+fmt(s.n)+'</b></div><div class="mt-row"><span>Total Plafon</span><b>Rp '+fmt(s.plafon)+'</b></div></div>'+
        '<div class="mt-foot"><button type="button" class="mt-btn" data-open="'+esc(m.kode)+'">Lihat Data</button></div></div>';
    }).join('');
  }
  $('mtGrid').addEventListener('click',e=>{
    const av=e.target.closest('.mt-avatar');if(av){pickFor(av.dataset.kode);return;}
    const b=e.target.closest('[data-open]');if(b)A.goMantriDetail(b.dataset.open);
  });

  /* ---------- detail mantri ---------- */
  let cur=null,f={q:'',restruk:false,inc:false,date:''};
  function resetFilters(){
    f={q:'',restruk:false,inc:false,date:''};
    $('mtdSearch').value='';$('mtdDate').value='';$('mtdTglLabel').textContent='Tanggal';
  }
  function card(d){
    return '<div class="nc'+(d.incomplete?' incomplete':'')+'" data-id="'+esc(d.id)+'">'+
      '<div class="nc-name">'+esc(d.nama)+'</div><div class="nc-brimen">BRIMEN : '+esc(d.brimen)+'</div>'+
      '<div class="nc-tag">'+(d.status==='Restruk'?'<span class="badge-restruk">Restruk</span>':d.status==='Lunas'?'<span class="badge-lunas">Lunas</span>':d.status==='DH'?'<span class="badge-dh">DH</span>':'')+'<span class="nc-jenis">'+esc(d.jenis)+'</span></div>'+
      '<div class="nc-grid"><div><span>No. Pinjaman</span>'+esc(d.noPinjaman)+'</div><div><span>CIF</span>'+esc(d.cif)+'</div><div><span>Tgl Realisasi</span>'+esc(d.tgl)+'</div><div><span>Plafon</span>'+esc(d.plafon)+'</div><div><span>BRIMEN</span>'+esc(d.berkas.join('.'))+'</div></div>'+
      '<button type="button" class="icon-btn icon-edit nc-edit" data-act="edit" data-id="'+esc(d.id)+'" title="Edit">'+EDIT+'</button>'+(d.status==='Lunas'?'<button type="button" class="icon-btn icon-del nc-del" data-act="del" data-id="'+esc(d.id)+'" title="Hapus data (lunas)"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14M10 11v6M14 11v6"/></svg></button>':'')+'</div>';
  }
  function renderDetail(){
    if(!cur)return;
    const s=stats(cur),q=f.q.toLowerCase();
    $('mtdAvatarWrap').innerHTML=avatar(cur,'white');
    $('mtdName').textContent=cur.nama;$('mtdRole').textContent=cur.jabatan||'Mantri';
    $('mtdN').textContent=fmt(s.n);$('mtdP').textContent=short(s.plafon);$('mtdP').title='Rp '+fmt(s.plafon);$('mtdI').textContent=fmt(s.inc);
    const rows=s.rs.filter(d=>(!f.restruk||d.status==='Restruk')&&(!f.inc||d.incomplete)&&(!f.date||d.tglISO===f.date)&&(!q||(d.nama+' '+d.cif+' '+d.noPinjaman+' '+d.brimen).toLowerCase().indexOf(q)>-1));
    $('mtdList').innerHTML=rows.length?rows.map(card).join(''):'<div class="empty">Tidak ada nasabah yang cocok.</div>';
    const none=!f.restruk&&!f.inc&&!f.date;
    document.querySelector('.mtd-chip[data-f="all"]').classList.toggle('active',none);
    document.querySelector('.mtd-chip[data-f="restruk"]').classList.toggle('active',f.restruk);
    document.querySelector('.mtd-chip[data-f="inc"]').classList.toggle('active',f.inc);
    $('mtdTgl').classList.toggle('active',!!f.date);
  }
  const ret=()=>A.goMantriDetail(cur.kode);
  $('mtdList').addEventListener('click',e=>{
    const c=e.target.closest('.nc');if(!c)return;
    const d=window.CariApi.DATA.find(x=>x.id===c.dataset.id);if(!d)return;
    if(e.target.closest('[data-act="del"]')){window.Link.askDeleteDoc(d,()=>renderDetail());return;}
    if(e.target.closest('[data-act="edit"]'))A.openEdit(d,ret);else A.openDetail(d,ret);
  });
  $('mtdAvatarWrap').addEventListener('click',e=>{const av=e.target.closest('.mt-avatar');if(av)pickFor(av.dataset.kode);});
  document.querySelectorAll('.mtd-chip[data-f]').forEach(b=>b.addEventListener('click',()=>{
    const k=b.dataset.f;
    if(k==='all'){f.restruk=false;f.inc=false;f.date='';$('mtdDate').value='';$('mtdTglLabel').textContent='Tanggal';}
    else if(k==='restruk')f.restruk=!f.restruk;
    else f.inc=!f.inc;
    renderDetail();
  }));
  $('mtdSearch').addEventListener('input',e=>{f.q=e.target.value.trim();renderDetail();});
  $('mtdTgl').addEventListener('click',e=>{e.stopPropagation();$('mtdTglPop').classList.toggle('hidden');});
  $('mtdTglPop').addEventListener('click',e=>e.stopPropagation());
  $('mtdApply').addEventListener('click',()=>{
    const v=$('mtdDate').value;if(!v)return;
    const p=v.split('-').map(Number);
    f.date=v;$('mtdTglLabel').textContent=String(p[2]).padStart(2,'0')+' '+MON[p[1]-1]+' '+p[0];
    $('mtdTglPop').classList.add('hidden');renderDetail();
  });
  $('mtdClear').addEventListener('click',()=>{f.date='';$('mtdDate').value='';$('mtdTglLabel').textContent='Tanggal';$('mtdTglPop').classList.add('hidden');renderDetail();});
  document.addEventListener('click',()=>$('mtdTglPop').classList.add('hidden'));
  $('mtdBack').addEventListener('click',()=>A.goMantri());

  /* ---------- tambah mantri ---------- */
  let newFoto='';
  function paintNewAvatar(){
    const el=$('mtNewAvatar');
    el.style.backgroundImage=newFoto?"url('"+newFoto+"')":'';
    el.querySelector('svg').style.display=newFoto?'none':'';
  }
  function openAdd(){
    ['mtNama','mtKode'].forEach(id=>{$(id).value='';$(id).classList.remove('err');});
    $('mtJabatan').value='Junior Associate Mantri';newFoto='';paintNewAvatar();
    $('mtModal').classList.remove('hidden');setTimeout(()=>$('mtNama').focus(),30);
  }
  $('mtAdd').addEventListener('click',openAdd);
  $('mtNewAvatar').addEventListener('click',()=>pick(u=>{newFoto=u;paintNewAvatar();}));
  const closeAdd=()=>$('mtModal').classList.add('hidden');
  $('mtModalClose').addEventListener('click',closeAdd);
  $('mtCancel').addEventListener('click',closeAdd);
  $('mtModal').addEventListener('click',e=>{if(e.target===$('mtModal'))closeAdd();});
  $('mtSave').addEventListener('click',()=>{
    const nama=$('mtNama').value.replace(/\s+/g,' ').trim(),kode=$('mtKode').value.trim(),jab=$('mtJabatan').value.replace(/\s+/g,' ').trim()||'Mantri';
    ['mtNama','mtKode'].forEach(id=>$(id).classList.remove('err'));
    if(!nama){$('mtNama').classList.add('err');A.toast('Nama lengkap wajib diisi','err');return;}
    if(!kode){$('mtKode').classList.add('err');A.toast('ID / kode mantri wajib diisi','err');return;}
    if(S.some(m=>m.kode===kode)){$('mtKode').classList.add('err');A.toast('ID / kode '+kode+' sudah terdaftar','err');return;}
    if(S.some(m=>m.nama.toLowerCase()===nama.toLowerCase())){$('mtNama').classList.add('err');A.toast('Mantri dengan nama itu sudah ada','err');return;}
    S.push({kode:kode,nama:nama,jabatan:jab,foto:newFoto});
    window.FormView.rebuildMantri();window.CariApi.refreshMantri();renderGrid();closeAdd();
    A.toast('Mantri '+nama+' berhasil ditambahkan');
  });

  /* ---------- navigasi ---------- */
  A.goMantri=function(){renderGrid();A.show('mantri');A.setNav('mantri');};
  A.goMantriDetail=function(kode){
    const m=S.find(x=>x.kode===kode);if(!m){A.goMantri();return;}
    if(!cur||cur.kode!==kode)resetFilters();
    cur=m;renderDetail();A.show('mantriDetail');A.setNav('mantri');
  };
  window.FormView.rebuildMantri();
})();
