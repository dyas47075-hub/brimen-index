<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\DataController;
use App\Http\Controllers\PageController;
use Illuminate\Support\Facades\Route;

// Halaman aplikasi (login + seluruh menu berjalan di satu halaman)
Route::get('/', [PageController::class, 'index']);

// Autentikasi (maksimal 6 percobaan per menit)
Route::post('/login', [AuthController::class, 'login'])->middleware('throttle:6,1');
Route::post('/logout', [AuthController::class, 'logout']);

// API data (wajib login)
Route::middleware('auth')->prefix('api')->group(function () {
    Route::get('/bootstrap', [DataController::class, 'bootstrap']);
    Route::post('/sync', [DataController::class, 'sync']);
});
