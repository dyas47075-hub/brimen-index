<?php

namespace App\Support;

/**
 * Pemetaan data antara format front-end (JSON) dan kolom database.
 * Sengaja dibuat tanpa ketergantungan framework agar mudah diuji.
 */
class DokumenMapper
{
    public const JENIS = ['KUR', 'KUPERA', 'KUPEDES', 'KECE', 'GBT'];

    public const STATUS_BERKAS = ['Aktif', 'Lunas', 'Restruk', 'DH'];

    public const STATUS_JAMINAN = [
        'Aktif', 'Lunas', 'Restruk', 'DH',
        'Diambil', 'Lemari Tahan Api', 'Notaris', 'Dibawa Mantri',
    ];

    private const BULAN = [
        'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
        'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember',
    ];

    /** 2026-06-29 -> "29 Juni 2026" */
    public static function tglIndo(string $iso): string
    {
        $p = explode('-', substr($iso, 0, 10));
        if (count($p) !== 3) {
            return $iso;
        }

        return str_pad($p[2], 2, '0', STR_PAD_LEFT).' '.self::BULAN[((int) $p[1]) - 1].' '.$p[0];
    }

    /** Normalisasi bagian kode BRIMEN: huruf kapital, angka tanpa nol di depan ("01" == "1"). */
    public static function norm(mixed $v): string
    {
        $v = strtoupper(trim((string) $v));

        return ctype_digit($v) ? (string) ((int) $v) : $v;
    }

    /** CIF dibandingkan tanpa spasi dan tanpa membedakan huruf besar/kecil. */
    public static function cifN(mixed $v): string
    {
        return strtoupper((string) preg_replace('/\s+/', '', (string) $v));
    }

    /** Nama dibandingkan tanpa titik/koma, spasi ganda, dan huruf besar/kecil. */
    public static function namaN(mixed $v): string
    {
        $s = str_replace(['.', ','], ' ', strtoupper((string) $v));

        return trim((string) preg_replace('/\s+/', ' ', $s));
    }

    /** Kunci unik lokasi jaminan: ruang|loker|laci|nomor */
    public static function slotKey(array $j): string
    {
        return implode('|', array_map([self::class, 'norm'], array_slice(array_values($j), 0, 4)));
    }

    /** Data dari front-end -> atribut tabel documents. */
    public static function fromClient(array $d, string $mantriKode): array
    {
        $b = array_values($d['berkas'] ?? []);
        $noJam = (bool) ($d['noJaminan'] ?? false);
        $j = $noJam ? [null, null, null, null] : array_values($d['jaminan'] ?? []);
        $j = array_pad($j, 4, null);

        $riwayat = [];
        foreach (($d['riwayat'] ?? []) as $r) {
            if (is_array($r) && isset($r['t'], $r['x'])) {
                $riwayat[] = ['t' => (int) $r['t'], 'x' => mb_substr((string) $r['x'], 0, 500)];
            }
        }
        $riwayat = array_slice($riwayat, 0, 20);

        $isi = trim((string) ($d['isiJaminan'] ?? ''));
        $ket = trim((string) ($d['ketJaminan'] ?? ''));
        $note = trim((string) ($d['note'] ?? ''));

        return [
            'nama_debitur' => trim((string) preg_replace('/\s+/', ' ', (string) $d['nama'])),
            'no_pinjaman' => (string) $d['noPinjaman'],
            'cif' => trim((string) $d['cif']),
            'jenis_pinjaman' => (string) $d['jenis'],
            'plafon' => (int) preg_replace('/\D/', '', (string) $d['plafon']),
            'mantri_kode' => $mantriKode,
            'tgl_realisasi' => (string) $d['tglISO'],
            'status_pinjaman' => (string) $d['status'],
            'berkas_ruang' => (string) ($b[0] ?? ''),
            'berkas_loker' => (string) ($b[1] ?? ''),
            'berkas_laci' => (string) ($b[2] ?? ''),
            'berkas_nomor' => (string) ($b[3] ?? ''),
            'tanpa_agunan' => $noJam,
            'jaminan_ruang' => $j[0],
            'jaminan_loker' => $j[1],
            'jaminan_laci' => $j[2],
            'jaminan_nomor' => $j[3],
            'isi_jaminan' => ($noJam || $isi === '') ? null : $isi,
            'status_jaminan' => (string) ($d['statusJaminan'] ?? 'Aktif') ?: 'Aktif',
            'keterangan_jaminan' => ($noJam || $ket === '') ? null : $ket,
            'note' => $note === '' ? null : $note,
            'belum_lengkap' => (bool) ($d['incomplete'] ?? false),
            'riwayat' => $riwayat,
        ];
    }

    /** Baris tabel documents -> format front-end. */
    public static function toClient(array $row, string $mantriNama): array
    {
        $noJam = (bool) ($row['tanpa_agunan'] ?? false);
        $riw = $row['riwayat'] ?? [];
        if (is_string($riw)) {
            $riw = json_decode($riw, true) ?: [];
        }
        $iso = substr((string) $row['tgl_realisasi'], 0, 10);

        return [
            'id' => (string) $row['id'],
            'nama' => (string) $row['nama_debitur'],
            'noPinjaman' => (string) $row['no_pinjaman'],
            'cif' => (string) $row['cif'],
            'jenis' => (string) $row['jenis_pinjaman'],
            'plafon' => number_format((int) $row['plafon'], 0, ',', '.'),
            'mantriFull' => $mantriNama,
            'tglISO' => $iso,
            'tgl' => self::tglIndo($iso),
            'berkas' => [
                (string) $row['berkas_ruang'], (string) $row['berkas_loker'],
                (string) $row['berkas_laci'], (string) $row['berkas_nomor'],
            ],
            'jaminan' => $noJam ? [] : [
                (string) $row['jaminan_ruang'], (string) $row['jaminan_loker'],
                (string) $row['jaminan_laci'], (string) $row['jaminan_nomor'],
            ],
            'noJaminan' => $noJam,
            'isiJaminan' => (string) ($row['isi_jaminan'] ?? ''),
            'status' => (string) $row['status_pinjaman'],
            'statusJaminan' => (string) ($row['status_jaminan'] ?? 'Aktif'),
            'ketJaminan' => (string) ($row['keterangan_jaminan'] ?? ''),
            'incomplete' => (bool) ($row['belum_lengkap'] ?? false),
            'note' => (string) ($row['note'] ?? ''),
            'riwayat' => array_values($riw),
        ];
    }
}
