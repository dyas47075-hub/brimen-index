<?php

namespace App\Console\Commands;

use App\Models\User;
use Illuminate\Console\Command;

class BuatAkun extends Command
{
    protected $signature = 'brimen:buat-akun {id? : ID Petugas} {--nama= : Nama tampilan}';

    protected $description = 'Membuat akun petugas baru atau mereset kata sandi akun yang sudah ada';

    public function handle(): int
    {
        $id = $this->argument('id') ?: $this->ask('ID Petugas');
        $nama = $this->option('nama') ?: $this->ask('Nama tampilan', $id);
        $pw = (string) $this->secret('Kata sandi (minimal 8 karakter)');
        $pw2 = (string) $this->secret('Ulangi kata sandi');

        if (strlen($pw) < 8) {
            $this->error('Kata sandi minimal 8 karakter.');

            return self::FAILURE;
        }
        if ($pw !== $pw2) {
            $this->error('Kata sandi tidak sama.');

            return self::FAILURE;
        }

        // Kata sandi otomatis di-hash (cast "hashed" pada model User)
        User::updateOrCreate(['id_petugas' => $id], [
            'nama' => $nama,
            'password' => $pw,
            'role' => 'admin',
            'aktif' => true,
        ]);

        $this->info("Akun '{$id}' siap dipakai.");

        return self::SUCCESS;
    }
}
