<?php

namespace App\Http\Controllers;

use App\Models\Dokumen;
use App\Models\Laci;
use App\Models\Lemari;
use App\Models\Mantri;
use App\Support\DokumenMapper;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class DataController extends Controller
{
    /** Seluruh data awal untuk front-end setelah login. */
    public function bootstrap(Request $request): JsonResponse
    {
        $u = $request->user();
        $mantri = Mantri::orderBy('id')->get();
        $namaByKode = $mantri->pluck('nama', 'kode');

        $docs = Dokumen::orderByDesc('created_at')->orderBy('no_pinjaman')->get()
            ->map(fn (Dokumen $d) => DokumenMapper::toClient(
                $d->attributesToArray(),
                (string) ($namaByKode[$d->mantri_kode] ?? '')
            ))->values();

        $lemari = Lemari::with('laci')->orderBy('id')->get()->map(fn (Lemari $l) => [
            'kode' => $l->kode,
            'laci' => $l->laci->sortBy('no')->map(fn (Laci $c) => [
                'no' => (int) $c->no,
                'on' => (bool) $c->aktif,
            ])->values()->all(),
        ])->values();

        return response()->json([
            'user' => ['id' => $u->id_petugas, 'name' => $u->nama],
            'mantri' => $mantri->map(fn (Mantri $m) => [
                'kode' => $m->kode,
                'nama' => $m->nama,
                'jabatan' => $m->jabatan,
                'foto' => $m->foto ?? '',
            ])->values(),
            'lemari' => $lemari,
            'docs' => $docs,
        ]);
    }

    /**
     * Menyimpan perubahan dari front-end dalam satu transaksi:
     * mantri baru/berubah, lemari baru/berubah, dokumen ditambah/diubah, dokumen dihapus.
     * Jika satu data tidak valid, seluruh perubahan dibatalkan dan pesan alasannya dikirim balik.
     */
    public function sync(Request $request): JsonResponse
    {
        $data = $request->validate([
            'mantri' => ['array'],
            'mantri.*.kode' => ['required', 'string', 'max:20'],
            'mantri.*.nama' => ['required', 'string', 'max:100'],
            'mantri.*.jabatan' => ['nullable', 'string', 'max:100'],
            'mantri.*.foto' => ['nullable', 'string', 'max:3000000'],
            'lemari' => ['array'],
            'lemari.*.kode' => ['required', 'regex:/^[A-Z0-9]{1,3}$/'],
            'lemari.*.laci' => ['required', 'array', 'min:1', 'max:24'],
            'lemari.*.laci.*.no' => ['required', 'integer', 'min:1', 'max:99'],
            'lemari.*.laci.*.on' => ['required', 'boolean'],
            'docs.deletes' => ['array'],
            'docs.deletes.*' => ['string', 'max:40'],
        ]);

        $upserts = $request->input('docs.upserts', []);
        if (! is_array($upserts)) {
            $this->fail('Format data dokumen tidak valid');
        }

        DB::transaction(function () use ($data, $upserts) {
            $this->syncMantri($data['mantri'] ?? []);
            $this->syncLemari($data['lemari'] ?? []);

            $deletes = $data['docs']['deletes'] ?? [];
            if ($deletes) {
                Dokumen::whereIn('id', $deletes)->delete();
            }

            $this->upsertDocs($upserts);
        });

        return response()->json(['ok' => true]);
    }

    private function syncMantri(array $list): void
    {
        foreach ($list as $m) {
            $nama = trim((string) preg_replace('/\s+/', ' ', $m['nama']));
            $clash = Mantri::where('nama', $nama)->where('kode', '!=', $m['kode'])->exists();
            if ($clash) {
                $this->fail('Nama mantri "'.$nama.'" sudah dipakai kode lain');
            }

            Mantri::updateOrCreate(['kode' => $m['kode']], [
                'nama' => $nama,
                'jabatan' => ($m['jabatan'] ?? '') !== '' ? $m['jabatan'] : 'Mantri',
                'foto' => ($m['foto'] ?? '') !== '' ? $m['foto'] : null,
            ]);
        }
    }

    private function syncLemari(array $list): void
    {
        foreach ($list as $l) {
            $lemari = Lemari::firstOrCreate(['kode' => $l['kode']]);
            foreach ($l['laci'] as $c) {
                Laci::updateOrCreate(
                    ['lemari_id' => $lemari->id, 'no' => (int) $c['no']],
                    ['aktif' => (bool) $c['on']]
                );
            }
        }
    }

    private function upsertDocs(array $docs): void
    {
        if (! $docs) {
            return;
        }

        foreach ($docs as $d) {
            if (! is_array($d)) {
                $this->fail('Format data dokumen tidak valid');
            }
        }

        // Proses dulu dokumen yang MELEPAS berkas/slot (status Lunas / jaminan Diambil), baru yang memakainya,
        // supaya tidak ada penolakan palsu ketika satu permintaan memuat keduanya.
        usort($docs, function (array $a, array $b) {
            $ka = [($a['status'] ?? '') === 'Lunas' ? 0 : 1, ($a['statusJaminan'] ?? '') === 'Diambil' ? 0 : 1];
            $kb = [($b['status'] ?? '') === 'Lunas' ? 0 : 1, ($b['statusJaminan'] ?? '') === 'Diambil' ? 0 : 1];

            return $ka <=> $kb;
        });

        $kodeByNama = Mantri::pluck('kode', 'nama');

        foreach ($docs as $d) {
            if (! is_array($d)) {
                $this->fail('Format data dokumen tidak valid');
            }

            $label = 'Data "'.($d['nama'] ?? ($d['id'] ?? '?')).'": ';
            $v = Validator::make($d, self::docRules());
            if ($v->fails()) {
                $this->fail($label.$v->errors()->first());
            }

            $kode = $kodeByNama[$d['mantriFull']] ?? null;
            if (! $kode) {
                $this->fail($label.'mantri "'.$d['mantriFull'].'" belum terdaftar');
            }

            if ((int) preg_replace('/\D/', '', (string) $d['plafon']) <= 0) {
                $this->fail($label.'plafon harus lebih dari 0');
            }

            // 1) Nomor pinjaman tidak boleh kembar
            $kembar = Dokumen::where('id', '!=', $d['id'])->where('no_pinjaman', $d['noPinjaman'])->first();
            if ($kembar) {
                $this->fail($label.'no. pinjaman '.$d['noPinjaman'].' sudah dipakai '.$kembar->nama_debitur);
            }

            // 1b) BRIMEN berkas: boleh dipakai ulang HANYA setelah dokumen sebelumnya Lunas.
            //     Dokumen yang belum Lunas milik nasabah (CIF) lain -> ditolak. CIF yang sama -> boleh.
            if ($d['status'] !== 'Lunas') {
                $bo = $this->pemilikBerkas($d['berkas'], $d['cif'], $d['id']);
                if ($bo) {
                    $this->fail($label.'BRIMEN berkas '.implode('.', $d['berkas']).' masih dipakai '.$bo->nama_debitur.' (CIF berbeda, belum lunas)');
                }
            }

            // 1c) CIF yang sama harus atas nama yang sama (berlaku untuk data baru)
            if (! Dokumen::where('id', $d['id'])->exists()) {
                $cn = $this->pemilikCifBeda($d['cif'], $d['nama'], $d['id']);
                if ($cn) {
                    $this->fail($label.'CIF '.trim($d['cif']).' sudah terdaftar atas nama '.$cn->nama_debitur);
                }
            }

            // 2) Satu slot jaminan hanya untuk satu jaminan (jaminan "Diambil" = slot kosong)
            $noJam = (bool) $d['noJaminan'];
            $stJam = $d['statusJaminan'] ?? 'Aktif';
            if (! $noJam) {
                if (count($d['jaminan']) !== 4) {
                    $this->fail($label.'BRIMEN jaminan harus terdiri dari 4 bagian');
                }
                if ($stJam !== 'Diambil') {
                    $pemilik = $this->pemilikSlot($d['jaminan'], $d['id']);
                    if ($pemilik) {
                        $this->fail($label.'BRIMEN jaminan '.implode('.', $d['jaminan']).' sudah dipakai '.$pemilik->nama_debitur);
                    }
                }
            }

            $model = Dokumen::find($d['id']) ?? new Dokumen();
            $model->id = $d['id'];
            $model->fill(DokumenMapper::fromClient($d, $kode));
            $model->save();
        }
    }

    private function pemilikSlot(array $jaminan, string $kecualiId): ?Dokumen
    {
        $kunci = DokumenMapper::slotKey($jaminan);

        return Dokumen::where('id', '!=', $kecualiId)
            ->where('tanpa_agunan', false)
            ->where('status_jaminan', '!=', 'Diambil')
            ->where('jaminan_loker', strtoupper(trim((string) $jaminan[1])))
            ->get()
            ->first(fn (Dokumen $x) => DokumenMapper::slotKey([
                $x->jaminan_ruang, $x->jaminan_loker, $x->jaminan_laci, $x->jaminan_nomor,
            ]) === $kunci);
    }

    /** Dokumen lain yang belum Lunas, memakai BRIMEN berkas yang sama, dengan CIF berbeda. */
    private function pemilikBerkas(array $berkas, string $cif, string $kecualiId): ?Dokumen
    {
        $kunci = DokumenMapper::slotKey($berkas);
        $c = DokumenMapper::cifN($cif);

        return Dokumen::where('id', '!=', $kecualiId)
            ->where('status_pinjaman', '!=', 'Lunas')
            ->where('berkas_loker', strtoupper(trim((string) $berkas[1])))
            ->get()
            ->first(fn (Dokumen $x) => DokumenMapper::cifN($x->cif) !== $c
                && DokumenMapper::slotKey([$x->berkas_ruang, $x->berkas_loker, $x->berkas_laci, $x->berkas_nomor]) === $kunci);
    }

    /** Dokumen lain dengan CIF yang sama tetapi nama debitur berbeda. */
    private function pemilikCifBeda(string $cif, string $nama, string $kecualiId): ?Dokumen
    {
        $c = DokumenMapper::cifN($cif);
        $n = DokumenMapper::namaN($nama);

        return Dokumen::where('id', '!=', $kecualiId)
            ->whereRaw("UPPER(REPLACE(cif, ' ', '')) = ?", [$c])
            ->get()
            ->first(fn (Dokumen $x) => DokumenMapper::namaN($x->nama_debitur) !== $n);
    }

    private static function docRules(): array
    {
        return [
            'id' => ['required', 'string', 'max:40'],
            'nama' => ['required', 'string', 'max:150'],
            'noPinjaman' => ['required', 'regex:/^\d{4}-\d{2}-\d{6}-\d{2}-\d$/'],
            'cif' => ['required', 'string', 'max:30'],
            'jenis' => ['required', Rule::in(DokumenMapper::JENIS)],
            'plafon' => ['required'],
            'mantriFull' => ['required', 'string', 'max:100'],
            'tglISO' => ['required', 'date_format:Y-m-d'],
            'berkas' => ['required', 'array', 'size:4'],
            'berkas.*' => ['required', 'string', 'max:10'],
            'noJaminan' => ['required', 'boolean'],
            'jaminan' => ['present', 'array'],
            'jaminan.*' => ['required', 'string', 'max:10'],
            'isiJaminan' => ['nullable', 'string', 'max:255'],
            'status' => ['required', Rule::in(DokumenMapper::STATUS_BERKAS)],
            'statusJaminan' => ['nullable', Rule::in(DokumenMapper::STATUS_JAMINAN)],
            'ketJaminan' => ['nullable', 'string', 'max:255'],
            'incomplete' => ['required', 'boolean'],
            'note' => ['nullable', 'string', 'max:1000'],
            'riwayat' => ['nullable', 'array'],
        ];
    }

    private function fail(string $message): never
    {
        throw new HttpResponseException(response()->json(['message' => $message], 422));
    }
}
