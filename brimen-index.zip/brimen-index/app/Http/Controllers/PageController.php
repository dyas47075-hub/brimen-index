<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\View\View;

class PageController extends Controller
{
    /** Satu-satunya halaman HTML. Seluruh menu dijalankan di sisi browser dan menyimpan data lewat /api. */
    public function index(Request $request): View
    {
        $u = $request->user();

        return view('app', [
            'user' => $u ? ['id' => $u->id_petugas, 'name' => $u->nama] : null,
        ]);
    }
}
