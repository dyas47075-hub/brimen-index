<?php

namespace App\Http\Controllers;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    public function login(Request $request): JsonResponse
    {
        $data = $request->validate([
            'id_petugas' => ['required', 'string'],
            'password' => ['required', 'string'],
        ]);

        $ok = Auth::attempt([
            'id_petugas' => $data['id_petugas'],
            'password' => $data['password'],
            'aktif' => true,
        ], $request->boolean('remember'));

        if (! $ok) {
            return response()->json(['message' => 'ID Petugas atau kata sandi salah'], 422);
        }

        $request->session()->regenerate();
        $u = $request->user();

        return response()->json([
            'user' => ['id' => $u->id_petugas, 'name' => $u->nama],
            'csrf' => csrf_token(),
        ]);
    }

    public function logout(Request $request): JsonResponse
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return response()->json(['ok' => true, 'csrf' => csrf_token()]);
    }
}
