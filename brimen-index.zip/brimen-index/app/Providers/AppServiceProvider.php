<?php

namespace App\Providers;

use Illuminate\Support\Facades\Schema;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        // Aman untuk MySQL/MariaDB versi lama (batas panjang indeks utf8mb4)
        Schema::defaultStringLength(191);
    }
}
