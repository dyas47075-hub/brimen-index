<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * Dokumen / berkas pinjaman. Primary key berupa string (dibuat oleh aplikasi).
 */
class Dokumen extends Model
{
    protected $table = 'documents';

    public $incrementing = false;

    protected $keyType = 'string';

    protected $guarded = [];

    protected function casts(): array
    {
        return [
            'tgl_realisasi' => 'date:Y-m-d',
            'plafon' => 'integer',
            'tanpa_agunan' => 'boolean',
            'belum_lengkap' => 'boolean',
            'riwayat' => 'array',
        ];
    }

    public function mantri(): BelongsTo
    {
        return $this->belongsTo(Mantri::class, 'mantri_kode', 'kode');
    }
}
