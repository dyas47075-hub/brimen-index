<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;

/**
 * Akun petugas. Login memakai ID Petugas (kolom id_petugas) dan kata sandi (hash bcrypt).
 */
class User extends Authenticatable
{
    protected $table = 'users';

    protected $fillable = ['id_petugas', 'nama', 'password', 'role', 'aktif'];

    protected $hidden = ['password', 'remember_token'];

    protected function casts(): array
    {
        return [
            'password' => 'hashed',
            'aktif' => 'boolean',
        ];
    }
}
