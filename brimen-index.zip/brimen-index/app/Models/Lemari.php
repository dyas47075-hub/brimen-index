<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Lemari extends Model
{
    protected $table = 'lemari';

    protected $fillable = ['kode'];

    public function laci(): HasMany
    {
        return $this->hasMany(Laci::class, 'lemari_id');
    }
}
