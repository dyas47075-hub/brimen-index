<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Mantri extends Model
{
    protected $table = 'mantri';

    protected $fillable = ['kode', 'nama', 'jabatan', 'foto'];
}
