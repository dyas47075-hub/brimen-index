<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Laci extends Model
{
    protected $table = 'laci';

    protected $fillable = ['lemari_id', 'no', 'aktif'];

    protected function casts(): array
    {
        return ['aktif' => 'boolean', 'no' => 'integer'];
    }
}
