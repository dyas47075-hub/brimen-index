<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<meta name="app-base" content="<?php echo e(rtrim(url('/'), '/')); ?>">
<title>BRIMEN Index — Bank BRI</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/app.css')); ?>">
<script src="<?php echo e(asset('vendor/xlsx.full.min.js')); ?>"></script>
</head>
<body class="<?php echo e($user ? '' : 'logged-out'); ?>">
<div class="layout">
<aside class="sidebar">
    <div class="brand">
      <img class="brand-logo" src="<?php echo e(asset('images/logo-bank-bri-putih.png')); ?>" alt="Bank BRI">
    </div>

    <div class="nav-label">Menu Utama</div>
    <a class="nav-item" data-nav="dashboard">Dashboard</a>
    <a class="nav-item active" data-nav="cari">Cari File</a>
    <a class="nav-item" data-nav="new">Input File</a>

    <div class="nav-label">Referensi</div>
    <a class="nav-item" data-nav="mantri">Mantri</a>
    <a class="nav-item" data-nav="jaminan">Jaminan</a>

    <div class="nav-label">Laporan</div>
    <a class="nav-item" data-nav="statistik">Statistik</a>
    <a class="nav-item" data-nav="export">Export Excel</a>
    <a class="nav-item" data-nav="logout" style="margin-top:26px;border-top:1px solid rgba(255,255,255,.18);padding-top:14px">Keluar</a>
  </aside>
<div class="view <?php echo e($user ? '' : 'active'); ?>" id="view-login">
<main class="login-main">
  <div class="login-top"><img class="lg-bumn" src="<?php echo e(asset('images/bumn-untuk-indonesia.png')); ?>" alt="BUMN untuk Indonesia"><img class="lg-bri" src="<?php echo e(asset('images/bank-bri.png')); ?>" alt="Bank BRI"></div>
  <div class="lg-left">
    <h2 class="lg-welcome">Welcome to</h2>
    <h1 class="lg-brand">BRIMEN INDEX</h1>
    <div class="lg-field"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="12" cy="8" r="4"/><path d="M5 21c0-4 3.1-6.5 7-6.5s7 2.5 7 6.5Z"/></svg><input id="lgId" type="text" placeholder="Masukkan ID Petugas" autocomplete="username"></div>
    <div class="lg-field"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="7.5" cy="15.5" r="4.5"/><path d="M10.7 12.3 21 2M16 7l3 3M13.5 9.5l2 2"/></svg><input id="lgPw" type="password" placeholder="•••••" autocomplete="current-password"></div>
    <div class="lg-row">
      <div class="lg-remember" id="lgRemember"><span class="lg-chk" id="lgChk"></span>Ingat Saya</div>
      <a class="lg-forgot" id="lgForgot">Lupa kata sandi?</a>
    </div>
    <button type="button" class="lg-btn" id="lgBtn">LOGIN</button>
    <div class="lg-err" id="lgErr"></div>
  </div>
  <div class="lg-right"><img src="<?php echo e(asset('images/ilustrasi-login.webp')); ?>" alt="Ilustrasi"></div>
</main>
</div>
<div class="view" id="view-dashboard">
<main class="main-dash">
  <div class="dash-banner">
    <div><div class="db-date" id="dbDate"></div><h1 class="db-title">Welcome Back, <span id="dbName">Lina</span></h1><div class="db-sub" id="dbGreet"></div></div>
    <img class="db-img" src="<?php echo e(asset('images/ilustrasi-kalender.webp')); ?>" alt="">
  </div>
  <div class="dash-stats">
    <div class="stat-card"><div class="stat-head"><span class="stat-ic ic-doc"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/></svg></span>Total Dokumen</div><div class="stat-num" id="stDok">0</div></div>
    <div class="stat-card"><div class="stat-head"><span class="stat-ic ic-jam"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5 12.6 20a5.5 5.5 0 0 1-7.8-7.8l8.5-8.5a3.7 3.7 0 0 1 5.2 5.2l-8.4 8.4a1.8 1.8 0 0 1-2.6-2.6l7.7-7.7"/></svg></span>Total Jaminan</div><div class="stat-num" id="stJam">0</div></div>
    <div class="stat-card"><div class="stat-head"><span class="stat-ic ic-man"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><circle cx="12" cy="8" r="3.6"/><path d="M5 20c0-3.6 3-5.6 7-5.6s7 2 7 5.6Z"/></svg></span>Total Mantri</div><div class="stat-num" id="stMan">0</div></div>
  </div>
  <div class="dash-row">
    <div class="chart-card">
    <div class="cc-head">
    <span>Aktivitas per Bulan</span>

    <select id="bcYear"
            class="bc-year-select"
            aria-label="Pilih tahun statistik">
    </select>
</div>

        <div class="bc-legend">
            <span><i style="background:#0b559f"></i>Dokumen</span>
            <span><i style="background:#9c1f3b"></i>Jaminan</span>
        </div>

        <div class="bc-plot" id="bcPlot"></div>

        <div class="bc-months" id="bcMonths"></div>
    </div>

    <div class="pie-card">
      <div class="pc-head"><span class="stat-ic ic-pin"><svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="12" r="10"/><path d="m12 6.5 1.7 3.5 3.8.5-2.8 2.6.7 3.8-3.4-1.9-3.4 1.9.7-3.8-2.8-2.6 3.8-.5z" fill="#bdf7a0"/></svg></span>Pinjaman</div>
      <div class="pie-wrap"><svg viewBox="-1.02 -1.02 2.04 2.04" id="pieSvg"></svg></div>
      <div class="pie-legend" id="pieLegend"></div>
    </div>
  </div>
</main>
</div>
<div class="view" id="view-mantri">
<main class="main-mantri">
  <button type="button" class="mt-add" id="mtAdd"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><circle cx="12" cy="12" r="10"/><path d="M12 7v10M7 12h10"/></svg>Add</button>
  <div class="mt-grid" id="mtGrid"></div>
</main>
</div>
<div class="view" id="view-mantri-detail">
<main class="main-mtd">
  <div class="mtd-top"><button type="button" class="mtd-back" id="mtdBack" title="Kembali"><svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5M12 19l-7-7 7-7"/></svg></button></div>
  <div class="mtd-body">
    <div class="mtd-banner">
      <div id="mtdAvatarWrap"></div>
      <div class="mtd-info"><div class="mtd-name" id="mtdName"></div><div class="mtd-role" id="mtdRole"></div></div>
      <div class="mtd-stat"><b id="mtdN">0</b><span>Total Nasabah</span></div>
      <div class="mtd-stat"><b id="mtdP">0</b><span>Total Plafon</span></div>
      <div class="mtd-stat"><b id="mtdI">0</b><span>Belum Lengkap</span></div>
    </div>
    <div class="mtd-filters">
      <div class="mtd-search"><svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg><input id="mtdSearch" type="text" placeholder="Search Nasabah/CIF/No. Rek" autocomplete="off"></div>
      <button type="button" class="mtd-chip active" data-f="all">Semua</button>
      <button type="button" class="mtd-chip" data-f="restruk">Restruk</button>
      <div class="mtd-datewrap">
        <button type="button" class="mtd-chip" id="mtdTgl"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><rect x="3" y="5" width="18" height="16" rx="3"/><path d="M3 10h18M8 3v4M16 3v4"/></svg><span id="mtdTglLabel">Tanggal</span></button>
        <div class="dropdown dd-tanggal hidden" id="mtdTglPop">
          <label for="mtdDate">Pilih Tgl Realisasi</label>
          <input type="date" id="mtdDate">
          <div class="dd-actions"><button class="btn-clear" id="mtdClear" type="button">Hapus</button><button class="btn-apply" id="mtdApply" type="button">Terapkan</button></div>
        </div>
      </div>
      <button type="button" class="mtd-chip" data-f="inc">Belum lengkap</button>
    </div>
    <div class="mtd-list" id="mtdList"></div>
  </div>
</main>
</div>
<div class="view" id="view-jaminan">
<main class="main-jm">
  <div class="jm-head"><h1>Jaminan</h1><p>Klik laci untuk melihat daftar jaminan di dalamnya</p></div>
  <div class="jm-stats">
    <div class="jm-stat"><span>Total Jaminan</span><b id="jmTotal">0</b></div>
    <div class="jm-stat"><span>Aktif</span><b id="jmAktif">0</b></div>
    <div class="jm-stat"><span>Lunas</span><b id="jmLunas">0</b></div>
    <div class="jm-stat"><span>Diambil</span><b id="jmDiambil">0</b></div>
  </div>
  <div class="jm-warn hidden" id="jmWarn"></div>
  <div class="jm-grid" id="jmGrid"></div>
  <button type="button" class="jm-add" id="jmAdd"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><circle cx="12" cy="12" r="10"/><path d="M12 7v10M7 12h10"/></svg>Tambah Lemari</button>
</main>
</div>
<div class="view" id="view-jaminan-detail">
<main class="main-mtd">
  <div class="mtd-top jd-top"><button type="button" class="mtd-back" id="jdBack" title="Kembali"><svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5M12 19l-7-7 7-7"/></svg></button><div><div class="jd-title" id="jdTitle"></div><div class="jd-subt" id="jdSub"></div></div></div>
  <div class="mtd-body">
    <div class="jd-summary">
      <div class="jd-card" id="jdCap"></div>
      <div class="jd-card"><div class="jd-lbl">Status jaminan (klik untuk memfilter)</div><div class="jd-chips" id="jdChips"></div></div>
    </div>
    <div class="jd-card jd-mapcard"><div class="jd-lbl">Peta isi laci (1–200) — kotak putih bergaris = kosong (jaminan Diambil). Klik kotak untuk mengedit</div><div class="jd-map" id="jdMap"></div></div>
    <div class="jd-toolbar">
      <div class="jd-search"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg><input id="jdSearch" type="text" placeholder="Cari no. urut / debitur / no. pinjaman / isi jaminan" autocomplete="off"></div>
      <select class="jd-sort" id="jdSort"><option value="asc">No. urut ↑</option><option value="desc">No. urut ↓</option><option value="nama">Nama A–Z</option><option value="status">Status</option></select>
    </div>
    <div class="jd-tblwrap"><table class="jd-tbl"><thead><tr><th>No.</th><th>Debitur</th><th>Isi Jaminan</th><th>Status</th><th style="text-align:right">Aksi</th></tr></thead><tbody id="jdBody"></tbody></table></div>
    <div class="jd-pager" id="jdPager"></div>
  </div>
</main>
</div>
<div class="view" id="view-statistik">
<main class="main-jm">
  <div class="jm-head"><h1>Statistik</h1><p>Ringkasan dokumen, plafon, kinerja mantri, dan kondisi jaminan</p></div>
  <div class="st-body">
    <div class="st-filters">
      <span class="st-fl">Filter</span>
      <select class="st-sel" id="stYear"></select>
      <select class="st-sel" id="stMantri"></select>
      <select class="st-sel" id="stJenis"></select>
      <button type="button" class="st-reset" id="stReset">Reset</button>
    </div>
    <div class="st-kpis" id="stKpis"></div>
    <div class="st-row r1">
      <div class="st-card"><div class="st-ct"><span>Tren Bulanan</span><span class="st-cs" id="stTrendSub"></span></div>
        <div class="st-legendline"><span><i style="background:#0b559f;border-radius:3px"></i>Jumlah dokumen (kiri)</span><span><i style="background:#ff9800;border-radius:50%"></i>Total plafon, juta Rp (kanan)</span></div>
        <div id="stTrend"></div></div>
      <div class="st-card"><div class="st-ct"><span>Status Pinjaman</span></div><div id="stStatus"></div></div>
    </div>
    <div class="st-row r2">
      <div class="st-card"><div class="st-ct"><span>Plafon per Jenis Pinjaman</span></div><div id="stJenisChart"></div></div>
      <div class="st-card"><div class="st-ct"><span>Kelengkapan Berkas</span></div><div id="stLengkap"></div></div>
    </div>
    <div class="st-row r3">
      <div class="st-card"><div class="st-ct"><span>Peringkat Mantri</span><span class="st-cs">Klik baris untuk melihat detail</span></div><div style="overflow-x:auto" id="stMantriTbl"></div></div>
      <div class="st-col">
        <div class="st-card"><div class="st-ct"><span>Status Jaminan</span><span class="st-cs" id="stJamSub"></span></div><div id="stJamStatus"></div></div>
        <div class="st-card"><div class="st-ct"><span>Okupansi Lemari</span><span class="st-cs">Jaminan diambil dihitung kosong</span></div><div id="stOkupansi"></div></div>
      </div>
    </div>
  </div>
</main>
</div>
<div class="view" id="view-export">
<main class="main-jm">
  <div class="jm-head"><h1>Export Excel</h1><p>Unduh data dokumen atau jaminan ke file Excel atau CSV</p></div>
  <div class="ex-body">
    <div class="ex-main">
      <div class="ex-card"><div class="ex-ct">Jenis data</div>
        <div class="ex-seg" id="exDs"><button type="button" class="active" data-ds="doc">Dokumen</button><button type="button" data-ds="jam">Jaminan</button></div></div>
      <div class="ex-card"><div class="ex-ct"><span>Filter</span><button type="button" class="ex-lk" id="exReset">Reset filter</button></div>
        <div class="ex-filters">
          <div class="ex-f"><label for="exFrom">Tgl realisasi dari</label><input type="date" id="exFrom"></div>
          <div class="ex-f"><label for="exTo">Sampai</label><input type="date" id="exTo"></div>
          <div class="ex-f"><label for="exMantri">Mantri</label><select id="exMantri"></select></div>
          <div class="ex-f"><label for="exJenis">Jenis pinjaman</label><select id="exJenis"></select></div>
          <div class="ex-f"><label for="exStatus">Status pinjaman</label><select id="exStatus"><option value="">Semua status</option><option>Aktif</option><option>Lunas</option><option>Restruk</option><option>DH</option></select></div>
          <div class="ex-f"><label for="exLengkap">Kelengkapan berkas</label><select id="exLengkap"><option value="">Semua</option><option value="lengkap">Lengkap</option><option value="belum">Belum lengkap</option></select></div>
          <div class="ex-f" id="exStjWrap" style="display:none"><label for="exStj">Status jaminan</label><select id="exStj"></select></div>
        </div></div>
      <div class="ex-card"><div class="ex-ct"><span>Kolom yang diekspor</span><span class="ex-lks"><button type="button" id="exStd">Format impor</button><button type="button" id="exAll">Semua</button><button type="button" id="exNone">Kosongkan</button></span></div><div class="ex-cols" id="exCols"></div></div>
      <div class="ex-card"><div class="ex-ct"><span>Pratinjau</span><span class="st-cs" id="exPrevSub"></span></div><div class="jd-tblwrap" id="exPrev"></div></div>
    </div>
    <aside class="ex-side"><div class="ex-card">
      <div class="ex-count" id="exCount">0</div><div class="ex-dsl" id="exDsLabel"></div><div class="ex-dsl" id="exColCount"></div>
      <div class="ex-sep"></div>
      <span class="ex-lab">Format file</span>
      <div class="ex-seg" id="exFmt"><button type="button" class="active" data-fmt="xlsx">Excel (.xlsx)</button><button type="button" data-fmt="csv">CSV (.csv)</button></div>
      <div id="exCsvOpt" style="display:none"><span class="ex-lab">Pemisah kolom CSV</span>
        <select id="exSep" class="ex-in"><option value=";">Titik koma ( ; ) — Excel Indonesia</option><option value=",">Koma ( , )</option><option value="tab">Tab</option></select></div>
      <span class="ex-lab">Nama file</span>
      <div class="ex-namebox"><input id="exName" class="ex-in" type="text" autocomplete="off"><span id="exExt">.xlsx</span></div>
      <button type="button" class="ex-btn" id="exGo">Download</button>
      <button type="button" class="ex-btn2" id="exTpl">Unduh template impor (kosong)</button>
      <p class="ex-hint">Kolom <b>Format impor</b> (NO sampai JAMINAN) sama dengan kolom di Upload File, jadi hasil ekspor bisa langsung diimpor kembali.</p>
    </div></aside>
  </div>
</main>
</div>
<div class="view" id="view-cari"><main class="main">
    <div class="sticky-top">
    <div class="topbar">
      <div class="search-wrap">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>
        <input id="searchInput" type="text" placeholder="No BRIMEN/CIF/No.Pinjaman/Nama Debitur">
      </div>
      <button class="btn-input-file" id="openInputModalBtn">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6"><circle cx="12" cy="12" r="10"/><path d="M12 8v8M8 12h8"/></svg>
        Input File
      </button>
    </div>

    <div class="filters">
      <div class="pill pill-mantri">
        <button class="pill-btn" id="mantriBtn">
          <span class="ic"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-8 8-8s8 3.6 8 8"/></svg></span>
          <span id="mantriLabel">Mantri</span>
        </button>
        <div class="dropdown dd-mantri hidden" id="mantriDropdown"></div>
      </div>

      <div class="pill pill-pinjaman">
        <button class="pill-btn" id="pinjamanBtn">
          <span class="ic"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3"><path d="M21 11.5a4.5 4.5 0 0 0-4.5-4.5H9A6 6 0 0 0 9 19h8a4 4 0 0 0 0-8H10a2.5 2.5 0 0 0 0 5h6"/></svg></span>
          <span id="pinjamanLabel">Pinjaman</span>
        </button>
        <div class="dropdown dd-pinjaman hidden" id="pinjamanDropdown"></div>
      </div>

      <div class="pill pill-tanggal">
        <button class="pill-btn" id="tanggalBtn">
          <span class="ic"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3"><rect x="3" y="5" width="18" height="16" rx="3"/><path d="M3 10h18M8 3v4M16 3v4"/></svg></span>
          <span id="tanggalLabel">Tanggal</span>
        </button>
        <div class="dropdown dd-tanggal hidden" id="tanggalDropdown">
          <label for="tglInput">Pilih Tgl Realisasi</label>
          <input type="date" id="tglInput">
          <div class="dd-actions">
            <button class="btn-clear" id="tglClear" type="button">Hapus</button>
            <button class="btn-apply" id="tglApply" type="button">Terapkan</button>
          </div>
        </div>
      </div>
    </div>

    <div class="result-label">Semua Hasil</div>
    </div><!-- /.sticky-top -->
    <div class="cards-scroll">
      <div class="cards" id="cardsContainer"></div>
    </div>
  </main></div>
<div class="view" id="view-form"><main class="main-if">
    <div class="form-wrap">
      <div class="form-card">
        <div class="form-header">
          <div class="fh-icon">
            <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M12 12v6M9 15h6"/></svg>
          </div>
          <div>
            <h2 id="formTitle">Input dokumen baru</h2>
            <p id="formSub">Lengkapi semua field yang wajib diisi</p>
          </div>
        </div>

        <div class="form-body">
          <div class="section-label">Data Nasabah</div>

          <div class="grid-row row-1">
            <div class="field">
              <label>Nama debitur <span class="req">*</span></label>
              <input type="text" id="fNama" placeholder="Nama lengkap sesuai doumen">
            </div>
            <div class="field">
              <label>No. pinjaman <span class="req">*</span></label>
              <input type="text" id="noPinjaman" inputmode="numeric" autocomplete="off" placeholder="6152-01-xxxxxx-xx-x">
            </div>
            <div class="field dropdown-field" id="jenisField">
              <label>Jenis Pinjaman<span class="req">*</span></label>
              <button type="button" class="select-box" id="jenisBtn">
                <span class="ph" id="jenisVal">Pilih jenis pinjaman</span>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M6 9l6 6 6-6"/></svg>
              </button>
              <div class="listbox hidden" id="jenisList">
                <div class="lb-header">Pilih jenis pinjaman</div>
                <div class="lb-item" data-val="KUR">KUR</div>
                <div class="lb-item" data-val="KUPEDES">KUPEDES</div>
                <div class="lb-item" data-val="KUPERA">KUPERA</div>
                <div class="lb-item" data-val="GBT">GBT</div>
                <div class="lb-item" data-val="KECE">KECE</div>
              </div>
            </div>
          </div>

          <div class="grid-row row-2">
            <div class="field">
              <label>Plafon<span class="req">*</span></label>
              <div class="rp-wrap">
                <span class="rp">Rp</span>
                <input type="text" id="plafon" inputmode="numeric" autocomplete="off" placeholder="0">
              </div>
            </div>
            <div class="field">
              <label>CIF<span class="req">*</span></label>
              <input type="text" id="fCif">
            </div>
            <div class="field dropdown-field" id="mantriField">
              <label>Mantri<span class="req">*</span></label>
              <button type="button" class="select-box" id="fMantriBtn">
                <span class="ph" id="mantriVal">Pilih mantri</span>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M6 9l6 6 6-6"/></svg>
              </button>
              <div class="listbox hidden" id="mantriList">
                <div class="lb-header">Pilih mantri</div>
                <div class="lb-item" data-val="Regita Aulia Permadani">Regita Aulia Permadani</div>
                <div class="lb-item" data-val="Ayunda Febrianti">Ayunda Febrianti</div>
                <div class="lb-item" data-val="Antika Prasfilodia">Antika Prasfilodia</div>
                <div class="lb-item" data-val="Azizah Ira Alquran">Azizah Ira Alquran</div>
                <div class="lb-item" data-val="Muhammad Adel">Muhammad Adel</div>
                <div class="lb-item" data-val="Taufan Pramana P">Taufan Pramana P</div>
              </div>
            </div>
            <div class="field dropdown-field" id="tglField">
              <label>Tanggal Realisasi<span class="req">*</span></label>
              <button type="button" class="select-box" id="tglBtn">
                <span class="ph" id="tglVal">Pilih tanggal</span>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><rect x="3" y="5" width="18" height="16" rx="3"/><path d="M3 10h18M8 3v4M16 3v4"/></svg>
              </button>
              <div class="calendar-pop hidden" id="calendarPop">
                <div class="cal-head">
                  <span class="cal-title" id="calTitle">April 2026</span>
                  <div>
                    <button type="button" id="calPrev">
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M15 18l-6-6 6-6"/></svg>
                    </button>
                    <button type="button" id="calNext">
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M9 18l6-6-6-6"/></svg>
                    </button>
                  </div>
                </div>
                <div class="cal-grid" id="calGrid"></div>
              </div>
            </div>
          </div>

          <div class="section-label second">Lokasi Berkas</div>

          <div class="checkbox-row" id="noJaminanRow">
            <span class="chk-box" id="noJaminanChk"></span>
            Tidak ada jaminan fisik (tanpa agunan)
          </div>

          <div class="brimen-section" id="brimenSection">
            <div class="brimen-group">
              <div class="bg-label">BRIMEN berkas <span class="req">*</span></div>
              <div class="bg-boxes">
                <div class="bb"><label>Ruang</label><input></div>
                <div class="bb"><label>Loker</label><input></div>
                <div class="bb"><label>Laci</label><input></div>
                <div class="bb"><label>Berkas</label><input></div>
              </div>
            </div>
            <div class="brimen-group" id="jaminanGroup">
              <div class="bg-label">BRIMEN jaminan<span class="req">*</span></div>
              <div class="bg-boxes">
                <div class="bb"><label>Ruang</label><input></div>
                <div class="bb"><label>Loker</label><input></div>
                <div class="bb"><label>Laci</label><input></div>
                <div class="bb"><label>Berkas</label><input></div>
              </div>
            </div>
            <div class="field dropdown-field status-field" id="statusField">
              <label>Status Pinjaman</label>
              <button type="button" class="select-box" id="statusBtn">
                <span class="ph" id="statusVal">Pilih Status</span>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M6 9l6 6 6-6"/></svg>
              </button>
              <div class="listbox hidden" id="statusList">
                <div class="lb-header">Pilih Status</div>
                <div class="lb-item" data-val="Aktif">Aktif</div>
                <div class="lb-item" data-val="Lunas">Lunas</div>
                <div class="lb-item" data-val="Restruk">Restruk</div>
                <div class="lb-item" data-val="DH">DH</div>
              </div>
            </div>
          </div>

          <div class="field full" id="isiJaminanField">
            <label>Isi jaminan<span class="req">*</span></label>
            <input type="text" id="fIsi">
          </div>

          <div class="field full">
            <label>note</label>
            <textarea id="fNote"></textarea>
          </div>

          <div class="form-footer">
            <div class="checkbox-row small" id="belumLengkapRow">
              <span class="chk-box" id="belumLengkapChk"></span>
              Tandai Belum lengkap
            </div>
            <div class="footer-actions">
              <button type="button" class="btn-outline" id="btnBatal">Batal</button>
              <button type="button" class="btn-outline strong" id="btnSimpan">Simpan dokumen</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main></div>
<div class="view" id="view-detail"><main class="main-if">
  <div class="form-wrap">
    <div class="form-card">
      <div class="form-header">
        <div class="fh-icon"><svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7Z"/><circle cx="12" cy="12" r="3"/></svg></div>
        <div><h2>Detail dokumen</h2><p id="dSub"></p></div>
        <div class="d-badges" id="dBadges"></div>
      </div>
      <div class="form-body">
        <div id="dAlert"></div>
        <div class="section-label">Data Nasabah</div>
        <div class="d-grid" id="dNasabah"></div>
        <div class="section-label second">Lokasi Berkas</div>
        <div id="dLokasi"></div>
        <div class="section-label second">Catatan</div>
        <div class="d-note" id="dNote"></div>
        <div class="form-footer">
          <button type="button" class="btn-outline" id="dBack">Kembali</button>
          <div style="display:flex;gap:10px"><button type="button" class="btn-outline danger" id="dDel" style="display:none">Hapus data</button><button type="button" class="btn-outline strong" id="dEdit">Edit data</button></div>
        </div>
      </div>
    </div>
  </div>
</main></div>
</div>
<!-- MODAL INPUT FILE -->
<div class="modal-overlay hidden" id="inputModalOverlay">
  <div class="modal" id="modalBox">

    <!-- Step 0: pilihan -->
    <div class="modal-sub active" id="stepChoice">
      <div class="modal-head">
        <div>
          <h2>Input File</h2>
          <p>Pilih cara memasukkan data pinjaman baru</p>
        </div>
        <button class="modal-close" id="closeModalBtn">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M6 6l12 12M18 6L6 18"/></svg>
        </button>
      </div>
      <div class="choice-grid">
        <div class="choice-card excel" id="choiceExcel">
          <div class="ci">
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M9 13l2.5 5M11.5 13L9 18"/></svg>
          </div>
          <h3>Upload File</h3>
          <p>Unggah file Excel, CSV, TXT, atau HTML berisi banyak data pinjaman sekaligus</p>
        </div>
        <div class="choice-card manual" id="choiceManual">
          <div class="ci">
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>
          </div>
          <h3>Input Manual</h3>
          <p>Isi form satu per satu untuk satu data debitur</p>
        </div>
      </div>
    </div>

    <!-- Step Excel -->
    <div class="modal-sub" id="stepExcel">
      <button class="back-link" id="backFromExcel">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M15 18l-6-6 6-6"/></svg>
        Kembali
      </button>
      <div class="modal-head">
        <div><h2>Upload File</h2><p>Format kolom harus sesuai template yang disediakan</p></div>
      </div>
      <div class="dropzone" id="dropzone">
        <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3v12"/><path d="M7 8l5-5 5 5"/><path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"/></svg>
        <div class="dz-title">Klik untuk pilih file, atau tarik ke sini</div>
        <div class="dz-sub">Format .xlsx, .xls, .csv, .txt, atau .html</div>
      </div>
      <input type="file" id="excelInput" accept=".xlsx,.xls,.csv,.txt,.html,.htm" style="display:none">
      <div class="dz-hint"><b>Kolom yang dibaca:</b> NO REKENING PINJAMAN, NAMA DEBITUR, PLAFON, TGL REALISASI, CIF NO, JENIS PINJ, MANTRI, NO BRIMEN, NO JAMINAN, JAMINAN</div>
      <div id="fileChipWrap"></div>
      <div class="modal-actions">
        <button class="btn-secondary" id="cancelExcel">Batal</button>
        <button class="btn-primary" id="processExcel" disabled>Proses Data</button>
      </div>
    </div>

    <!-- Step Pratinjau -->
    <div class="modal-sub" id="stepPreview">
      <button class="back-link" id="pvBack">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M15 18l-6-6 6-6"/></svg>
        Kembali
      </button>
      <div class="modal-head"><div><h2>Pratinjau Impor</h2><p id="pvSub"></p></div></div>
      <label class="pv-opt"><input type="checkbox" id="pvUpdate"> Perbarui data yang sudah ada jika isinya berbeda</label>
      <div class="pv-chips" id="pvChips"></div>
      <div class="pv-wrap" id="pvWrap"></div>
      <div id="pvIssues"></div>
      <div class="modal-actions">
        <button class="btn-secondary" id="pvCancel">Batal</button>
        <button class="btn-primary" id="pvImport">Impor</button>
      </div>
    </div>

    <!-- Step Manual -->
    <div class="modal-sub" id="stepManual">
      <button class="back-link" id="backFromManual">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M15 18l-6-6 6-6"/></svg>
        Kembali
      </button>
      <div class="modal-head">
        <div><h2>Input Manual</h2><p>Form input satu data debitur</p></div>
      </div>
      <div class="manual-note">
        Form input manual (nama debitur, BRIMEN, No. Pinjaman, CIF, mantri, jenis pinjaman, plafon, dll) akan dibuatkan setelah struktur datanya kita tentukan bersama di halaman Input File.
      </div>
      <div class="modal-actions">
        <button class="btn-secondary" id="cancelManual">Tutup</button>
      </div>
    </div>

  </div>
</div>


<div class="modal-overlay hidden" id="mtModal">
  <div class="modal" style="max-width:480px">
    <div class="modal-head"><div><h2>Tambah Mantri</h2><p>Mantri baru otomatis muncul di form dan filter</p></div>
      <button type="button" class="modal-close" id="mtModalClose"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M6 6l12 12M18 6L6 18"/></svg></button></div>
    <div class="mt-photo"><div class="mt-avatar big" id="mtNewAvatar"><svg viewBox="0 0 24 24" fill="none" stroke-width="1.8" stroke-linecap="round"><circle cx="12" cy="8" r="4"/><path d="M4.5 21c0-4 3.4-6.5 7.5-6.5s7.5 2.5 7.5 6.5"/></svg><span class="cam">Tambah foto</span></div><small>Klik lingkaran untuk menambah foto (opsional)</small></div>
    <div class="mt-form">
      <label for="mtNama">Nama lengkap <span class="req">*</span></label><input id="mtNama" type="text" placeholder="Nama lengkap mantri" autocomplete="off">
      <label for="mtKode">ID / Kode mantri <span class="req">*</span></label><input id="mtKode" type="text" placeholder="mis. 00399892" autocomplete="off">
      <label for="mtJabatan">Jabatan</label><input id="mtJabatan" type="text" autocomplete="off">
    </div>
    <div class="modal-actions"><button type="button" class="btn-secondary" id="mtCancel">Batal</button><button type="button" class="btn-primary" id="mtSave">Simpan</button></div>
  </div>
</div>
<div class="modal-overlay hidden" id="jmModal">
  <div class="modal" style="max-width:520px">
    <div class="modal-head"><div><h2>Edit Jaminan</h2><p>Perubahan tercatat di riwayat</p></div>
      <button type="button" class="modal-close" id="jmClose"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M6 6l12 12M18 6L6 18"/></svg></button></div>
    <div class="jm-box" id="jmInfo"></div>
    <div class="mt-form">
      <label for="jmIsi">Isi jaminan <span class="req">*</span></label><textarea id="jmIsi" placeholder="mis. Sertifikat tanah SHM No. 1182 a.n. Siti Rahayu"></textarea>
      <label for="jmSt">Status</label><select id="jmSt"></select><small class="jm-hint">Mengubah ke Aktif, Lunas, Restruk, atau DH ikut mengubah status berkas. Jaminan Diambil dianggap slot kosong dan bisa dihapus. Jaminan Lunas tetap mengisi slot sampai diambil.</small>
      <label for="jmKet">Keterangan status (opsional)</label><input id="jmKet" type="text" placeholder="mis. dibawa Mantri Regita, 12 Okt 2026" autocomplete="off">
      <label>Riwayat perubahan</label><div class="jm-hist" id="jmHist"></div>
    </div>
    <div class="modal-actions"><button type="button" class="btn-danger" id="jmDel" style="margin-right:auto;display:none">Hapus jaminan</button><button type="button" class="btn-secondary" id="jmCancel">Batal</button><button type="button" class="btn-primary" id="jmSave">Simpan</button></div>
  </div>
</div>
<div class="modal-overlay hidden" id="lmModal">
  <div class="modal" style="max-width:420px">
    <div class="modal-head"><div><h2>Tambah Lemari</h2><p>Kode lemari = huruf loker pada BRIMEN jaminan</p></div>
      <button type="button" class="modal-close" id="lmClose"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M6 6l12 12M18 6L6 18"/></svg></button></div>
    <div class="mt-form">
      <label for="lmKode">Kode lemari <span class="req">*</span></label><input id="lmKode" type="text" maxlength="3" placeholder="mis. Q" autocomplete="off" style="text-transform:uppercase">
      <label for="lmJumlah">Jumlah laci</label><input id="lmJumlah" type="number" min="1" max="12" value="4">
    </div>
    <div class="modal-actions"><button type="button" class="btn-secondary" id="lmCancel">Batal</button><button type="button" class="btn-primary" id="lmSave">Simpan</button></div>
  </div>
</div>
<div class="modal-overlay hidden" id="cfModal">
  <div class="modal" style="max-width:440px">
    <div class="modal-head"><div><h2 id="cfTitle">Hapus data?</h2><p id="cfMsg"></p></div></div>
    <div class="cf-warn" id="cfWarn"></div>
    <div class="modal-actions"><button type="button" class="btn-secondary" id="cfNo">Batal</button><button type="button" class="btn-danger" id="cfYes">Hapus</button></div>
  </div>
</div>
<div class="toast" id="toast"></div>

<script>window.__BOOT__ = { user: <?php echo json_encode($user, 15, 512) ?> };</script>
<script src="<?php echo e(asset('assets/js/01-store-mantri.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/02-cari-file.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/03-form-input.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/04-aplikasi.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/05-dashboard-login.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/06-upload-file.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/07-mantri.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/08-jaminan.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/09-statistik.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/10-export-excel.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/11-status-relasi.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/12-sinkronisasi.js')); ?>"></script>
</body>
</html>
<?php /**PATH D:\Semester 6\MAGANG\brimen-index\resources\views/app.blade.php ENDPATH**/ ?>