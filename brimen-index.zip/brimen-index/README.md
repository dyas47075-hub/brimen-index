# BRIMEN Index (Laravel + MySQL)

Sistem Informasi Pengindeksan Dokumen Brimen Berbasis Web — versi **Laravel (PHP)** dengan database **MySQL**.
Tampilan dan fitur sama persis dengan prototipe HTML: Login, Dashboard, Cari File, Input File (formulir manual &
upload Excel/CSV/TXT/HTML), Edit Data, Detail Dokumen, Mantri, Jaminan (lemari & laci), Statistik, dan Export Excel.
Bedanya, semua data kini **tersimpan permanen di database**, dan login memakai akun di tabel `users`.

---

## 1. Kebutuhan

| Perangkat lunak | Versi |
|---|---|
| PHP | 8.2 atau lebih baru |
| Ekstensi PHP | `pdo_mysql`, `mbstring`, `openssl`, `tokenizer`, `xml`, `ctype`, `json`, `fileinfo` |
| Composer | 2.x |
| MySQL / MariaDB | MySQL 5.7+ atau MariaDB 10.3+ |

Paling mudah di Windows: pasang **XAMPP** (PHP 8.2+ & MySQL) dan **Composer**.

> Folder `vendor/` tidak disertakan di zip. Dibuat otomatis oleh `composer install`.

## 2. Instalasi (cara disarankan: migration)

Buka terminal/CMD di dalam folder proyek ini, lalu:

```bash
# 1) Pasang dependensi Laravel
composer install

# 2) Buat file konfigurasi
cp .env.example .env            # Windows CMD: copy .env.example .env
php artisan key:generate

# 3) Buat database kosong "brimen_index" (phpMyAdmin atau):
mysql -u root -e "CREATE DATABASE brimen_index CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
#    lalu cek DB_DATABASE / DB_USERNAME / DB_PASSWORD di file .env

# 4) Buat tabel + akun awal + lemari L, M, N, P
php artisan migrate --seed

# 5) Jalankan
php artisan serve
```

Buka **http://127.0.0.1:8000**

### Akun awal
| | |
|---|---|
| ID Petugas | `admin` |
| Kata sandi | `Brimen#2026` |

**Segera ganti** (kata sandi disimpan sebagai hash, tidak pernah berupa teks biasa):

```bash
php artisan brimen:buat-akun admin --nama="Nama Anda"
# lalu ketik kata sandi baru dua kali
```

Perintah yang sama dipakai untuk **membuat akun baru** atau **mereset kata sandi yang lupa**.
Tidak ada halaman registrasi — akun hanya bisa dibuat lewat perintah ini sehingga orang luar tidak bisa mendaftar sendiri.

## 3. Alternatif: impor SQL manual

Jika tidak memakai `php artisan migrate`, impor `database/schema.sql` lewat phpMyAdmin
(sudah termasuk pembuatan database, semua tabel, akun `admin`, dan lemari L–P).
Jangan lanjut menjalankan `php artisan migrate` setelah itu karena tabelnya sudah ada.
Langkah `composer install`, `.env`, dan `key:generate` tetap diperlukan.

## 4. Data contoh (opsional)

Database awal **kosong** (kecuali akun & lemari). Untuk mencoba aplikasi dengan data contoh
(6 mantri + 206 dokumen):

```bash
php artisan db:seed --class=DemoSeeder
```

## 5. Struktur database

| Tabel | Isi |
|---|---|
| `users` | Akun petugas (ID Petugas, nama, hash kata sandi) |
| `mantri` | Daftar mantri: kode, nama, jabatan, foto |
| `lemari`, `laci` | Lemari penyimpanan jaminan dan lacinya (laci bisa ditandai tidak dipakai) |
| `documents` | Berkas pinjaman: data nasabah, BRIMEN berkas, jaminan (BRIMEN jaminan, isi, status), status berkas, catatan, riwayat perubahan |

Aturan yang dijaga oleh **server** (selain validasi di tampilan):
- No. pinjaman unik, format `0000-00-000000-00-0`.
- Satu slot jaminan (ruang.loker.laci.nomor) hanya untuk satu jaminan; jaminan berstatus **Diambil** dianggap slot kosong.
- Status berkas: Aktif, Lunas, Restruk, DH. Status jaminan: Aktif, Lunas, Restruk, DH, Diambil, Lemari Tahan Api, Notaris, Dibawa Mantri.
- **BRIMEN berkas** (map & nomor berkas) hanya boleh dipakai ulang setelah dokumen sebelumnya **Lunas**. Selama belum lunas,
  map yang sama hanya boleh dipakai pinjaman milik nasabah (CIF) yang sama; nasabah lain ditolak.
  Mengembalikan status dokumen dari Lunas ke status lain juga ditolak bila berkasnya sudah dipakai nasabah lain.
- **CIF** yang sama harus atas nama yang sama (untuk data baru). CIF yang sama dengan no. pinjaman berbeda diperbolehkan
  (satu nasabah, beberapa pinjaman) dan hanya diberi pemberitahuan di tampilan.
- Mantri pada dokumen harus terdaftar di tabel `mantri`.

## 6. Cara kerja singkat

- `routes/web.php` — halaman `/`, `POST /login`, `POST /logout`, `GET /api/bootstrap`, `POST /api/sync`.
- `resources/views/app.blade.php` — satu halaman yang memuat seluruh tampilan (menu berpindah tanpa reload).
- `public/assets/js/*.js` — logika tiap halaman. `12-sinkronisasi.js` memuat data dari server setelah login
  dan **menyimpan otomatis** setiap perubahan (tambah / ubah / hapus) lewat `POST /api/sync` dalam satu transaksi database.
  Jika server menolak suatu data (mis. no. pinjaman kembar), semua perubahan pada permintaan itu dibatalkan,
  pesan alasannya ditampilkan, lalu halaman dimuat ulang dari database.
- `app/Http/Controllers/DataController.php` — validasi dan penyimpanan data.
- `app/Support/DokumenMapper.php` — pemetaan data tampilan ↔ kolom database.
- `public/vendor/xlsx.full.min.js` — pustaka SheetJS (Apache-2.0) untuk membaca/membuat file Excel; tersimpan lokal sehingga
  upload & export Excel tetap jalan tanpa internet. Font Poppins dimuat dari Google Fonts (tanpa internet memakai font bawaan).

## 7. Menjalankan di XAMPP (tanpa `artisan serve`)

Arahkan *DocumentRoot* Apache (virtual host) ke folder `public/`, atau akses `http://localhost/brimen-index/public`.
Pastikan `mod_rewrite` aktif. Folder `storage/` dan `bootstrap/cache/` harus bisa ditulis oleh web server.

## 8. Pemecahan masalah

| Gejala | Penyebab / solusi |
|---|---|
| `Class ... not found` / halaman putih | Belum `composer install`, atau ekstensi PHP belum aktif |
| `No application encryption key` | Jalankan `php artisan key:generate` |
| `SQLSTATE ... Access denied / Unknown database` | Periksa `DB_*` di `.env` dan pastikan database `brimen_index` sudah dibuat |
| Error 500 | Lihat `storage/logs/laravel.log`; pastikan `storage/` dan `bootstrap/cache/` bisa ditulis |
| Muncul "Sesi berakhir" / error 419 | Muat ulang halaman lalu login lagi |
| Login ditolak terus | Maksimal 6 percobaan per menit. Tunggu 1 menit, atau reset dengan `php artisan brimen:buat-akun` |
| Upload Excel gagal dibaca | Pastikan kolom sesuai: NO REKENING PINJAMAN, NAMA DEBITUR, PLAFON, TGL REALISASI, CIF NO, JENIS PINJ, MANTRI, NO BRIMEN, NO JAMINAN, JAMINAN |

## 9. Keamanan

- Ganti kata sandi awal sebelum dipakai (lihat bagian 2).
- Untuk penggunaan sebenarnya set `APP_ENV=production` dan `APP_DEBUG=false` di `.env`.
- Jangan mengunggah file `.env` ke repositori publik.
- Gunakan HTTPS bila diakses lewat jaringan.
